#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class DCAPILib_commonsPlatformContext, DCAPIAccountPixCommand, DCAPIAccountPixQuery, DCAPIKotlinx_datetimeLocalDateTime, DCAPIAuthorization, DCAPICancellation, DCAPICancellationQuery, DCAPICapture, DCAPICaptureRequest, DCAPICaptureQuery, DCAPIHistoricTransaction, DCAPITransactionToCapture, DCAPICredentials, DCAPICredentialsCommand, DCAPIDcc, DCAPIErrorInformation, DCAPIKotlinArray<T>, DCAPIFilterSORTING, DCAPIFilter, DCAPIFullReceiptQuery, DCAPIAddress, DCAPIVoucherType, DCAPIInstalmentType, DCAPICardEntryMode, DCAPIStatus, DCAPITransactionType, DCAPIFullTransactionQuery, DCAPICustomer, DCAPIInstantPayment, DCAPIInvoice, DCAPIMerchantCommand, DCAPISubMerchantCommand, DCAPIData_container_contractTaxIdentificationType, DCAPIData_container_contractCardBrand, DCAPIPixAccount, DCAPIMerchantCommandCompanion, DCAPIMerchantQuery, DCAPIData_container_dataDataContainerDataBase, DCAPISubMerchantQuery, DCAPIProbeRequired, DCAPIProbeRequest, DCAPIProbeRequestStatus, DCAPIKotlinEnumCompanion, DCAPIKotlinEnum<E>, DCAPIReportCashPaymentQuery, DCAPIReportDataQuery, DCAPIReportQrCodeQuery, DCAPIReportSummaryCashPaymentQuery, DCAPIReportSummaryQrCodeQuery, DCAPIReportSummaryWalletQuery, DCAPIReportWalletQuery, DCAPIReversalRequired, DCAPIReversalRequest, DCAPIReversalRequestStatus, DCAPISalesHistoryQuery, DCAPIData_container_dataSystemConfigDao, DCAPIEnvironmentEnum, DCAPITransactionQuery, DCAPIAuthorizationTransactionQuery, DCAPICardHolder, DCAPICard, DCAPICardCommand, DCAPIDetailedTransactionQuery, DCAPIInstantPaymentTransactionQuery, DCAPIPaymentBusinessModel, DCAPIQrCodeTransactionQuery, DCAPITransactionCommand, DCAPITransactionToken, DCAPITransactionTokenCommand, DCAPICypher, DCAPISecurityUtil, DCAPILib_commonsPlatformContextCompanion, DCAPIData_container_dataAccountPixEntity, DCAPIKotlinx_datetimeLocalDate, DCAPIKotlinx_datetimeLocalTime, DCAPIKotlinx_datetimeMonth, DCAPIKotlinx_datetimeLocalDateTimeCompanion, DCAPIKotlinx_datetimeDayOfWeek, DCAPIData_container_dataAuthorizationEntity, DCAPIData_container_dataTransactionEntity, DCAPIData_container_dataPixApprovedTransactionView, DCAPIData_container_dataQrCodePaymentTransactionView, DCAPIData_container_dataAuthorizationTransactionView, DCAPIRoom_runtimeRoomRawQuery, DCAPIData_container_dataCancellationEntity, DCAPIData_container_dataCaptureRequestEntity, DCAPIData_container_dataTransactionToCaptureView, DCAPIData_container_dataHistoricTransactionView, DCAPIData_container_dataCaptureEntity, DCAPIData_container_dataCredentialsEntity, DCAPIData_container_dataDccEntity, DCAPIData_container_dataErrorInformationEntity, DCAPIData_container_dataFullReceiptView, DCAPIData_container_dataInvoiceEntity, DCAPIData_container_contractCardBrandCompanion, DCAPIData_container_dataMerchantEntity, DCAPIData_container_dataSubMerchantEntity, DCAPIRoom_runtimeMigration, DCAPIRoom_runtimeInvalidationTracker, DCAPIRoom_runtimeRoomDatabase, DCAPIData_container_dataDataContainerDataBaseCompanion, DCAPIData_container_dataProbeRequestEntity, DCAPIData_container_dataProbeRequiredEntity, DCAPIData_container_dataReportCashPaymentView, DCAPIData_container_dataReportData, DCAPIData_container_dataReportQrCode, DCAPIData_container_dataReportWallet, DCAPIData_container_dataReportSummaryQrCodeEntity, DCAPIData_container_dataReportSummaryWallet, DCAPIData_container_dataReversalRequestEntity, DCAPIData_container_dataReversalRequiredEntity, DCAPIData_container_dataSalesHistoryView, DCAPIKotlinThrowable, DCAPIKotlinException, DCAPIKotlinRuntimeException, DCAPIKotlinIllegalStateException, DCAPIData_container_dataSystemConfigDaoCompanion, DCAPIData_container_dataEnvironmentEnum, DCAPIKotlinx_datetimeLocalDateCompanion, DCAPIKotlinx_datetimeLocalTimeCompanion, DCAPIData_container_dataCardEntity, DCAPIData_container_dataCustomerEntity, DCAPIData_container_dataInstantPaymentEntity, DCAPIData_container_dataAddressEntity, DCAPIData_container_dataPixAccountEntity, DCAPIRoom_runtimeInvalidationTrackerObserver, DCAPIData_container_dataFullTransactionView, DCAPIData_container_dataTransactionTokenEntity, DCAPIKotlinByteArray, DCAPIKotlinx_datetimePadding, DCAPIKotlinx_datetimeDayOfWeekNames, DCAPIKotlinx_datetimeMonthNames, DCAPIData_container_dataCardHolderEntity, DCAPIKotlinByteIterator, DCAPIKotlinx_datetimeDayOfWeekNamesCompanion, DCAPIKotlinx_datetimeMonthNamesCompanion, DCAPIKotlinx_serialization_coreSerializersModule, DCAPIKotlinx_serialization_coreSerialKind, DCAPIKotlinNothing;

@protocol DCAPIAccountPixApi, DCAPIAuthorizationApi, DCAPICancellationApi, DCAPICaptureApi, DCAPICredentialsApi, DCAPIDccApi, DCAPIErrorInformationApi, DCAPIFullReceiptApi, DCAPIFullTransactionApi, DCAPIInvoiceApi, DCAPIMerchantApi, DCAPIProbeApi, DCAPIReportApi, DCAPIReversalApi, DCAPISalesHistoryApi, DCAPISystemConfigApi, DCAPITransactionApi, DCAPITransactionTokenApi, DCAPIAccountPixRepository, DCAPIData_container_dataAccountPixDao, DCAPIData_container_dataAuthorizationDao, DCAPIData_container_dataTransactionDao, DCAPIData_container_dataCancellationDao, DCAPIData_container_dataCaptureRequestDao, DCAPIData_container_dataTransactionToCaptureDao, DCAPIData_container_dataHistoricTransactionDao, DCAPIData_container_dataCaptureDao, DCAPIData_container_dataCredentialsDao, DCAPIData_container_dataDccDao, DCAPIData_container_dataErrorInformationDao, DCAPIData_container_dataFullReceiptDao, DCAPIData_container_dataInvoiceDao, DCAPIData_container_dataMerchantDao, DCAPIData_container_dataSubMerchantDao, DCAPIData_container_dataProbeRequestDao, DCAPIData_container_dataProbeRequiredDao, DCAPIData_container_dataConnectionProvider, DCAPIKotlinComparable, DCAPIData_container_dataReportDao, DCAPIData_container_dataReversalRequestDao, DCAPIData_container_dataReversalRequiredDao, DCAPIData_container_dataSalesHistoryDao, DCAPISqliteSQLiteConnection, DCAPIKotlinIterator, DCAPIKotlinKClass, DCAPIRoom_runtimeAutoMigrationSpec, DCAPIRoom_runtimeRoomOpenDelegateMarker, DCAPIKotlinx_coroutines_coreCoroutineScope, DCAPIData_container_dataDB, DCAPIData_container_dataFullTransactionDao, DCAPIData_container_dataTransactionTokenDao, DCAPISqliteSQLiteStatement, DCAPIDatastore_coreDataMigration, DCAPIDatastore_coreDataStore, DCAPIKotlinx_datetimeDateTimeFormat, DCAPIKotlinx_datetimeDateTimeFormatBuilderWithDateTime, DCAPIKotlinx_serialization_coreKSerializer, DCAPIKotlinKDeclarationContainer, DCAPIKotlinKAnnotatedElement, DCAPIKotlinKClassifier, DCAPIKotlinCoroutineContext, DCAPIKotlinSuspendFunction1, DCAPIKotlinx_coroutines_coreFlow, DCAPIKotlinx_datetimeDateTimeFormatBuilderWithDate, DCAPIKotlinx_datetimeDateTimeFormatBuilderWithTime, DCAPIKotlinAppendable, DCAPIKotlinx_datetimeDateTimeFormatBuilder, DCAPIKotlinx_serialization_coreEncoder, DCAPIKotlinx_serialization_coreSerialDescriptor, DCAPIKotlinx_serialization_coreSerializationStrategy, DCAPIKotlinx_serialization_coreDecoder, DCAPIKotlinx_serialization_coreDeserializationStrategy, DCAPIKotlinCoroutineContextElement, DCAPIKotlinCoroutineContextKey, DCAPIKotlinFunction, DCAPIKotlinx_coroutines_coreFlowCollector, DCAPIKotlinx_serialization_coreCompositeEncoder, DCAPIKotlinAnnotation, DCAPIKotlinx_serialization_coreCompositeDecoder, DCAPIKotlinx_serialization_coreSerializersModuleCollector;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface DCAPIBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface DCAPIBase (DCAPIBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface DCAPIMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface DCAPIMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorDCAPIKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface DCAPINumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface DCAPIByte : DCAPINumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface DCAPIUByte : DCAPINumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface DCAPIShort : DCAPINumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface DCAPIUShort : DCAPINumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface DCAPIInt : DCAPINumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface DCAPIUInt : DCAPINumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface DCAPILong : DCAPINumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface DCAPIULong : DCAPINumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface DCAPIFloat : DCAPINumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface DCAPIDouble : DCAPINumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface DCAPIBoolean : DCAPINumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiFactory")))
@interface DCAPIApiFactory : DCAPIBase
- (instancetype)initWithPlatformContext:(DCAPILib_commonsPlatformContext *)platformContext __attribute__((swift_name("init(platformContext:)"))) __attribute__((objc_designated_initializer));
- (id<DCAPIAccountPixApi>)createAccountPixApi __attribute__((swift_name("createAccountPixApi()")));
- (id<DCAPIAuthorizationApi>)createAuthorizationApi __attribute__((swift_name("createAuthorizationApi()")));
- (id<DCAPICancellationApi>)createCancellationApi __attribute__((swift_name("createCancellationApi()")));
- (id<DCAPICaptureApi>)createCaptureApi __attribute__((swift_name("createCaptureApi()")));
- (id<DCAPICredentialsApi>)createCredentialsApi __attribute__((swift_name("createCredentialsApi()")));
- (id<DCAPIDccApi>)createDccApi __attribute__((swift_name("createDccApi()")));
- (id<DCAPIErrorInformationApi>)createErrorInformationApi __attribute__((swift_name("createErrorInformationApi()")));
- (id<DCAPIFullReceiptApi>)createFullReceiptApi __attribute__((swift_name("createFullReceiptApi()")));
- (id<DCAPIFullTransactionApi>)createFullTransactionApi __attribute__((swift_name("createFullTransactionApi()")));
- (id<DCAPIInvoiceApi>)createInvoiceApi __attribute__((swift_name("createInvoiceApi()")));
- (id<DCAPIMerchantApi>)createMerchantApi __attribute__((swift_name("createMerchantApi()")));
- (id<DCAPIProbeApi>)createProbeApi __attribute__((swift_name("createProbeApi()")));
- (id<DCAPIReportApi>)createReportApi __attribute__((swift_name("createReportApi()")));
- (id<DCAPIReversalApi>)createReversalApi __attribute__((swift_name("createReversalApi()")));
- (id<DCAPISalesHistoryApi>)createSalesHistoryApi __attribute__((swift_name("createSalesHistoryApi()")));
- (id<DCAPISystemConfigApi>)createSystemConfigApi __attribute__((swift_name("createSystemConfigApi()")));
- (id<DCAPITransactionApi>)createTransactionApi __attribute__((swift_name("createTransactionApi()")));
- (id<DCAPITransactionTokenApi>)createTransactionTokenApi __attribute__((swift_name("createTransactionTokenApi()")));
@end

__attribute__((swift_name("AccountPixApi")))
@protocol DCAPIAccountPixApi
@required
- (id _Nullable)getAccountsPixByAccountIdAccountId:(NSString *)accountId __attribute__((swift_name("getAccountsPixByAccountId(accountId:)")));
- (id _Nullable)getAccountsPixByMerchantMerchantId:(int64_t)merchantId __attribute__((swift_name("getAccountsPixByMerchant(merchantId:)")));
- (id _Nullable)insertAccountPixCommand:(DCAPIAccountPixCommand *)accountPixCommand __attribute__((swift_name("insert(accountPixCommand:)")));
- (id _Nullable)updateAccountPixCommand:(DCAPIAccountPixCommand *)accountPixCommand __attribute__((swift_name("update(accountPixCommand:)")));
@end

__attribute__((swift_name("AccountPixRepository")))
@protocol DCAPIAccountPixRepository
@required
- (id _Nullable)getAccountsPixByAccountIdAccountId:(NSString *)accountId __attribute__((swift_name("getAccountsPixByAccountId(accountId:)")));
- (id _Nullable)getAccountsPixByMerchantMerchantId:(int64_t)merchantId __attribute__((swift_name("getAccountsPixByMerchant(merchantId:)")));
- (id _Nullable)insertAccountPixCommand:(DCAPIAccountPixCommand *)accountPixCommand __attribute__((swift_name("insert(accountPixCommand:)")));
- (id _Nullable)updateAccountPixCommand:(DCAPIAccountPixCommand *)accountPixCommand __attribute__((swift_name("update(accountPixCommand:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccountPixRepositoryImpl")))
@interface DCAPIAccountPixRepositoryImpl : DCAPIBase <DCAPIAccountPixRepository>
- (instancetype)initWithAccountPixDao:(id<DCAPIData_container_dataAccountPixDao>)accountPixDao __attribute__((swift_name("init(accountPixDao:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getAccountsPixByAccountIdAccountId:(NSString *)accountId __attribute__((swift_name("getAccountsPixByAccountId(accountId:)")));
- (id _Nullable)getAccountsPixByMerchantMerchantId:(int64_t)merchantId __attribute__((swift_name("getAccountsPixByMerchant(merchantId:)")));
- (id _Nullable)insertAccountPixCommand:(DCAPIAccountPixCommand *)accountPixCommand __attribute__((swift_name("insert(accountPixCommand:)")));
- (id _Nullable)updateAccountPixCommand:(DCAPIAccountPixCommand *)accountPixCommand __attribute__((swift_name("update(accountPixCommand:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccountPixCommand")))
@interface DCAPIAccountPixCommand : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id accountId:(NSString *)accountId accountNumber:(NSString *)accountNumber keyCreated:(BOOL)keyCreated merchantActivateId:(int64_t)merchantActivateId __attribute__((swift_name("init(id:accountId:accountNumber:keyCreated:merchantActivateId:)"))) __attribute__((objc_designated_initializer));
- (DCAPIAccountPixCommand *)doCopyId:(DCAPILong * _Nullable)id accountId:(NSString *)accountId accountNumber:(NSString *)accountNumber keyCreated:(BOOL)keyCreated merchantActivateId:(int64_t)merchantActivateId __attribute__((swift_name("doCopy(id:accountId:accountNumber:keyCreated:merchantActivateId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountId __attribute__((swift_name("accountId")));
@property (readonly) NSString *accountNumber __attribute__((swift_name("accountNumber")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) BOOL keyCreated __attribute__((swift_name("keyCreated")));
@property (readonly) int64_t merchantActivateId __attribute__((swift_name("merchantActivateId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccountPixQuery")))
@interface DCAPIAccountPixQuery : DCAPIBase
- (instancetype)initWithId:(int64_t)id accountId:(NSString *)accountId accountNumber:(NSString *)accountNumber keyCreated:(BOOL)keyCreated merchantId:(int64_t)merchantId __attribute__((swift_name("init(id:accountId:accountNumber:keyCreated:merchantId:)"))) __attribute__((objc_designated_initializer));
- (DCAPIAccountPixQuery *)doCopyId:(int64_t)id accountId:(NSString *)accountId accountNumber:(NSString *)accountNumber keyCreated:(BOOL)keyCreated merchantId:(int64_t)merchantId __attribute__((swift_name("doCopy(id:accountId:accountNumber:keyCreated:merchantId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountId __attribute__((swift_name("accountId")));
@property (readonly) NSString *accountNumber __attribute__((swift_name("accountNumber")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) BOOL keyCreated __attribute__((swift_name("keyCreated")));
@property (readonly) int64_t merchantId __attribute__((swift_name("merchantId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Authorization")))
@interface DCAPIAuthorization : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId atk:(NSString *)atk amountAuthorized:(NSString *)amountAuthorized authorizationCode:(NSString *)authorizationCode dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime __attribute__((swift_name("init(transactionId:atk:amountAuthorized:authorizationCode:dateTime:)"))) __attribute__((objc_designated_initializer));
- (DCAPIAuthorization *)doCopyTransactionId:(int64_t)transactionId atk:(NSString *)atk amountAuthorized:(NSString *)amountAuthorized authorizationCode:(NSString *)authorizationCode dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime __attribute__((swift_name("doCopy(transactionId:atk:amountAuthorized:authorizationCode:dateTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amountAuthorized __attribute__((swift_name("amountAuthorized")));
@property (readonly) NSString *atk __attribute__((swift_name("atk")));
@property (readonly) NSString *authorizationCode __attribute__((swift_name("authorizationCode")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((swift_name("AuthorizationApi")))
@protocol DCAPIAuthorizationApi
@required
- (id _Nullable)getAuthorizationTransactionId:(int64_t)transactionId __attribute__((swift_name("getAuthorization(transactionId:)")));
- (id _Nullable)getAuthorizationAtk:(NSString *)atk __attribute__((swift_name("getAuthorization(atk:)")));
- (id _Nullable)saveAuthorizationAuthorization:(DCAPIAuthorization *)authorization __attribute__((swift_name("saveAuthorization(authorization:)")));
- (id _Nullable)saveVoucherAuthorizationAuthorization:(DCAPIAuthorization *)authorization cardBalance:(NSString *)cardBalance __attribute__((swift_name("saveVoucherAuthorization(authorization:cardBalance:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthorizationRepositoryImpl")))
@interface DCAPIAuthorizationRepositoryImpl : DCAPIBase
- (instancetype)initWithAuthorizationDao:(id<DCAPIData_container_dataAuthorizationDao>)authorizationDao transactionDao:(id<DCAPIData_container_dataTransactionDao>)transactionDao __attribute__((swift_name("init(authorizationDao:transactionDao:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getAuthorizationTransactionId:(int64_t)transactionId __attribute__((swift_name("getAuthorization(transactionId:)")));
- (id _Nullable)getAuthorizationAtk:(NSString *)atk __attribute__((swift_name("getAuthorization(atk:)")));
- (id _Nullable)saveAuthorizationAuthorization:(DCAPIAuthorization *)authorization __attribute__((swift_name("saveAuthorization(authorization:)")));
- (id _Nullable)saveVoucherAuthorizationAuthorization:(DCAPIAuthorization *)authorization cardBalance:(NSString *)cardBalance __attribute__((swift_name("saveVoucherAuthorization(authorization:cardBalance:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Cancellation")))
@interface DCAPICancellation : DCAPIBase
- (instancetype)initWithAtk:(NSString *)atk amount:(NSString *)amount dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime authorizationCode:(NSString * _Nullable)authorizationCode __attribute__((swift_name("init(atk:amount:dateTime:authorizationCode:)"))) __attribute__((objc_designated_initializer));
- (DCAPICancellation *)doCopyAtk:(NSString *)atk amount:(NSString *)amount dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime authorizationCode:(NSString * _Nullable)authorizationCode __attribute__((swift_name("doCopy(atk:amount:dateTime:authorizationCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) NSString *atk __attribute__((swift_name("atk")));
@property (readonly) NSString * _Nullable authorizationCode __attribute__((swift_name("authorizationCode")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *dateTime __attribute__((swift_name("dateTime")));
@end

__attribute__((swift_name("CancellationApi")))
@protocol DCAPICancellationApi
@required
- (id _Nullable)getCancellationsTransactionId:(int64_t)transactionId __attribute__((swift_name("getCancellations(transactionId:)")));
- (id _Nullable)getCancellationsAtk:(NSString *)atk __attribute__((swift_name("getCancellations(atk:)")));
- (id _Nullable)getCancellationsQueryTransactionId:(int64_t)transactionId __attribute__((swift_name("getCancellationsQuery(transactionId:)")));
- (id _Nullable)getCancellationsQueryAtk:(NSString *)atk __attribute__((swift_name("getCancellationsQuery(atk:)")));
- (id _Nullable)saveCancelCancellation:(DCAPICancellation *)cancellation __attribute__((swift_name("saveCancel(cancellation:)")));
- (id _Nullable)saveVoucherCancelCancellation:(DCAPICancellation *)cancellation cardBalance:(NSString *)cardBalance __attribute__((swift_name("saveVoucherCancel(cancellation:cardBalance:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CancellationQuery")))
@interface DCAPICancellationQuery : DCAPIBase
- (instancetype)initWithId:(int64_t)id atk:(NSString *)atk amount:(NSString *)amount dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime authorizationCode:(NSString * _Nullable)authorizationCode __attribute__((swift_name("init(id:atk:amount:dateTime:authorizationCode:)"))) __attribute__((objc_designated_initializer));
- (DCAPICancellationQuery *)doCopyId:(int64_t)id atk:(NSString *)atk amount:(NSString *)amount dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime authorizationCode:(NSString * _Nullable)authorizationCode __attribute__((swift_name("doCopy(id:atk:amount:dateTime:authorizationCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) NSString *atk __attribute__((swift_name("atk")));
@property (readonly) NSString * _Nullable authorizationCode __attribute__((swift_name("authorizationCode")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CancellationRepositoryImpl")))
@interface DCAPICancellationRepositoryImpl : DCAPIBase
- (instancetype)initWithCancellationDao:(id<DCAPIData_container_dataCancellationDao>)cancellationDao authorizationDao:(id<DCAPIData_container_dataAuthorizationDao>)authorizationDao transactionDao:(id<DCAPIData_container_dataTransactionDao>)transactionDao __attribute__((swift_name("init(cancellationDao:authorizationDao:transactionDao:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCancellationsTransactionId:(int64_t)transactionId __attribute__((swift_name("getCancellations(transactionId:)")));
- (id _Nullable)getCancellationsAtk:(NSString *)atk __attribute__((swift_name("getCancellations(atk:)")));
- (id _Nullable)getCancellationsQueryTransactionId:(int64_t)transactionId __attribute__((swift_name("getCancellationsQuery(transactionId:)")));
- (id _Nullable)getCancellationsQueryAtk:(NSString *)atk __attribute__((swift_name("getCancellationsQuery(atk:)")));
- (id _Nullable)saveCancelCancellation:(DCAPICancellation *)cancellation __attribute__((swift_name("saveCancel(cancellation:)")));
- (id _Nullable)saveVoucherCancelCancellation:(DCAPICancellation *)cancellation cardBalance:(NSString *)cardBalance __attribute__((swift_name("saveVoucherCancel(cancellation:cardBalance:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Capture")))
@interface DCAPICapture : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId amount:(NSString *)amount date:(DCAPIKotlinx_datetimeLocalDateTime *)date __attribute__((swift_name("init(transactionId:amount:date:)"))) __attribute__((objc_designated_initializer));
- (DCAPICapture *)doCopyTransactionId:(int64_t)transactionId amount:(NSString *)amount date:(DCAPIKotlinx_datetimeLocalDateTime *)date __attribute__((swift_name("doCopy(transactionId:amount:date:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *date __attribute__((swift_name("date")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((swift_name("CaptureApi")))
@protocol DCAPICaptureApi
@required
- (id _Nullable)getCaptureTransactionId:(int64_t)transactionId __attribute__((swift_name("getCapture(transactionId:)")));
- (id _Nullable)getCapturesByTransactionIdTransactionId:(int64_t)transactionId __attribute__((swift_name("getCapturesByTransactionId(transactionId:)")));
- (id _Nullable)getManualCaptureRequiredTransactions __attribute__((swift_name("getManualCaptureRequiredTransactions()")));
- (id _Nullable)getManualCaptureRequiredTransactionsPanLastFourDigits:(NSString *)panLastFourDigits __attribute__((swift_name("getManualCaptureRequiredTransactions(panLastFourDigits:)")));
- (id _Nullable)getManualCaptureRequiredTransactionsStartDate:(DCAPIKotlinx_datetimeLocalDateTime *)startDate endDate:(DCAPIKotlinx_datetimeLocalDateTime *)endDate __attribute__((swift_name("getManualCaptureRequiredTransactions(startDate:endDate:)")));
- (id _Nullable)getManualCaptureRequiredTransactionsHistoric __attribute__((swift_name("getManualCaptureRequiredTransactionsHistoric()")));
- (id _Nullable)getManualCaptureRequiredTransactionsHistoricPanLastFourDigits:(NSString *)panLastFourDigits __attribute__((swift_name("getManualCaptureRequiredTransactionsHistoric(panLastFourDigits:)")));
- (id _Nullable)getManualCaptureRequiredTransactionsHistoricStartDate:(DCAPIKotlinx_datetimeLocalDateTime *)startDate endDate:(DCAPIKotlinx_datetimeLocalDateTime *)endDate __attribute__((swift_name("getManualCaptureRequiredTransactionsHistoric(startDate:endDate:)")));
- (id _Nullable)getNotCapturedApprovedTransactions __attribute__((swift_name("getNotCapturedApprovedTransactions()")));
- (id _Nullable)saveCaptureCapture:(DCAPICapture *)capture __attribute__((swift_name("saveCapture(capture:)")));
- (id _Nullable)saveCaptureCaptureRequest:(DCAPICaptureRequest *)captureRequest __attribute__((swift_name("saveCapture(captureRequest:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CaptureQuery")))
@interface DCAPICaptureQuery : DCAPIBase
- (instancetype)initWithId:(int64_t)id transactionId:(int64_t)transactionId amount:(NSString *)amount date:(DCAPIKotlinx_datetimeLocalDateTime *)date __attribute__((swift_name("init(id:transactionId:amount:date:)"))) __attribute__((objc_designated_initializer));
- (DCAPICaptureQuery *)doCopyId:(int64_t)id transactionId:(int64_t)transactionId amount:(NSString *)amount date:(DCAPIKotlinx_datetimeLocalDateTime *)date __attribute__((swift_name("doCopy(id:transactionId:amount:date:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *date __attribute__((swift_name("date")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CaptureRepositoryImpl")))
@interface DCAPICaptureRepositoryImpl : DCAPIBase
- (instancetype)initWithCaptureRequestDao:(id<DCAPIData_container_dataCaptureRequestDao>)captureRequestDao transactionToCaptureDao:(id<DCAPIData_container_dataTransactionToCaptureDao>)transactionToCaptureDao historicTransactionDao:(id<DCAPIData_container_dataHistoricTransactionDao>)historicTransactionDao captureDao:(id<DCAPIData_container_dataCaptureDao>)captureDao __attribute__((swift_name("init(captureRequestDao:transactionToCaptureDao:historicTransactionDao:captureDao:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCaptureTransactionId:(int64_t)transactionId __attribute__((swift_name("getCapture(transactionId:)")));
- (id _Nullable)getCapturesByTransactionIdTransactionId:(int64_t)transactionId __attribute__((swift_name("getCapturesByTransactionId(transactionId:)")));
- (id _Nullable)getManualCaptureRequiredTransactions __attribute__((swift_name("getManualCaptureRequiredTransactions()")));
- (id _Nullable)getManualCaptureRequiredTransactionsPanLastFourDigits:(NSString *)panLastFourDigits __attribute__((swift_name("getManualCaptureRequiredTransactions(panLastFourDigits:)")));
- (id _Nullable)getManualCaptureRequiredTransactionsStartDate:(DCAPIKotlinx_datetimeLocalDateTime *)startDate endDate:(DCAPIKotlinx_datetimeLocalDateTime *)endDate __attribute__((swift_name("getManualCaptureRequiredTransactions(startDate:endDate:)")));
- (id _Nullable)getManualCaptureRequiredTransactionsHistoric __attribute__((swift_name("getManualCaptureRequiredTransactionsHistoric()")));
- (id _Nullable)getManualCaptureRequiredTransactionsHistoricPanLastFourDigits:(NSString *)panLastFourDigits __attribute__((swift_name("getManualCaptureRequiredTransactionsHistoric(panLastFourDigits:)")));
- (id _Nullable)getManualCaptureRequiredTransactionsHistoricStartDate:(DCAPIKotlinx_datetimeLocalDateTime *)startDate endDate:(DCAPIKotlinx_datetimeLocalDateTime *)endDate __attribute__((swift_name("getManualCaptureRequiredTransactionsHistoric(startDate:endDate:)")));
- (id _Nullable)getNotCapturedApprovedTransactions __attribute__((swift_name("getNotCapturedApprovedTransactions()")));
- (id _Nullable)saveCaptureCapture:(DCAPICapture *)capture __attribute__((swift_name("saveCapture(capture:)")));
- (id _Nullable)saveCaptureCaptureRequest:(DCAPICaptureRequest *)captureRequest __attribute__((swift_name("saveCapture(captureRequest:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CaptureRequest")))
@interface DCAPICaptureRequest : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId iccRelatedData:(NSString *)iccRelatedData __attribute__((swift_name("init(transactionId:iccRelatedData:)"))) __attribute__((objc_designated_initializer));
- (DCAPICaptureRequest *)doCopyTransactionId:(int64_t)transactionId iccRelatedData:(NSString *)iccRelatedData __attribute__((swift_name("doCopy(transactionId:iccRelatedData:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *iccRelatedData __attribute__((swift_name("iccRelatedData")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HistoricTransaction")))
@interface DCAPIHistoricTransaction : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId itk:(NSString *)itk amountAuthorized:(NSString *)amountAuthorized atk:(NSString *)atk arqc:(NSString * _Nullable)arqc orderId:(NSString * _Nullable)orderId authorizationCode:(NSString * _Nullable)authorizationCode extendedModality:(NSString * _Nullable)extendedModality reducedModality:(NSString * _Nullable)reducedModality iccRelatedData:(NSString * _Nullable)iccRelatedData transactionType:(NSString * _Nullable)transactionType status:(NSString * _Nullable)status isCaptured:(DCAPIBoolean * _Nullable)isCaptured brandId:(DCAPILong * _Nullable)brandId brandName:(NSString * _Nullable)brandName cardHolderName:(NSString * _Nullable)cardHolderName cardPan:(NSString * _Nullable)cardPan cardEntryMode:(NSString * _Nullable)cardEntryMode amount:(NSString * _Nullable)amount createDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)createDate applicationIdentifier:(NSString * _Nullable)applicationIdentifier applicationLabel:(NSString * _Nullable)applicationLabel stoneCode:(NSString * _Nullable)stoneCode cardCVM:(NSString * _Nullable)cardCVM captureAmountTotal:(NSString * _Nullable)captureAmountTotal __attribute__((swift_name("init(transactionId:itk:amountAuthorized:atk:arqc:orderId:authorizationCode:extendedModality:reducedModality:iccRelatedData:transactionType:status:isCaptured:brandId:brandName:cardHolderName:cardPan:cardEntryMode:amount:createDate:applicationIdentifier:applicationLabel:stoneCode:cardCVM:captureAmountTotal:)"))) __attribute__((objc_designated_initializer));
- (DCAPIHistoricTransaction *)doCopyTransactionId:(int64_t)transactionId itk:(NSString *)itk amountAuthorized:(NSString *)amountAuthorized atk:(NSString *)atk arqc:(NSString * _Nullable)arqc orderId:(NSString * _Nullable)orderId authorizationCode:(NSString * _Nullable)authorizationCode extendedModality:(NSString * _Nullable)extendedModality reducedModality:(NSString * _Nullable)reducedModality iccRelatedData:(NSString * _Nullable)iccRelatedData transactionType:(NSString * _Nullable)transactionType status:(NSString * _Nullable)status isCaptured:(DCAPIBoolean * _Nullable)isCaptured brandId:(DCAPILong * _Nullable)brandId brandName:(NSString * _Nullable)brandName cardHolderName:(NSString * _Nullable)cardHolderName cardPan:(NSString * _Nullable)cardPan cardEntryMode:(NSString * _Nullable)cardEntryMode amount:(NSString * _Nullable)amount createDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)createDate applicationIdentifier:(NSString * _Nullable)applicationIdentifier applicationLabel:(NSString * _Nullable)applicationLabel stoneCode:(NSString * _Nullable)stoneCode cardCVM:(NSString * _Nullable)cardCVM captureAmountTotal:(NSString * _Nullable)captureAmountTotal __attribute__((swift_name("doCopy(transactionId:itk:amountAuthorized:atk:arqc:orderId:authorizationCode:extendedModality:reducedModality:iccRelatedData:transactionType:status:isCaptured:brandId:brandName:cardHolderName:cardPan:cardEntryMode:amount:createDate:applicationIdentifier:applicationLabel:stoneCode:cardCVM:captureAmountTotal:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable amount __attribute__((swift_name("amount")));
@property (readonly) NSString *amountAuthorized __attribute__((swift_name("amountAuthorized")));
@property (readonly) NSString * _Nullable applicationIdentifier __attribute__((swift_name("applicationIdentifier")));
@property (readonly) NSString * _Nullable applicationLabel __attribute__((swift_name("applicationLabel")));
@property (readonly) NSString * _Nullable arqc __attribute__((swift_name("arqc")));
@property (readonly) NSString *atk __attribute__((swift_name("atk")));
@property (readonly) NSString * _Nullable authorizationCode __attribute__((swift_name("authorizationCode")));
@property (readonly) DCAPILong * _Nullable brandId __attribute__((swift_name("brandId")));
@property (readonly) NSString * _Nullable brandName __attribute__((swift_name("brandName")));
@property (readonly) NSString * _Nullable captureAmountTotal __attribute__((swift_name("captureAmountTotal")));
@property (readonly) NSString * _Nullable cardCVM __attribute__((swift_name("cardCVM")));
@property (readonly) NSString * _Nullable cardEntryMode __attribute__((swift_name("cardEntryMode")));
@property (readonly) NSString * _Nullable cardHolderName __attribute__((swift_name("cardHolderName")));
@property (readonly) NSString * _Nullable cardPan __attribute__((swift_name("cardPan")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable createDate __attribute__((swift_name("createDate")));
@property (readonly) NSString * _Nullable extendedModality __attribute__((swift_name("extendedModality")));
@property (readonly) NSString * _Nullable iccRelatedData __attribute__((swift_name("iccRelatedData")));
@property (readonly) DCAPIBoolean * _Nullable isCaptured __attribute__((swift_name("isCaptured")));
@property (readonly) NSString *itk __attribute__((swift_name("itk")));
@property (readonly) NSString * _Nullable orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString * _Nullable reducedModality __attribute__((swift_name("reducedModality")));
@property (readonly) NSString * _Nullable status __attribute__((swift_name("status")));
@property (readonly) NSString * _Nullable stoneCode __attribute__((swift_name("stoneCode")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@property (readonly) NSString * _Nullable transactionType __attribute__((swift_name("transactionType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionToCapture")))
@interface DCAPITransactionToCapture : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId itk:(NSString *)itk amountAuthorized:(NSString *)amountAuthorized atk:(NSString *)atk iccRelatedData:(NSString * _Nullable)iccRelatedData transactionType:(NSString * _Nullable)transactionType brandId:(DCAPILong * _Nullable)brandId status:(NSString * _Nullable)status brandName:(NSString * _Nullable)brandName cardHolderName:(NSString * _Nullable)cardHolderName cardPan:(NSString * _Nullable)cardPan cardEntryMode:(NSString * _Nullable)cardEntryMode amount:(NSString * _Nullable)amount createDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)createDate __attribute__((swift_name("init(transactionId:itk:amountAuthorized:atk:iccRelatedData:transactionType:brandId:status:brandName:cardHolderName:cardPan:cardEntryMode:amount:createDate:)"))) __attribute__((objc_designated_initializer));
- (DCAPITransactionToCapture *)doCopyTransactionId:(int64_t)transactionId itk:(NSString *)itk amountAuthorized:(NSString *)amountAuthorized atk:(NSString *)atk iccRelatedData:(NSString * _Nullable)iccRelatedData transactionType:(NSString * _Nullable)transactionType brandId:(DCAPILong * _Nullable)brandId status:(NSString * _Nullable)status brandName:(NSString * _Nullable)brandName cardHolderName:(NSString * _Nullable)cardHolderName cardPan:(NSString * _Nullable)cardPan cardEntryMode:(NSString * _Nullable)cardEntryMode amount:(NSString * _Nullable)amount createDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)createDate __attribute__((swift_name("doCopy(transactionId:itk:amountAuthorized:atk:iccRelatedData:transactionType:brandId:status:brandName:cardHolderName:cardPan:cardEntryMode:amount:createDate:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable amount __attribute__((swift_name("amount")));
@property (readonly) NSString *amountAuthorized __attribute__((swift_name("amountAuthorized")));
@property (readonly) NSString *atk __attribute__((swift_name("atk")));
@property (readonly) DCAPILong * _Nullable brandId __attribute__((swift_name("brandId")));
@property (readonly) NSString * _Nullable brandName __attribute__((swift_name("brandName")));
@property (readonly) NSString * _Nullable cardEntryMode __attribute__((swift_name("cardEntryMode")));
@property (readonly) NSString * _Nullable cardHolderName __attribute__((swift_name("cardHolderName")));
@property (readonly) NSString * _Nullable cardPan __attribute__((swift_name("cardPan")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable createDate __attribute__((swift_name("createDate")));
@property (readonly) NSString * _Nullable iccRelatedData __attribute__((swift_name("iccRelatedData")));
@property (readonly) NSString *itk __attribute__((swift_name("itk")));
@property (readonly) NSString * _Nullable status __attribute__((swift_name("status")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@property (readonly) NSString * _Nullable transactionType __attribute__((swift_name("transactionType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Credentials")))
@interface DCAPICredentials : DCAPIBase
- (instancetype)initWithCredentialsAffiliationCode:(NSString *)credentialsAffiliationCode userName:(NSString *)userName password:(NSString *)password clientId:(NSString *)clientId clientSecret:(NSString *)clientSecret __attribute__((swift_name("init(credentialsAffiliationCode:userName:password:clientId:clientSecret:)"))) __attribute__((objc_designated_initializer));
- (DCAPICredentials *)doCopyCredentialsAffiliationCode:(NSString *)credentialsAffiliationCode userName:(NSString *)userName password:(NSString *)password clientId:(NSString *)clientId clientSecret:(NSString *)clientSecret __attribute__((swift_name("doCopy(credentialsAffiliationCode:userName:password:clientId:clientSecret:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *clientId __attribute__((swift_name("clientId")));
@property (readonly) NSString *clientSecret __attribute__((swift_name("clientSecret")));
@property (readonly) NSString *credentialsAffiliationCode __attribute__((swift_name("credentialsAffiliationCode")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@property (readonly) NSString *userName __attribute__((swift_name("userName")));
@end

__attribute__((swift_name("CredentialsApi")))
@protocol DCAPICredentialsApi
@required
- (id _Nullable)getCredentialsByAffiliationCodeAffiliationCode:(NSString *)affiliationCode __attribute__((swift_name("getCredentialsByAffiliationCode(affiliationCode:)")));
- (id _Nullable)saveCredentialsCredentialsCommand:(DCAPICredentialsCommand *)credentialsCommand __attribute__((swift_name("saveCredentials(credentialsCommand:)")));
- (id _Nullable)updateCredentialsCredentialsCommand:(DCAPICredentialsCommand *)credentialsCommand __attribute__((swift_name("updateCredentials(credentialsCommand:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CredentialsCommand")))
@interface DCAPICredentialsCommand : DCAPIBase
- (instancetype)initWithCredentialsAffiliationCode:(NSString *)credentialsAffiliationCode userName:(NSString *)userName password:(NSString *)password clientId:(NSString *)clientId clientSecret:(NSString *)clientSecret __attribute__((swift_name("init(credentialsAffiliationCode:userName:password:clientId:clientSecret:)"))) __attribute__((objc_designated_initializer));
- (DCAPICredentialsCommand *)doCopyCredentialsAffiliationCode:(NSString *)credentialsAffiliationCode userName:(NSString *)userName password:(NSString *)password clientId:(NSString *)clientId clientSecret:(NSString *)clientSecret __attribute__((swift_name("doCopy(credentialsAffiliationCode:userName:password:clientId:clientSecret:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *clientId __attribute__((swift_name("clientId")));
@property (readonly) NSString *clientSecret __attribute__((swift_name("clientSecret")));
@property (readonly) NSString *credentialsAffiliationCode __attribute__((swift_name("credentialsAffiliationCode")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@property (readonly) NSString *userName __attribute__((swift_name("userName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CredentialsRepositoryImpl")))
@interface DCAPICredentialsRepositoryImpl : DCAPIBase
- (instancetype)initWithCredentialsDao:(id<DCAPIData_container_dataCredentialsDao>)credentialsDao __attribute__((swift_name("init(credentialsDao:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCredentialsByAffiliationCodeAffiliationCode:(NSString *)affiliationCode __attribute__((swift_name("getCredentialsByAffiliationCode(affiliationCode:)")));
- (id _Nullable)saveCredentialsCredentialsCommand:(DCAPICredentialsCommand *)credentialsCommand __attribute__((swift_name("saveCredentials(credentialsCommand:)")));
- (id _Nullable)updateCredentialsCredentialsCommand:(DCAPICredentialsCommand *)credentialsCommand __attribute__((swift_name("updateCredentials(credentialsCommand:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Dcc")))
@interface DCAPIDcc : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId cancellationId:(DCAPILong * _Nullable)cancellationId currencyCode:(DCAPIInt * _Nullable)currencyCode currencyLabel:(NSString *)currencyLabel exchangeRate:(NSString *)exchangeRate markUpRate:(NSString *)markUpRate convertedAmount:(NSString *)convertedAmount exponent:(NSString * _Nullable)exponent __attribute__((swift_name("init(transactionId:cancellationId:currencyCode:currencyLabel:exchangeRate:markUpRate:convertedAmount:exponent:)"))) __attribute__((objc_designated_initializer));
- (DCAPIDcc *)doCopyTransactionId:(int64_t)transactionId cancellationId:(DCAPILong * _Nullable)cancellationId currencyCode:(DCAPIInt * _Nullable)currencyCode currencyLabel:(NSString *)currencyLabel exchangeRate:(NSString *)exchangeRate markUpRate:(NSString *)markUpRate convertedAmount:(NSString *)convertedAmount exponent:(NSString * _Nullable)exponent __attribute__((swift_name("doCopy(transactionId:cancellationId:currencyCode:currencyLabel:exchangeRate:markUpRate:convertedAmount:exponent:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPILong * _Nullable cancellationId __attribute__((swift_name("cancellationId")));
@property (readonly) NSString *convertedAmount __attribute__((swift_name("convertedAmount")));
@property (readonly) DCAPIInt * _Nullable currencyCode __attribute__((swift_name("currencyCode")));
@property (readonly) NSString *currencyLabel __attribute__((swift_name("currencyLabel")));
@property (readonly) NSString *exchangeRate __attribute__((swift_name("exchangeRate")));
@property (readonly) NSString * _Nullable exponent __attribute__((swift_name("exponent")));
@property (readonly) NSString *markUpRate __attribute__((swift_name("markUpRate")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((swift_name("DccApi")))
@protocol DCAPIDccApi
@required
- (id _Nullable)getDccByCancellationCancellationId:(int64_t)cancellationId __attribute__((swift_name("getDccByCancellation(cancellationId:)")));
- (id _Nullable)getDccByTransactionTransactionId:(int64_t)transactionId __attribute__((swift_name("getDccByTransaction(transactionId:)")));
- (id _Nullable)saveDccDcc:(DCAPIDcc *)dcc __attribute__((swift_name("saveDcc(dcc:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DccRepositoryImpl")))
@interface DCAPIDccRepositoryImpl : DCAPIBase
- (instancetype)initWithDccDao:(id<DCAPIData_container_dataDccDao>)dccDao __attribute__((swift_name("init(dccDao:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getDccByCancellationCancellationId:(int64_t)cancellationId __attribute__((swift_name("getDccByCancellation(cancellationId:)")));
- (id _Nullable)getDccByTransactionTransactionId:(int64_t)transactionId __attribute__((swift_name("getDccByTransaction(transactionId:)")));
- (id _Nullable)saveDccDcc:(DCAPIDcc *)dcc __attribute__((swift_name("saveDcc(dcc:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorInformation")))
@interface DCAPIErrorInformation : DCAPIBase
- (instancetype)initWithCode:(NSString *)code transactionId:(int64_t)transactionId message:(NSString *)message dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime __attribute__((swift_name("init(code:transactionId:message:dateTime:)"))) __attribute__((objc_designated_initializer));
- (DCAPIErrorInformation *)doCopyCode:(NSString *)code transactionId:(int64_t)transactionId message:(NSString *)message dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime __attribute__((swift_name("doCopy(code:transactionId:message:dateTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *code __attribute__((swift_name("code")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((swift_name("ErrorInformationApi")))
@protocol DCAPIErrorInformationApi
@required
- (id _Nullable)getErrorInformationStartDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)startDate endDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)endDate limit:(int32_t)limit __attribute__((swift_name("getErrorInformation(startDate:endDate:limit:)")));
- (id _Nullable)saveErrorInformationErrorInformation:(DCAPIErrorInformation *)errorInformation __attribute__((swift_name("saveErrorInformation(errorInformation:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorInformationRepositoryImpl")))
@interface DCAPIErrorInformationRepositoryImpl : DCAPIBase
- (instancetype)initWithErrorInformationDao:(id<DCAPIData_container_dataErrorInformationDao>)errorInformationDao __attribute__((swift_name("init(errorInformationDao:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getErrorInformationStartDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)startDate endDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)endDate limit:(int32_t)limit __attribute__((swift_name("getErrorInformation(startDate:endDate:limit:)")));
- (id _Nullable)saveErrorInformationErrorInformation:(DCAPIErrorInformation *)errorInformation __attribute__((swift_name("saveErrorInformation(errorInformation:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Filter")))
@interface DCAPIFilter : DCAPIBase
- (instancetype)initWithColumnsProjection:(DCAPIKotlinArray<NSString *> * _Nullable)columnsProjection whereClause:(NSString * _Nullable)whereClause whereArguments:(DCAPIKotlinArray<NSString *> * _Nullable)whereArguments resultsSorting:(NSString * _Nullable)resultsSorting resultsLimit:(DCAPIInt * _Nullable)resultsLimit resultsOffset:(DCAPIInt * _Nullable)resultsOffset __attribute__((swift_name("init(columnsProjection:whereClause:whereArguments:resultsSorting:resultsLimit:resultsOffset:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) DCAPIFilterSORTING *companion __attribute__((swift_name("companion")));
- (DCAPIFilter *)doCopyColumnsProjection:(DCAPIKotlinArray<NSString *> * _Nullable)columnsProjection whereClause:(NSString * _Nullable)whereClause whereArguments:(DCAPIKotlinArray<NSString *> * _Nullable)whereArguments resultsSorting:(NSString * _Nullable)resultsSorting resultsLimit:(DCAPIInt * _Nullable)resultsLimit resultsOffset:(DCAPIInt * _Nullable)resultsOffset __attribute__((swift_name("doCopy(columnsProjection:whereClause:whereArguments:resultsSorting:resultsLimit:resultsOffset:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPIKotlinArray<NSString *> * _Nullable columnsProjection __attribute__((swift_name("columnsProjection")));
@property (readonly) DCAPIInt * _Nullable resultsLimit __attribute__((swift_name("resultsLimit")));
@property (readonly) DCAPIInt * _Nullable resultsOffset __attribute__((swift_name("resultsOffset")));
@property (readonly) NSString * _Nullable resultsSorting __attribute__((swift_name("resultsSorting")));
@property (readonly) DCAPIKotlinArray<NSString *> * _Nullable whereArguments __attribute__((swift_name("whereArguments")));
@property (readonly) NSString * _Nullable whereClause __attribute__((swift_name("whereClause")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Filter.SORTING")))
@interface DCAPIFilterSORTING : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sORTING __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPIFilterSORTING *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *ASC __attribute__((swift_name("ASC")));
@property (readonly) NSString *DESC __attribute__((swift_name("DESC")));
@end

__attribute__((swift_name("FullReceiptApi")))
@protocol DCAPIFullReceiptApi
@required
- (id _Nullable)getAllReceipt __attribute__((swift_name("getAllReceipt()")));
- (id _Nullable)getReceiptDetailsReceiptId:(int64_t)receiptId __attribute__((swift_name("getReceiptDetails(receiptId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FullReceiptQuery")))
@interface DCAPIFullReceiptQuery : DCAPIBase
- (instancetype)initWithId:(int64_t)id companyAddressCity:(NSString *)companyAddressCity companyAddressState:(NSString *)companyAddressState companyTaxType:(NSString *)companyTaxType companyTaxNumber:(NSString *)companyTaxNumber companyName:(NSString *)companyName aut:(NSString *)aut arqc:(NSString *)arqc aid:(NSString *)aid cardName:(NSString *)cardName stoneId:(NSString *)stoneId transactionStatus:(NSString *)transactionStatus __attribute__((swift_name("init(id:companyAddressCity:companyAddressState:companyTaxType:companyTaxNumber:companyName:aut:arqc:aid:cardName:stoneId:transactionStatus:)"))) __attribute__((objc_designated_initializer));
- (DCAPIFullReceiptQuery *)doCopyId:(int64_t)id companyAddressCity:(NSString *)companyAddressCity companyAddressState:(NSString *)companyAddressState companyTaxType:(NSString *)companyTaxType companyTaxNumber:(NSString *)companyTaxNumber companyName:(NSString *)companyName aut:(NSString *)aut arqc:(NSString *)arqc aid:(NSString *)aid cardName:(NSString *)cardName stoneId:(NSString *)stoneId transactionStatus:(NSString *)transactionStatus __attribute__((swift_name("doCopy(id:companyAddressCity:companyAddressState:companyTaxType:companyTaxNumber:companyName:aut:arqc:aid:cardName:stoneId:transactionStatus:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *aid __attribute__((swift_name("aid")));
@property (readonly) NSString *arqc __attribute__((swift_name("arqc")));
@property (readonly) NSString *aut __attribute__((swift_name("aut")));
@property (readonly) NSString *cardName __attribute__((swift_name("cardName")));
@property (readonly) NSString *companyAddressCity __attribute__((swift_name("companyAddressCity")));
@property (readonly) NSString *companyAddressState __attribute__((swift_name("companyAddressState")));
@property (readonly) NSString *companyName __attribute__((swift_name("companyName")));
@property (readonly) NSString *companyTaxNumber __attribute__((swift_name("companyTaxNumber")));
@property (readonly) NSString *companyTaxType __attribute__((swift_name("companyTaxType")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) NSString *stoneId __attribute__((swift_name("stoneId")));
@property (readonly) NSString *transactionStatus __attribute__((swift_name("transactionStatus")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FullReceiptRepositoryImpl")))
@interface DCAPIFullReceiptRepositoryImpl : DCAPIBase
- (instancetype)initWithFullReceiptDao:(id<DCAPIData_container_dataFullReceiptDao>)fullReceiptDao __attribute__((swift_name("init(fullReceiptDao:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getAllReceipt __attribute__((swift_name("getAllReceipt()")));
- (id _Nullable)getReceiptDetailsReceiptId:(int64_t)receiptId __attribute__((swift_name("getReceiptDetails(receiptId:)")));
@end

__attribute__((swift_name("FullTransactionApi")))
@protocol DCAPIFullTransactionApi
@required
- (id _Nullable)getAllTransactions __attribute__((swift_name("getAllTransactions()")));
- (id _Nullable)getFullTransactionByATKAtk:(NSString *)atk __attribute__((swift_name("getFullTransactionByATK(atk:)")));
- (id _Nullable)getFullTransactionByITKItk:(NSString *)itk __attribute__((swift_name("getFullTransactionByITK(itk:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FullTransactionQuery")))
@interface DCAPIFullTransactionQuery : DCAPIBase
- (instancetype)initWithId:(int64_t)id amount:(NSString *)amount authorizedAmount:(NSString * _Nullable)authorizedAmount cancelledAmount:(NSString * _Nullable)cancelledAmount dateTime:(NSString *)dateTime isCapture:(BOOL)isCapture subMerchantMcc:(NSString * _Nullable)subMerchantMcc subMerchantAddress:(DCAPIAddress * _Nullable)subMerchantAddress affiliationCode:(NSString *)affiliationCode cvm:(NSString *)cvm accountBalance:(NSString *)accountBalance cardHolderName:(NSString *)cardHolderName cardHolderNameExtended:(NSString *)cardHolderNameExtended cardHolderEmail:(NSString *)cardHolderEmail cardVoucherType:(DCAPIVoucherType *)cardVoucherType cardServiceCode:(NSString *)cardServiceCode cardAppLabel:(NSString *)cardAppLabel cardPan:(NSString *)cardPan cardBrandName:(NSString *)cardBrandName cardBrandId:(int32_t)cardBrandId orderId:(NSString *)orderId pinpadUsed:(NSString *)pinpadUsed instalmentCount:(int32_t)instalmentCount instalmentType:(DCAPIInstalmentType *)instalmentType transactionReference:(NSString *)transactionReference paymentBusinessModel:(NSString *)paymentBusinessModel signature:(NSString * _Nullable)signature isEmergencyAid:(BOOL)isEmergencyAid appIdentification:(NSString *)appIdentification qualifier:(NSString * _Nullable)qualifier entryMode:(DCAPICardEntryMode *)entryMode transactionStatus:(DCAPIStatus *)transactionStatus transactionType:(DCAPITransactionType *)transactionType authorizationCode:(NSString * _Nullable)authorizationCode atk:(NSString * _Nullable)atk itk:(NSString * _Nullable)itk arqc:(NSString * _Nullable)arqc aid:(NSString *)aid subMerchantTaxNumber:(NSString * _Nullable)subMerchantTaxNumber subMerchantRegisteredIdentifier:(NSString * _Nullable)subMerchantRegisteredIdentifier iccRelatedData:(NSString * _Nullable)iccRelatedData __attribute__((swift_name("init(id:amount:authorizedAmount:cancelledAmount:dateTime:isCapture:subMerchantMcc:subMerchantAddress:affiliationCode:cvm:accountBalance:cardHolderName:cardHolderNameExtended:cardHolderEmail:cardVoucherType:cardServiceCode:cardAppLabel:cardPan:cardBrandName:cardBrandId:orderId:pinpadUsed:instalmentCount:instalmentType:transactionReference:paymentBusinessModel:signature:isEmergencyAid:appIdentification:qualifier:entryMode:transactionStatus:transactionType:authorizationCode:atk:itk:arqc:aid:subMerchantTaxNumber:subMerchantRegisteredIdentifier:iccRelatedData:)"))) __attribute__((objc_designated_initializer));
- (DCAPIFullTransactionQuery *)doCopyId:(int64_t)id amount:(NSString *)amount authorizedAmount:(NSString * _Nullable)authorizedAmount cancelledAmount:(NSString * _Nullable)cancelledAmount dateTime:(NSString *)dateTime isCapture:(BOOL)isCapture subMerchantMcc:(NSString * _Nullable)subMerchantMcc subMerchantAddress:(DCAPIAddress * _Nullable)subMerchantAddress affiliationCode:(NSString *)affiliationCode cvm:(NSString *)cvm accountBalance:(NSString *)accountBalance cardHolderName:(NSString *)cardHolderName cardHolderNameExtended:(NSString *)cardHolderNameExtended cardHolderEmail:(NSString *)cardHolderEmail cardVoucherType:(DCAPIVoucherType *)cardVoucherType cardServiceCode:(NSString *)cardServiceCode cardAppLabel:(NSString *)cardAppLabel cardPan:(NSString *)cardPan cardBrandName:(NSString *)cardBrandName cardBrandId:(int32_t)cardBrandId orderId:(NSString *)orderId pinpadUsed:(NSString *)pinpadUsed instalmentCount:(int32_t)instalmentCount instalmentType:(DCAPIInstalmentType *)instalmentType transactionReference:(NSString *)transactionReference paymentBusinessModel:(NSString *)paymentBusinessModel signature:(NSString * _Nullable)signature isEmergencyAid:(BOOL)isEmergencyAid appIdentification:(NSString *)appIdentification qualifier:(NSString * _Nullable)qualifier entryMode:(DCAPICardEntryMode *)entryMode transactionStatus:(DCAPIStatus *)transactionStatus transactionType:(DCAPITransactionType *)transactionType authorizationCode:(NSString * _Nullable)authorizationCode atk:(NSString * _Nullable)atk itk:(NSString * _Nullable)itk arqc:(NSString * _Nullable)arqc aid:(NSString *)aid subMerchantTaxNumber:(NSString * _Nullable)subMerchantTaxNumber subMerchantRegisteredIdentifier:(NSString * _Nullable)subMerchantRegisteredIdentifier iccRelatedData:(NSString * _Nullable)iccRelatedData __attribute__((swift_name("doCopy(id:amount:authorizedAmount:cancelledAmount:dateTime:isCapture:subMerchantMcc:subMerchantAddress:affiliationCode:cvm:accountBalance:cardHolderName:cardHolderNameExtended:cardHolderEmail:cardVoucherType:cardServiceCode:cardAppLabel:cardPan:cardBrandName:cardBrandId:orderId:pinpadUsed:instalmentCount:instalmentType:transactionReference:paymentBusinessModel:signature:isEmergencyAid:appIdentification:qualifier:entryMode:transactionStatus:transactionType:authorizationCode:atk:itk:arqc:aid:subMerchantTaxNumber:subMerchantRegisteredIdentifier:iccRelatedData:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountBalance __attribute__((swift_name("accountBalance")));
@property (readonly) NSString *affiliationCode __attribute__((swift_name("affiliationCode")));
@property (readonly) NSString *aid __attribute__((swift_name("aid")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) NSString *appIdentification __attribute__((swift_name("appIdentification")));
@property (readonly) NSString * _Nullable arqc __attribute__((swift_name("arqc")));
@property (readonly) NSString * _Nullable atk __attribute__((swift_name("atk")));
@property (readonly) NSString * _Nullable authorizationCode __attribute__((swift_name("authorizationCode")));
@property (readonly) NSString * _Nullable authorizedAmount __attribute__((swift_name("authorizedAmount")));
@property (readonly) NSString * _Nullable cancelledAmount __attribute__((swift_name("cancelledAmount")));
@property (readonly) NSString *cardAppLabel __attribute__((swift_name("cardAppLabel")));
@property (readonly) int32_t cardBrandId __attribute__((swift_name("cardBrandId")));
@property (readonly) NSString *cardBrandName __attribute__((swift_name("cardBrandName")));
@property (readonly) NSString *cardHolderEmail __attribute__((swift_name("cardHolderEmail")));
@property (readonly) NSString *cardHolderName __attribute__((swift_name("cardHolderName")));
@property (readonly) NSString *cardHolderNameExtended __attribute__((swift_name("cardHolderNameExtended")));
@property (readonly) NSString *cardPan __attribute__((swift_name("cardPan")));
@property (readonly) NSString *cardServiceCode __attribute__((swift_name("cardServiceCode")));
@property (readonly) DCAPIVoucherType *cardVoucherType __attribute__((swift_name("cardVoucherType")));
@property (readonly) NSString *cvm __attribute__((swift_name("cvm")));
@property (readonly) NSString *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) DCAPICardEntryMode *entryMode __attribute__((swift_name("entryMode")));
@property (readonly) NSString * _Nullable iccRelatedData __attribute__((swift_name("iccRelatedData")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) int32_t instalmentCount __attribute__((swift_name("instalmentCount")));
@property (readonly) DCAPIInstalmentType *instalmentType __attribute__((swift_name("instalmentType")));
@property (readonly) BOOL isCapture __attribute__((swift_name("isCapture")));
@property (readonly) BOOL isEmergencyAid __attribute__((swift_name("isEmergencyAid")));
@property (readonly) NSString * _Nullable itk __attribute__((swift_name("itk")));
@property (readonly) NSString *orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString *paymentBusinessModel __attribute__((swift_name("paymentBusinessModel")));
@property (readonly) NSString *pinpadUsed __attribute__((swift_name("pinpadUsed")));
@property (readonly) NSString * _Nullable qualifier __attribute__((swift_name("qualifier")));
@property (readonly) NSString * _Nullable signature __attribute__((swift_name("signature")));
@property (readonly) DCAPIAddress * _Nullable subMerchantAddress __attribute__((swift_name("subMerchantAddress")));
@property (readonly) NSString * _Nullable subMerchantMcc __attribute__((swift_name("subMerchantMcc")));
@property (readonly) NSString * _Nullable subMerchantRegisteredIdentifier __attribute__((swift_name("subMerchantRegisteredIdentifier")));
@property (readonly) NSString * _Nullable subMerchantTaxNumber __attribute__((swift_name("subMerchantTaxNumber")));
@property (readonly) NSString *transactionReference __attribute__((swift_name("transactionReference")));
@property (readonly) DCAPIStatus *transactionStatus __attribute__((swift_name("transactionStatus")));
@property (readonly) DCAPITransactionType *transactionType __attribute__((swift_name("transactionType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Customer")))
@interface DCAPICustomer : DCAPIBase
- (instancetype)initWithAccountholderName:(NSString *)accountholderName accountholderNumber:(NSString *)accountholderNumber walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName __attribute__((swift_name("init(accountholderName:accountholderNumber:walletProviderId:walletProviderName:)"))) __attribute__((objc_designated_initializer));
- (DCAPICustomer *)doCopyAccountholderName:(NSString *)accountholderName accountholderNumber:(NSString *)accountholderNumber walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName __attribute__((swift_name("doCopy(accountholderName:accountholderNumber:walletProviderId:walletProviderName:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountholderName __attribute__((swift_name("accountholderName")));
@property (readonly) NSString *accountholderNumber __attribute__((swift_name("accountholderNumber")));
@property (readonly) NSString *walletProviderId __attribute__((swift_name("walletProviderId")));
@property (readonly) NSString *walletProviderName __attribute__((swift_name("walletProviderName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InstantPayment")))
@interface DCAPIInstantPayment : DCAPIBase
- (instancetype)initWithId:(NSString * _Nullable)id amount:(NSString * _Nullable)amount fee:(DCAPIInt * _Nullable)fee createdAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)createdAt approvedAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)approvedAt refusedAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)refusedAt paymentId:(NSString * _Nullable)paymentId __attribute__((swift_name("init(id:amount:fee:createdAt:approvedAt:refusedAt:paymentId:)"))) __attribute__((objc_designated_initializer));
- (DCAPIInstantPayment *)doCopyId:(NSString * _Nullable)id amount:(NSString * _Nullable)amount fee:(DCAPIInt * _Nullable)fee createdAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)createdAt approvedAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)approvedAt refusedAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)refusedAt paymentId:(NSString * _Nullable)paymentId __attribute__((swift_name("doCopy(id:amount:fee:createdAt:approvedAt:refusedAt:paymentId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable amount __attribute__((swift_name("amount")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable approvedAt __attribute__((swift_name("approvedAt")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property (readonly) DCAPIInt * _Nullable fee __attribute__((swift_name("fee")));
@property (readonly) NSString * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString * _Nullable paymentId __attribute__((swift_name("paymentId")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable refusedAt __attribute__((swift_name("refusedAt")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Invoice")))
@interface DCAPIInvoice : DCAPIBase
- (instancetype)initWithPaymentOrderId:(NSString *)paymentOrderId transactionId:(int64_t)transactionId paymentType:(NSString *)paymentType amount:(NSString *)amount currency:(int32_t)currency walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName createdAt:(DCAPIKotlinx_datetimeLocalDateTime *)createdAt expiresAt:(DCAPIKotlinx_datetimeLocalDateTime *)expiresAt instantPayment:(DCAPIInstantPayment * _Nullable)instantPayment customer:(DCAPICustomer *)customer __attribute__((swift_name("init(paymentOrderId:transactionId:paymentType:amount:currency:walletProviderId:walletProviderName:createdAt:expiresAt:instantPayment:customer:)"))) __attribute__((objc_designated_initializer));
- (DCAPIInvoice *)doCopyPaymentOrderId:(NSString *)paymentOrderId transactionId:(int64_t)transactionId paymentType:(NSString *)paymentType amount:(NSString *)amount currency:(int32_t)currency walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName createdAt:(DCAPIKotlinx_datetimeLocalDateTime *)createdAt expiresAt:(DCAPIKotlinx_datetimeLocalDateTime *)expiresAt instantPayment:(DCAPIInstantPayment * _Nullable)instantPayment customer:(DCAPICustomer *)customer __attribute__((swift_name("doCopy(paymentOrderId:transactionId:paymentType:amount:currency:walletProviderId:walletProviderName:createdAt:expiresAt:instantPayment:customer:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *createdAt __attribute__((swift_name("createdAt")));
@property (readonly) int32_t currency __attribute__((swift_name("currency")));
@property (readonly) DCAPICustomer *customer __attribute__((swift_name("customer")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *expiresAt __attribute__((swift_name("expiresAt")));
@property (readonly) DCAPIInstantPayment * _Nullable instantPayment __attribute__((swift_name("instantPayment")));
@property (readonly) NSString *paymentOrderId __attribute__((swift_name("paymentOrderId")));
@property (readonly) NSString *paymentType __attribute__((swift_name("paymentType")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@property (readonly) NSString *walletProviderId __attribute__((swift_name("walletProviderId")));
@property (readonly) NSString *walletProviderName __attribute__((swift_name("walletProviderName")));
@end

__attribute__((swift_name("InvoiceApi")))
@protocol DCAPIInvoiceApi
@required
- (id _Nullable)getAllInvoicesBetweenDatesDateStart:(DCAPIKotlinx_datetimeLocalDateTime *)dateStart dateEnd:(DCAPIKotlinx_datetimeLocalDateTime *)dateEnd __attribute__((swift_name("getAllInvoicesBetweenDates(dateStart:dateEnd:)")));
- (id _Nullable)getInvoiceInvoiceId:(int64_t)invoiceId __attribute__((swift_name("getInvoice(invoiceId:)")));
- (id _Nullable)getInvoiceByTransactionIdTransactionId:(int64_t)transactionId __attribute__((swift_name("getInvoiceByTransactionId(transactionId:)")));
- (id _Nullable)saveInvoiceInvoice:(DCAPIInvoice *)invoice __attribute__((swift_name("saveInvoice(invoice:)")));
- (id _Nullable)updateInvoiceInvoiceId:(int64_t)invoiceId invoice:(DCAPIInvoice *)invoice __attribute__((swift_name("updateInvoice(invoiceId:invoice:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InvoiceRepositoryImpl")))
@interface DCAPIInvoiceRepositoryImpl : DCAPIBase
- (instancetype)initWithInvoiceDao:(id<DCAPIData_container_dataInvoiceDao>)invoiceDao __attribute__((swift_name("init(invoiceDao:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getAllInvoicesBetweenDatesDateStart:(DCAPIKotlinx_datetimeLocalDateTime *)dateStart dateEnd:(DCAPIKotlinx_datetimeLocalDateTime *)dateEnd __attribute__((swift_name("getAllInvoicesBetweenDates(dateStart:dateEnd:)")));
- (id _Nullable)getInvoiceInvoiceId:(int64_t)invoiceId __attribute__((swift_name("getInvoice(invoiceId:)")));
- (id _Nullable)getInvoiceByTransactionIdTransactionId:(int64_t)transactionId __attribute__((swift_name("getInvoiceByTransactionId(transactionId:)")));
- (id _Nullable)saveInvoiceInvoice:(DCAPIInvoice *)invoice __attribute__((swift_name("saveInvoice(invoice:)")));
- (id _Nullable)updateInvoiceInvoiceId:(int64_t)invoiceId invoice:(DCAPIInvoice *)invoice __attribute__((swift_name("updateInvoice(invoiceId:invoice:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Address")))
@interface DCAPIAddress : DCAPIBase
- (instancetype)initWithStreet:(NSString *)street number:(NSString *)number complement:(NSString *)complement neighborhood:(NSString *)neighborhood zipCode:(NSString *)zipCode city:(NSString *)city state:(NSString *)state __attribute__((swift_name("init(street:number:complement:neighborhood:zipCode:city:state:)"))) __attribute__((objc_designated_initializer));
- (DCAPIAddress *)doCopyStreet:(NSString *)street number:(NSString *)number complement:(NSString *)complement neighborhood:(NSString *)neighborhood zipCode:(NSString *)zipCode city:(NSString *)city state:(NSString *)state __attribute__((swift_name("doCopy(street:number:complement:neighborhood:zipCode:city:state:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *city __attribute__((swift_name("city")));
@property (readonly) NSString *complement __attribute__((swift_name("complement")));
@property (readonly) NSString *neighborhood __attribute__((swift_name("neighborhood")));
@property (readonly) NSString *number __attribute__((swift_name("number")));
@property (readonly) NSString *state __attribute__((swift_name("state")));
@property (readonly) NSString *street __attribute__((swift_name("street")));
@property (readonly) NSString *zipCode __attribute__((swift_name("zipCode")));
@end

__attribute__((swift_name("MerchantApi")))
@protocol DCAPIMerchantApi
@required
- (id _Nullable)deleteAllMerchants __attribute__((swift_name("deleteAllMerchants()")));
- (id _Nullable)deleteMerchantStoneCode:(NSString *)stoneCode __attribute__((swift_name("deleteMerchant(stoneCode:)")));
- (id _Nullable)getAllMerchants __attribute__((swift_name("getAllMerchants()")));
- (id _Nullable)getAllMerchantsOrNull __attribute__((swift_name("getAllMerchantsOrNull()")));
- (id _Nullable)getFirstMerchant __attribute__((swift_name("getFirstMerchant()")));
- (id _Nullable)getMerchantStoneCode:(NSString *)stoneCode __attribute__((swift_name("getMerchant(stoneCode:)")));
- (id _Nullable)getSubMerchantsParentStoneCode:(NSString *)parentStoneCode __attribute__((swift_name("getSubMerchants(parentStoneCode:)")));
- (id _Nullable)saveMerchantMerchant:(DCAPIMerchantCommand *)merchant __attribute__((swift_name("saveMerchant(merchant:)")));
- (id _Nullable)saveSubMerchantSubMerchant:(DCAPISubMerchantCommand *)subMerchant __attribute__((swift_name("saveSubMerchant(subMerchant:)")));
- (id _Nullable)updateAffiliationCodeOlderAffiliationCode:(NSString *)olderAffiliationCode newAffiliationCode:(NSString *)newAffiliationCode __attribute__((swift_name("updateAffiliationCode(olderAffiliationCode:newAffiliationCode:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MerchantCommand")))
@interface DCAPIMerchantCommand : DCAPIBase
- (instancetype)initWithStoneCode:(NSString *)stoneCode sak:(NSString *)sak displayName:(NSString *)displayName affiliationKey:(NSString *)affiliationKey mcc:(NSString *)mcc taxIdentificationType:(DCAPIData_container_contractTaxIdentificationType *)taxIdentificationType taxIdentificationNumber:(NSString *)taxIdentificationNumber currencyCode:(NSString *)currencyCode phoneNumber:(NSString *)phoneNumber email:(NSString *)email address:(DCAPIAddress *)address acquirerCode:(NSString *)acquirerCode cardBrands:(NSArray<DCAPIData_container_contractCardBrand *> *)cardBrands legalName:(NSString *)legalName pixAccount:(DCAPIPixAccount * _Nullable)pixAccount __attribute__((swift_name("init(stoneCode:sak:displayName:affiliationKey:mcc:taxIdentificationType:taxIdentificationNumber:currencyCode:phoneNumber:email:address:acquirerCode:cardBrands:legalName:pixAccount:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) DCAPIMerchantCommandCompanion *companion __attribute__((swift_name("companion")));
- (DCAPIMerchantCommand *)doCopyStoneCode:(NSString *)stoneCode sak:(NSString *)sak displayName:(NSString *)displayName affiliationKey:(NSString *)affiliationKey mcc:(NSString *)mcc taxIdentificationType:(DCAPIData_container_contractTaxIdentificationType *)taxIdentificationType taxIdentificationNumber:(NSString *)taxIdentificationNumber currencyCode:(NSString *)currencyCode phoneNumber:(NSString *)phoneNumber email:(NSString *)email address:(DCAPIAddress *)address acquirerCode:(NSString *)acquirerCode cardBrands:(NSArray<DCAPIData_container_contractCardBrand *> *)cardBrands legalName:(NSString *)legalName pixAccount:(DCAPIPixAccount * _Nullable)pixAccount __attribute__((swift_name("doCopy(stoneCode:sak:displayName:affiliationKey:mcc:taxIdentificationType:taxIdentificationNumber:currencyCode:phoneNumber:email:address:acquirerCode:cardBrands:legalName:pixAccount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *acquirerCode __attribute__((swift_name("acquirerCode")));
@property (readonly) DCAPIAddress *address __attribute__((swift_name("address")));
@property (readonly) NSString *affiliationKey __attribute__((swift_name("affiliationKey")));
@property (readonly) NSArray<DCAPIData_container_contractCardBrand *> *cardBrands __attribute__((swift_name("cardBrands")));
@property (readonly) NSString *currencyCode __attribute__((swift_name("currencyCode")));
@property (readonly) NSString *displayName __attribute__((swift_name("displayName")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString *legalName __attribute__((swift_name("legalName")));
@property (readonly) NSString *mcc __attribute__((swift_name("mcc")));
@property (readonly) NSString *phoneNumber __attribute__((swift_name("phoneNumber")));
@property (readonly) DCAPIPixAccount * _Nullable pixAccount __attribute__((swift_name("pixAccount")));
@property (readonly) NSString *sak __attribute__((swift_name("sak")));
@property (readonly) NSString *stoneCode __attribute__((swift_name("stoneCode")));
@property (readonly) NSString *taxIdentificationNumber __attribute__((swift_name("taxIdentificationNumber")));
@property (readonly) DCAPIData_container_contractTaxIdentificationType *taxIdentificationType __attribute__((swift_name("taxIdentificationType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MerchantCommand.Companion")))
@interface DCAPIMerchantCommandCompanion : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPIMerchantCommandCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *DEFAULT_ACQUIRER_CODE __attribute__((swift_name("DEFAULT_ACQUIRER_CODE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MerchantQuery")))
@interface DCAPIMerchantQuery : DCAPIBase
- (instancetype)initWithId:(int64_t)id acquirerCode:(NSString *)acquirerCode stoneCode:(NSString *)stoneCode sak:(NSString *)sak displayName:(NSString *)displayName mcc:(NSString *)mcc taxIdentificationType:(DCAPIData_container_contractTaxIdentificationType *)taxIdentificationType taxIdentificationNumber:(NSString *)taxIdentificationNumber currencyCode:(NSString *)currencyCode phoneNumber:(NSString *)phoneNumber email:(NSString *)email shortName:(NSString *)shortName address:(DCAPIAddress *)address cardBrands:(NSArray<DCAPIData_container_contractCardBrand *> *)cardBrands affiliationKey:(NSString *)affiliationKey legalName:(NSString *)legalName pixAvailable:(DCAPIBoolean * _Nullable)pixAvailable pixAccount:(DCAPIPixAccount * _Nullable)pixAccount __attribute__((swift_name("init(id:acquirerCode:stoneCode:sak:displayName:mcc:taxIdentificationType:taxIdentificationNumber:currencyCode:phoneNumber:email:shortName:address:cardBrands:affiliationKey:legalName:pixAvailable:pixAccount:)"))) __attribute__((objc_designated_initializer));
- (DCAPIMerchantQuery *)doCopyId:(int64_t)id acquirerCode:(NSString *)acquirerCode stoneCode:(NSString *)stoneCode sak:(NSString *)sak displayName:(NSString *)displayName mcc:(NSString *)mcc taxIdentificationType:(DCAPIData_container_contractTaxIdentificationType *)taxIdentificationType taxIdentificationNumber:(NSString *)taxIdentificationNumber currencyCode:(NSString *)currencyCode phoneNumber:(NSString *)phoneNumber email:(NSString *)email shortName:(NSString *)shortName address:(DCAPIAddress *)address cardBrands:(NSArray<DCAPIData_container_contractCardBrand *> *)cardBrands affiliationKey:(NSString *)affiliationKey legalName:(NSString *)legalName pixAvailable:(DCAPIBoolean * _Nullable)pixAvailable pixAccount:(DCAPIPixAccount * _Nullable)pixAccount __attribute__((swift_name("doCopy(id:acquirerCode:stoneCode:sak:displayName:mcc:taxIdentificationType:taxIdentificationNumber:currencyCode:phoneNumber:email:shortName:address:cardBrands:affiliationKey:legalName:pixAvailable:pixAccount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *acquirerCode __attribute__((swift_name("acquirerCode")));
@property (readonly) DCAPIAddress *address __attribute__((swift_name("address")));
@property (readonly) NSString *affiliationKey __attribute__((swift_name("affiliationKey")));
@property (readonly) NSArray<DCAPIData_container_contractCardBrand *> *cardBrands __attribute__((swift_name("cardBrands")));
@property (readonly) NSString *currencyCode __attribute__((swift_name("currencyCode")));
@property (readonly) NSString *displayName __attribute__((swift_name("displayName")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) NSString *legalName __attribute__((swift_name("legalName")));
@property (readonly) NSString *mcc __attribute__((swift_name("mcc")));
@property (readonly) NSString *phoneNumber __attribute__((swift_name("phoneNumber")));
@property (readonly) DCAPIPixAccount * _Nullable pixAccount __attribute__((swift_name("pixAccount")));
@property (readonly) DCAPIBoolean * _Nullable pixAvailable __attribute__((swift_name("pixAvailable"))) __attribute__((deprecated("use pixAccount.isAvailable instead")));
@property (readonly) NSString *sak __attribute__((swift_name("sak")));
@property (readonly) NSString *shortName __attribute__((swift_name("shortName"))) __attribute__((deprecated("Use displayName instead")));
@property (readonly) NSString *stoneCode __attribute__((swift_name("stoneCode")));
@property (readonly) NSString *taxIdentificationNumber __attribute__((swift_name("taxIdentificationNumber")));
@property (readonly) DCAPIData_container_contractTaxIdentificationType *taxIdentificationType __attribute__((swift_name("taxIdentificationType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MerchantRepositoryImpl")))
@interface DCAPIMerchantRepositoryImpl : DCAPIBase
- (instancetype)initWithMerchantDao:(id<DCAPIData_container_dataMerchantDao>)merchantDao subMerchantDao:(id<DCAPIData_container_dataSubMerchantDao>)subMerchantDao database:(DCAPIData_container_dataDataContainerDataBase *)database __attribute__((swift_name("init(merchantDao:subMerchantDao:database:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)deleteAllMerchants __attribute__((swift_name("deleteAllMerchants()")));
- (id _Nullable)deleteMerchantStoneCode:(NSString *)stoneCode __attribute__((swift_name("deleteMerchant(stoneCode:)")));
- (id _Nullable)getAllMerchants __attribute__((swift_name("getAllMerchants()")));
- (id _Nullable)getAllMerchantsOrNull __attribute__((swift_name("getAllMerchantsOrNull()")));
- (id _Nullable)getFirstMerchant __attribute__((swift_name("getFirstMerchant()")));
- (id _Nullable)getMerchantStoneCode:(NSString *)stoneCode __attribute__((swift_name("getMerchant(stoneCode:)")));
- (id _Nullable)getSubMerchantsParentStoneCode:(NSString *)parentStoneCode __attribute__((swift_name("getSubMerchants(parentStoneCode:)")));
- (id _Nullable)saveMerchantMerchant:(DCAPIMerchantCommand *)merchant __attribute__((swift_name("saveMerchant(merchant:)")));
- (id _Nullable)saveSubMerchantSubMerchant:(DCAPISubMerchantCommand *)subMerchant __attribute__((swift_name("saveSubMerchant(subMerchant:)")));
- (BOOL)updateAffiliationCodeOlderAffiliationCode:(NSString *)olderAffiliationCode newAffiliationCode:(NSString *)newAffiliationCode __attribute__((swift_name("updateAffiliationCode(olderAffiliationCode:newAffiliationCode:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PixAccount")))
@interface DCAPIPixAccount : DCAPIBase
- (instancetype)initWithIsAvailable:(BOOL)isAvailable accountNumber:(NSString *)accountNumber branch:(NSString * _Nullable)branch accountId:(NSString *)accountId pixEntry:(NSString * _Nullable)pixEntry email:(NSString * _Nullable)email __attribute__((swift_name("init(isAvailable:accountNumber:branch:accountId:pixEntry:email:)"))) __attribute__((objc_designated_initializer));
- (DCAPIPixAccount *)doCopyIsAvailable:(BOOL)isAvailable accountNumber:(NSString *)accountNumber branch:(NSString * _Nullable)branch accountId:(NSString *)accountId pixEntry:(NSString * _Nullable)pixEntry email:(NSString * _Nullable)email __attribute__((swift_name("doCopy(isAvailable:accountNumber:branch:accountId:pixEntry:email:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountId __attribute__((swift_name("accountId")));
@property (readonly) NSString *accountNumber __attribute__((swift_name("accountNumber")));
@property (readonly) NSString * _Nullable branch __attribute__((swift_name("branch")));
@property (readonly) NSString * _Nullable email __attribute__((swift_name("email")));
@property (readonly) BOOL isAvailable __attribute__((swift_name("isAvailable")));
@property (readonly) NSString * _Nullable pixEntry __attribute__((swift_name("pixEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubMerchantCommand")))
@interface DCAPISubMerchantCommand : DCAPIBase
- (instancetype)initWithParentStoneCode:(NSString *)parentStoneCode taxIdentificationNumber:(NSString *)taxIdentificationNumber registeredIdentifier:(NSString *)registeredIdentifier mcc:(NSString *)mcc address:(DCAPIAddress *)address __attribute__((swift_name("init(parentStoneCode:taxIdentificationNumber:registeredIdentifier:mcc:address:)"))) __attribute__((objc_designated_initializer));
- (DCAPISubMerchantCommand *)doCopyParentStoneCode:(NSString *)parentStoneCode taxIdentificationNumber:(NSString *)taxIdentificationNumber registeredIdentifier:(NSString *)registeredIdentifier mcc:(NSString *)mcc address:(DCAPIAddress *)address __attribute__((swift_name("doCopy(parentStoneCode:taxIdentificationNumber:registeredIdentifier:mcc:address:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPIAddress *address __attribute__((swift_name("address")));
@property (readonly) NSString *mcc __attribute__((swift_name("mcc")));
@property (readonly) NSString *parentStoneCode __attribute__((swift_name("parentStoneCode")));
@property (readonly) NSString *registeredIdentifier __attribute__((swift_name("registeredIdentifier")));
@property (readonly) NSString *taxIdentificationNumber __attribute__((swift_name("taxIdentificationNumber")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubMerchantQuery")))
@interface DCAPISubMerchantQuery : DCAPIBase
- (instancetype)initWithId:(int64_t)id registeredIdentifier:(NSString *)registeredIdentifier parentStoneCode:(NSString *)parentStoneCode taxIdentificationNumber:(NSString *)taxIdentificationNumber mcc:(NSString *)mcc address:(DCAPIAddress *)address __attribute__((swift_name("init(id:registeredIdentifier:parentStoneCode:taxIdentificationNumber:mcc:address:)"))) __attribute__((objc_designated_initializer));
- (DCAPISubMerchantQuery *)doCopyId:(int64_t)id registeredIdentifier:(NSString *)registeredIdentifier parentStoneCode:(NSString *)parentStoneCode taxIdentificationNumber:(NSString *)taxIdentificationNumber mcc:(NSString *)mcc address:(DCAPIAddress *)address __attribute__((swift_name("doCopy(id:registeredIdentifier:parentStoneCode:taxIdentificationNumber:mcc:address:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPIAddress *address __attribute__((swift_name("address")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) NSString *mcc __attribute__((swift_name("mcc")));
@property (readonly) NSString *parentStoneCode __attribute__((swift_name("parentStoneCode")));
@property (readonly) NSString *registeredIdentifier __attribute__((swift_name("registeredIdentifier")));
@property (readonly) NSString *taxIdentificationNumber __attribute__((swift_name("taxIdentificationNumber")));
@end

__attribute__((swift_name("ProbeApi")))
@protocol DCAPIProbeApi
@required
- (id _Nullable)enableProbeProbeRequired:(DCAPIProbeRequired *)probeRequired __attribute__((swift_name("enableProbe(probeRequired:)")));
- (id _Nullable)getAllRequiredProbesFilter:(DCAPIFilter *)filter __attribute__((swift_name("getAllRequiredProbes(filter:)")));
- (id _Nullable)getProbeRequestsTransactionId:(int64_t)transactionId __attribute__((swift_name("getProbeRequests(transactionId:)")));
- (id _Nullable)getProbeRequiredTransactionId:(int64_t)transactionId __attribute__((swift_name("getProbeRequired(transactionId:)")));
- (id _Nullable)saveProbeRequestProbeRequest:(DCAPIProbeRequest *)probeRequest __attribute__((swift_name("saveProbeRequest(probeRequest:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ProbeRepositoryImpl")))
@interface DCAPIProbeRepositoryImpl : DCAPIBase
- (instancetype)initWithProbeRequestDao:(id<DCAPIData_container_dataProbeRequestDao>)probeRequestDao probeRequiredDao:(id<DCAPIData_container_dataProbeRequiredDao>)probeRequiredDao connectionProvider:(id<DCAPIData_container_dataConnectionProvider>)connectionProvider __attribute__((swift_name("init(probeRequestDao:probeRequiredDao:connectionProvider:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)enableProbeProbeRequired:(DCAPIProbeRequired *)probeRequired __attribute__((swift_name("enableProbe(probeRequired:)")));
- (id _Nullable)getAllRequiredProbesFilter:(DCAPIFilter *)filter __attribute__((swift_name("getAllRequiredProbes(filter:)")));
- (id _Nullable)getProbeRequestsTransactionId:(int64_t)transactionId __attribute__((swift_name("getProbeRequests(transactionId:)")));
- (id _Nullable)getProbeRequiredTransactionId:(int64_t)transactionId __attribute__((swift_name("getProbeRequired(transactionId:)")));
- (id _Nullable)saveProbeRequestProbeRequest:(DCAPIProbeRequest *)probeRequest __attribute__((swift_name("saveProbeRequest(probeRequest:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ProbeRequest")))
@interface DCAPIProbeRequest : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId status:(DCAPIProbeRequestStatus *)status dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime __attribute__((swift_name("init(transactionId:status:dateTime:)"))) __attribute__((objc_designated_initializer));
- (DCAPIProbeRequest *)doCopyTransactionId:(int64_t)transactionId status:(DCAPIProbeRequestStatus *)status dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime __attribute__((swift_name("doCopy(transactionId:status:dateTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) DCAPIProbeRequestStatus *status __attribute__((swift_name("status")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol DCAPIKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface DCAPIKotlinEnum<E> : DCAPIBase <DCAPIKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) DCAPIKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ProbeRequest.Status")))
@interface DCAPIProbeRequestStatus : DCAPIKotlinEnum<DCAPIProbeRequestStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPIProbeRequestStatus *success __attribute__((swift_name("success")));
@property (class, readonly) DCAPIProbeRequestStatus *error __attribute__((swift_name("error")));
+ (DCAPIKotlinArray<DCAPIProbeRequestStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPIProbeRequestStatus *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ProbeRequired")))
@interface DCAPIProbeRequired : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId reason:(NSString *)reason dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime reasonCode:(int32_t)reasonCode __attribute__((swift_name("init(transactionId:reason:dateTime:reasonCode:)"))) __attribute__((objc_designated_initializer));
- (DCAPIProbeRequired *)doCopyTransactionId:(int64_t)transactionId reason:(NSString *)reason dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime reasonCode:(int32_t)reasonCode __attribute__((swift_name("doCopy(transactionId:reason:dateTime:reasonCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) NSString *reason __attribute__((swift_name("reason")));
@property (readonly) int32_t reasonCode __attribute__((swift_name("reasonCode")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((swift_name("ReportApi")))
@protocol DCAPIReportApi
@required
- (id _Nullable)generateReportCashPaymentStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode __attribute__((swift_name("generateReportCashPayment(startReportDate:endReportDate:stoneCode:)")));
- (id _Nullable)generateReportDetailedDataStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode statusCode:(NSArray<DCAPIStatus *> *)statusCode __attribute__((swift_name("generateReportDetailedData(startReportDate:endReportDate:stoneCode:statusCode:)")));
- (id _Nullable)generateSummaryReportCashPaymentStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode __attribute__((swift_name("generateSummaryReportCashPayment(startReportDate:endReportDate:stoneCode:)")));
- (id _Nullable)getReportQrCodeQueryStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode transactionType:(DCAPITransactionType * _Nullable)transactionType __attribute__((swift_name("getReportQrCodeQuery(startReportDate:endReportDate:stoneCode:transactionType:)")));
- (id _Nullable)getReportWalletQueryStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode __attribute__((swift_name("getReportWalletQuery(startReportDate:endReportDate:stoneCode:)")));
- (id _Nullable)getSummaryQrCodeQueryStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode transactionType:(DCAPITransactionType * _Nullable)transactionType __attribute__((swift_name("getSummaryQrCodeQuery(startReportDate:endReportDate:stoneCode:transactionType:)")));
- (id _Nullable)getSummaryWalletQueryStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode __attribute__((swift_name("getSummaryWalletQuery(startReportDate:endReportDate:stoneCode:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReportCashPaymentQuery")))
@interface DCAPIReportCashPaymentQuery : DCAPIBase
- (instancetype)initWithApprovedAmountInCents:(int64_t)approvedAmountInCents approvedCount:(int32_t)approvedCount cancelledAmountInCents:(int64_t)cancelledAmountInCents cancelledCount:(int32_t)cancelledCount __attribute__((swift_name("init(approvedAmountInCents:approvedCount:cancelledAmountInCents:cancelledCount:)"))) __attribute__((objc_designated_initializer));
- (DCAPIReportCashPaymentQuery *)doCopyApprovedAmountInCents:(int64_t)approvedAmountInCents approvedCount:(int32_t)approvedCount cancelledAmountInCents:(int64_t)cancelledAmountInCents cancelledCount:(int32_t)cancelledCount __attribute__((swift_name("doCopy(approvedAmountInCents:approvedCount:cancelledAmountInCents:cancelledCount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t approvedAmountInCents __attribute__((swift_name("approvedAmountInCents")));
@property (readonly) int32_t approvedCount __attribute__((swift_name("approvedCount")));
@property (readonly) int64_t cancelledAmountInCents __attribute__((swift_name("cancelledAmountInCents")));
@property (readonly) int32_t cancelledCount __attribute__((swift_name("cancelledCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReportDataQuery")))
@interface DCAPIReportDataQuery : DCAPIBase
- (instancetype)initWithTotalApprovedBrand:(int64_t)totalApprovedBrand approvedValueBrand:(int64_t)approvedValueBrand approvedTransactionsNumber:(int64_t)approvedTransactionsNumber cancelledValueBrand:(int64_t)cancelledValueBrand cancelledTransactionsNumber:(int64_t)cancelledTransactionsNumber brandId:(int32_t)brandId brandName:(NSString *)brandName transactionType:(DCAPITransactionType * _Nullable)transactionType qualifier:(NSString * _Nullable)qualifier __attribute__((swift_name("init(totalApprovedBrand:approvedValueBrand:approvedTransactionsNumber:cancelledValueBrand:cancelledTransactionsNumber:brandId:brandName:transactionType:qualifier:)"))) __attribute__((objc_designated_initializer));
- (DCAPIReportDataQuery *)doCopyTotalApprovedBrand:(int64_t)totalApprovedBrand approvedValueBrand:(int64_t)approvedValueBrand approvedTransactionsNumber:(int64_t)approvedTransactionsNumber cancelledValueBrand:(int64_t)cancelledValueBrand cancelledTransactionsNumber:(int64_t)cancelledTransactionsNumber brandId:(int32_t)brandId brandName:(NSString *)brandName transactionType:(DCAPITransactionType * _Nullable)transactionType qualifier:(NSString * _Nullable)qualifier __attribute__((swift_name("doCopy(totalApprovedBrand:approvedValueBrand:approvedTransactionsNumber:cancelledValueBrand:cancelledTransactionsNumber:brandId:brandName:transactionType:qualifier:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int64_t approvedTransactionsNumber __attribute__((swift_name("approvedTransactionsNumber")));
@property int64_t approvedValueBrand __attribute__((swift_name("approvedValueBrand")));
@property int32_t brandId __attribute__((swift_name("brandId")));
@property NSString *brandName __attribute__((swift_name("brandName")));
@property int64_t cancelledTransactionsNumber __attribute__((swift_name("cancelledTransactionsNumber")));
@property int64_t cancelledValueBrand __attribute__((swift_name("cancelledValueBrand")));
@property NSString * _Nullable qualifier __attribute__((swift_name("qualifier")));
@property int64_t totalApprovedBrand __attribute__((swift_name("totalApprovedBrand")));
@property DCAPITransactionType * _Nullable transactionType __attribute__((swift_name("transactionType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReportQrCodeQuery")))
@interface DCAPIReportQrCodeQuery : DCAPIBase
- (instancetype)initWithWalletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName brandId:(int32_t)brandId brandName:(NSString *)brandName transactionType:(DCAPITransactionType *)transactionType totalApproved:(int64_t)totalApproved approvedValue:(int64_t)approvedValue approvedTransactionsNumber:(int64_t)approvedTransactionsNumber cancelledValue:(int64_t)cancelledValue cancelledTransactionsNumber:(int64_t)cancelledTransactionsNumber __attribute__((swift_name("init(walletProviderId:walletProviderName:brandId:brandName:transactionType:totalApproved:approvedValue:approvedTransactionsNumber:cancelledValue:cancelledTransactionsNumber:)"))) __attribute__((objc_designated_initializer));
- (DCAPIReportQrCodeQuery *)doCopyWalletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName brandId:(int32_t)brandId brandName:(NSString *)brandName transactionType:(DCAPITransactionType *)transactionType totalApproved:(int64_t)totalApproved approvedValue:(int64_t)approvedValue approvedTransactionsNumber:(int64_t)approvedTransactionsNumber cancelledValue:(int64_t)cancelledValue cancelledTransactionsNumber:(int64_t)cancelledTransactionsNumber __attribute__((swift_name("doCopy(walletProviderId:walletProviderName:brandId:brandName:transactionType:totalApproved:approvedValue:approvedTransactionsNumber:cancelledValue:cancelledTransactionsNumber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int64_t approvedTransactionsNumber __attribute__((swift_name("approvedTransactionsNumber")));
@property int64_t approvedValue __attribute__((swift_name("approvedValue")));
@property int32_t brandId __attribute__((swift_name("brandId")));
@property NSString *brandName __attribute__((swift_name("brandName")));
@property int64_t cancelledTransactionsNumber __attribute__((swift_name("cancelledTransactionsNumber")));
@property int64_t cancelledValue __attribute__((swift_name("cancelledValue")));
@property int64_t totalApproved __attribute__((swift_name("totalApproved")));
@property DCAPITransactionType *transactionType __attribute__((swift_name("transactionType")));
@property NSString *walletProviderId __attribute__((swift_name("walletProviderId")));
@property NSString *walletProviderName __attribute__((swift_name("walletProviderName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReportRepositoryImpl")))
@interface DCAPIReportRepositoryImpl : DCAPIBase
- (instancetype)initWithReportDao:(id<DCAPIData_container_dataReportDao>)reportDao __attribute__((swift_name("init(reportDao:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)generateReportCashPaymentStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode __attribute__((swift_name("generateReportCashPayment(startReportDate:endReportDate:stoneCode:)")));
- (id _Nullable)generateReportDetailedDataStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode statusCode:(NSArray<DCAPIStatus *> *)statusCode __attribute__((swift_name("generateReportDetailedData(startReportDate:endReportDate:stoneCode:statusCode:)")));
- (id _Nullable)generateSummaryReportCashPaymentStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode __attribute__((swift_name("generateSummaryReportCashPayment(startReportDate:endReportDate:stoneCode:)")));
- (id _Nullable)getReportQrCodeQueryStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode transactionType:(DCAPITransactionType * _Nullable)transactionType __attribute__((swift_name("getReportQrCodeQuery(startReportDate:endReportDate:stoneCode:transactionType:)")));
- (id _Nullable)getReportWalletQueryStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode __attribute__((swift_name("getReportWalletQuery(startReportDate:endReportDate:stoneCode:)")));
- (id _Nullable)getSummaryQrCodeQueryStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode transactionType:(DCAPITransactionType * _Nullable)transactionType __attribute__((swift_name("getSummaryQrCodeQuery(startReportDate:endReportDate:stoneCode:transactionType:)")));
- (id _Nullable)getSummaryWalletQueryStartReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)startReportDate endReportDate:(DCAPIKotlinx_datetimeLocalDateTime *)endReportDate stoneCode:(NSString *)stoneCode __attribute__((swift_name("getSummaryWalletQuery(startReportDate:endReportDate:stoneCode:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReportSummaryCashPaymentQuery")))
@interface DCAPIReportSummaryCashPaymentQuery : DCAPIBase
- (instancetype)initWithApprovedAmountInCents:(int64_t)approvedAmountInCents approvedCount:(int32_t)approvedCount cancelledAmountInCents:(int64_t)cancelledAmountInCents cancelledCount:(int32_t)cancelledCount __attribute__((swift_name("init(approvedAmountInCents:approvedCount:cancelledAmountInCents:cancelledCount:)"))) __attribute__((objc_designated_initializer));
- (DCAPIReportSummaryCashPaymentQuery *)doCopyApprovedAmountInCents:(int64_t)approvedAmountInCents approvedCount:(int32_t)approvedCount cancelledAmountInCents:(int64_t)cancelledAmountInCents cancelledCount:(int32_t)cancelledCount __attribute__((swift_name("doCopy(approvedAmountInCents:approvedCount:cancelledAmountInCents:cancelledCount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t approvedAmountInCents __attribute__((swift_name("approvedAmountInCents")));
@property (readonly) int32_t approvedCount __attribute__((swift_name("approvedCount")));
@property (readonly) int64_t cancelledAmountInCents __attribute__((swift_name("cancelledAmountInCents")));
@property (readonly) int32_t cancelledCount __attribute__((swift_name("cancelledCount")));
@property (readonly) int64_t totalApprovedAmountInCents __attribute__((swift_name("totalApprovedAmountInCents")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReportSummaryQrCodeQuery")))
@interface DCAPIReportSummaryQrCodeQuery : DCAPIBase
- (instancetype)initWithWalletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName brand:(int32_t)brand transactionType:(DCAPITransactionType *)transactionType approvedValue:(int64_t)approvedValue approvedNumber:(int64_t)approvedNumber cancelledNumber:(int64_t)cancelledNumber __attribute__((swift_name("init(walletProviderId:walletProviderName:brand:transactionType:approvedValue:approvedNumber:cancelledNumber:)"))) __attribute__((objc_designated_initializer));
- (DCAPIReportSummaryQrCodeQuery *)doCopyWalletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName brand:(int32_t)brand transactionType:(DCAPITransactionType *)transactionType approvedValue:(int64_t)approvedValue approvedNumber:(int64_t)approvedNumber cancelledNumber:(int64_t)cancelledNumber __attribute__((swift_name("doCopy(walletProviderId:walletProviderName:brand:transactionType:approvedValue:approvedNumber:cancelledNumber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t approvedNumber __attribute__((swift_name("approvedNumber")));
@property (readonly) int64_t approvedValue __attribute__((swift_name("approvedValue")));
@property int32_t brand __attribute__((swift_name("brand")));
@property (readonly) int64_t cancelledNumber __attribute__((swift_name("cancelledNumber")));
@property DCAPITransactionType *transactionType __attribute__((swift_name("transactionType")));
@property NSString *walletProviderId __attribute__((swift_name("walletProviderId")));
@property NSString *walletProviderName __attribute__((swift_name("walletProviderName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReportSummaryWalletQuery")))
@interface DCAPIReportSummaryWalletQuery : DCAPIBase
- (instancetype)initWithApprovedValueFromQrCode:(int64_t)approvedValueFromQrCode approvedNumberFromQrCode:(int64_t)approvedNumberFromQrCode __attribute__((swift_name("init(approvedValueFromQrCode:approvedNumberFromQrCode:)"))) __attribute__((objc_designated_initializer));
- (DCAPIReportSummaryWalletQuery *)doCopyApprovedValueFromQrCode:(int64_t)approvedValueFromQrCode approvedNumberFromQrCode:(int64_t)approvedNumberFromQrCode __attribute__((swift_name("doCopy(approvedValueFromQrCode:approvedNumberFromQrCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t approvedNumberFromQrCode __attribute__((swift_name("approvedNumberFromQrCode")));
@property (readonly) int64_t approvedValueFromQrCode __attribute__((swift_name("approvedValueFromQrCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReportWalletQuery")))
@interface DCAPIReportWalletQuery : DCAPIBase
- (instancetype)initWithWalletId:(NSString *)walletId walletName:(NSString *)walletName totalApprovedWallet:(int64_t)totalApprovedWallet approvedValueWallet:(int64_t)approvedValueWallet approvedTransactionsNumber:(int64_t)approvedTransactionsNumber cancelledValueWallet:(int64_t)cancelledValueWallet cancelledTransactionsNumber:(int64_t)cancelledTransactionsNumber __attribute__((swift_name("init(walletId:walletName:totalApprovedWallet:approvedValueWallet:approvedTransactionsNumber:cancelledValueWallet:cancelledTransactionsNumber:)"))) __attribute__((objc_designated_initializer));
- (DCAPIReportWalletQuery *)doCopyWalletId:(NSString *)walletId walletName:(NSString *)walletName totalApprovedWallet:(int64_t)totalApprovedWallet approvedValueWallet:(int64_t)approvedValueWallet approvedTransactionsNumber:(int64_t)approvedTransactionsNumber cancelledValueWallet:(int64_t)cancelledValueWallet cancelledTransactionsNumber:(int64_t)cancelledTransactionsNumber __attribute__((swift_name("doCopy(walletId:walletName:totalApprovedWallet:approvedValueWallet:approvedTransactionsNumber:cancelledValueWallet:cancelledTransactionsNumber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int64_t approvedTransactionsNumber __attribute__((swift_name("approvedTransactionsNumber")));
@property int64_t approvedValueWallet __attribute__((swift_name("approvedValueWallet")));
@property int64_t cancelledTransactionsNumber __attribute__((swift_name("cancelledTransactionsNumber")));
@property int64_t cancelledValueWallet __attribute__((swift_name("cancelledValueWallet")));
@property int64_t totalApprovedWallet __attribute__((swift_name("totalApprovedWallet")));
@property NSString *walletId __attribute__((swift_name("walletId")));
@property NSString *walletName __attribute__((swift_name("walletName")));
@end

__attribute__((swift_name("ReversalApi")))
@protocol DCAPIReversalApi
@required
- (id _Nullable)enableReversalReversalRequired:(DCAPIReversalRequired *)reversalRequired __attribute__((swift_name("enableReversal(reversalRequired:)")));
- (id _Nullable)getAllRequiredReversalsFilter:(DCAPIFilter *)filter __attribute__((swift_name("getAllRequiredReversals(filter:)")));
- (id _Nullable)getReversalRequestsTransactionId:(int64_t)transactionId __attribute__((swift_name("getReversalRequests(transactionId:)")));
- (id _Nullable)getReversalRequiredTransactionId:(int64_t)transactionId __attribute__((swift_name("getReversalRequired(transactionId:)")));
- (id _Nullable)saveReversalRequestReversalRequest:(DCAPIReversalRequest *)reversalRequest __attribute__((swift_name("saveReversalRequest(reversalRequest:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReversalRepositoryImpl")))
@interface DCAPIReversalRepositoryImpl : DCAPIBase
- (instancetype)initWithReversalRequestDao:(id<DCAPIData_container_dataReversalRequestDao>)reversalRequestDao reversalRequiredDao:(id<DCAPIData_container_dataReversalRequiredDao>)reversalRequiredDao __attribute__((swift_name("init(reversalRequestDao:reversalRequiredDao:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)enableReversalReversalRequired:(DCAPIReversalRequired *)reversalRequired __attribute__((swift_name("enableReversal(reversalRequired:)")));
- (id _Nullable)getAllRequiredReversalsFilter:(DCAPIFilter *)filter __attribute__((swift_name("getAllRequiredReversals(filter:)")));
- (id _Nullable)getReversalRequestsTransactionId:(int64_t)transactionId __attribute__((swift_name("getReversalRequests(transactionId:)")));
- (id _Nullable)getReversalRequiredTransactionId:(int64_t)transactionId __attribute__((swift_name("getReversalRequired(transactionId:)")));
- (id _Nullable)saveReversalRequestReversalRequest:(DCAPIReversalRequest *)reversalRequest __attribute__((swift_name("saveReversalRequest(reversalRequest:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReversalRequest")))
@interface DCAPIReversalRequest : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId status:(DCAPIReversalRequestStatus *)status dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime __attribute__((swift_name("init(transactionId:status:dateTime:)"))) __attribute__((objc_designated_initializer));
- (DCAPIReversalRequest *)doCopyTransactionId:(int64_t)transactionId status:(DCAPIReversalRequestStatus *)status dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime __attribute__((swift_name("doCopy(transactionId:status:dateTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) DCAPIReversalRequestStatus *status __attribute__((swift_name("status")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReversalRequest.Status")))
@interface DCAPIReversalRequestStatus : DCAPIKotlinEnum<DCAPIReversalRequestStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPIReversalRequestStatus *success __attribute__((swift_name("success")));
@property (class, readonly) DCAPIReversalRequestStatus *error __attribute__((swift_name("error")));
@property (class, readonly) DCAPIReversalRequestStatus *backoffError __attribute__((swift_name("backoffError")));
+ (DCAPIKotlinArray<DCAPIReversalRequestStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPIReversalRequestStatus *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReversalRequired")))
@interface DCAPIReversalRequired : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId reason:(NSString *)reason dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime reasonCode:(int32_t)reasonCode __attribute__((swift_name("init(transactionId:reason:dateTime:reasonCode:)"))) __attribute__((objc_designated_initializer));
- (DCAPIReversalRequired *)doCopyTransactionId:(int64_t)transactionId reason:(NSString *)reason dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime reasonCode:(int32_t)reasonCode __attribute__((swift_name("doCopy(transactionId:reason:dateTime:reasonCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) NSString *reason __attribute__((swift_name("reason")));
@property (readonly) int32_t reasonCode __attribute__((swift_name("reasonCode")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((swift_name("SalesHistoryApi")))
@protocol DCAPISalesHistoryApi
@required
- (id _Nullable)getAllSalesHistory __attribute__((swift_name("getAllSalesHistory()")));
- (id _Nullable)getAllSalesHistoryBetweenDatesDateStart:(DCAPIKotlinx_datetimeLocalDateTime *)dateStart dateEnd:(DCAPIKotlinx_datetimeLocalDateTime *)dateEnd __attribute__((swift_name("getAllSalesHistoryBetweenDates(dateStart:dateEnd:)")));
- (id _Nullable)getPaginatedSalesHistoryDateStart:(DCAPIKotlinx_datetimeLocalDateTime *)dateStart dateEnd:(DCAPIKotlinx_datetimeLocalDateTime *)dateEnd limit:(int32_t)limit offset:(int32_t)offset __attribute__((swift_name("getPaginatedSalesHistory(dateStart:dateEnd:limit:offset:)")));
- (id _Nullable)getSaleHistorySalesHistoryId:(int64_t)salesHistoryId __attribute__((swift_name("getSaleHistory(salesHistoryId:)")));
- (id _Nullable)getSalesHistoryByFilterFilter:(DCAPIFilter *)filter __attribute__((swift_name("getSalesHistoryByFilter(filter:)")));
- (id _Nullable)getSalesHistoryRowsDateStart:(DCAPIKotlinx_datetimeLocalDateTime *)dateStart dateEnd:(DCAPIKotlinx_datetimeLocalDateTime *)dateEnd __attribute__((swift_name("getSalesHistoryRows(dateStart:dateEnd:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SalesHistoryQuery")))
@interface DCAPISalesHistoryQuery : DCAPIBase
- (instancetype)initWithSalesHistoryId:(int64_t)salesHistoryId amount:(int64_t)amount cancelledAmount:(int64_t)cancelledAmount finalAmount:(int64_t)finalAmount cardBrandId:(int32_t)cardBrandId cardBrandName:(NSString *)cardBrandName status:(NSString *)status approvalDate:(DCAPIKotlinx_datetimeLocalDateTime *)approvalDate cancelledDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)cancelledDate stoneId:(NSString *)stoneId reducedModality:(NSString *)reducedModality extendedModality:(NSString *)extendedModality hasMultipleCancellations:(BOOL)hasMultipleCancellations isInstantPaymentTransaction:(BOOL)isInstantPaymentTransaction walletId:(NSString * _Nullable)walletId cardPan:(NSString * _Nullable)cardPan qualifier:(NSString * _Nullable)qualifier __attribute__((swift_name("init(salesHistoryId:amount:cancelledAmount:finalAmount:cardBrandId:cardBrandName:status:approvalDate:cancelledDate:stoneId:reducedModality:extendedModality:hasMultipleCancellations:isInstantPaymentTransaction:walletId:cardPan:qualifier:)"))) __attribute__((objc_designated_initializer));
- (DCAPISalesHistoryQuery *)doCopySalesHistoryId:(int64_t)salesHistoryId amount:(int64_t)amount cancelledAmount:(int64_t)cancelledAmount finalAmount:(int64_t)finalAmount cardBrandId:(int32_t)cardBrandId cardBrandName:(NSString *)cardBrandName status:(NSString *)status approvalDate:(DCAPIKotlinx_datetimeLocalDateTime *)approvalDate cancelledDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)cancelledDate stoneId:(NSString *)stoneId reducedModality:(NSString *)reducedModality extendedModality:(NSString *)extendedModality hasMultipleCancellations:(BOOL)hasMultipleCancellations isInstantPaymentTransaction:(BOOL)isInstantPaymentTransaction walletId:(NSString * _Nullable)walletId cardPan:(NSString * _Nullable)cardPan qualifier:(NSString * _Nullable)qualifier __attribute__((swift_name("doCopy(salesHistoryId:amount:cancelledAmount:finalAmount:cardBrandId:cardBrandName:status:approvalDate:cancelledDate:stoneId:reducedModality:extendedModality:hasMultipleCancellations:isInstantPaymentTransaction:walletId:cardPan:qualifier:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t amount __attribute__((swift_name("amount")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *approvalDate __attribute__((swift_name("approvalDate")));
@property (readonly) int64_t cancelledAmount __attribute__((swift_name("cancelledAmount")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable cancelledDate __attribute__((swift_name("cancelledDate")));
@property (readonly) int32_t cardBrandId __attribute__((swift_name("cardBrandId")));
@property (readonly) NSString *cardBrandName __attribute__((swift_name("cardBrandName")));
@property (readonly) NSString * _Nullable cardPan __attribute__((swift_name("cardPan")));
@property (readonly) NSString *extendedModality __attribute__((swift_name("extendedModality")));
@property (readonly) int64_t finalAmount __attribute__((swift_name("finalAmount")));
@property (readonly) BOOL hasMultipleCancellations __attribute__((swift_name("hasMultipleCancellations")));
@property (readonly) BOOL isInstantPaymentTransaction __attribute__((swift_name("isInstantPaymentTransaction")));
@property (readonly) NSString * _Nullable qualifier __attribute__((swift_name("qualifier")));
@property (readonly) NSString *reducedModality __attribute__((swift_name("reducedModality")));
@property (readonly) int64_t salesHistoryId __attribute__((swift_name("salesHistoryId")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) NSString *stoneId __attribute__((swift_name("stoneId")));
@property (readonly) NSString * _Nullable walletId __attribute__((swift_name("walletId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SalesHistoryRepositoryImpl")))
@interface DCAPISalesHistoryRepositoryImpl : DCAPIBase
- (instancetype)initWithSalesHistoryDao:(id<DCAPIData_container_dataSalesHistoryDao>)salesHistoryDao connectionProvider:(id<DCAPIData_container_dataConnectionProvider>)connectionProvider __attribute__((swift_name("init(salesHistoryDao:connectionProvider:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getAllSalesHistory __attribute__((swift_name("getAllSalesHistory()")));
- (id _Nullable)getAllSalesHistoryBetweenDatesDateStart:(DCAPIKotlinx_datetimeLocalDateTime *)dateStart dateEnd:(DCAPIKotlinx_datetimeLocalDateTime *)dateEnd __attribute__((swift_name("getAllSalesHistoryBetweenDates(dateStart:dateEnd:)")));
- (id _Nullable)getPaginatedSalesHistoryDateStart:(DCAPIKotlinx_datetimeLocalDateTime *)dateStart dateEnd:(DCAPIKotlinx_datetimeLocalDateTime *)dateEnd limit:(int32_t)limit offset:(int32_t)offset __attribute__((swift_name("getPaginatedSalesHistory(dateStart:dateEnd:limit:offset:)")));
- (id _Nullable)getSaleHistorySalesHistoryId:(int64_t)salesHistoryId __attribute__((swift_name("getSaleHistory(salesHistoryId:)")));
- (id _Nullable)getSalesHistoryByFilterFilter:(DCAPIFilter *)filter __attribute__((swift_name("getSalesHistoryByFilter(filter:)")));
- (id _Nullable)getSalesHistoryRowsDateStart:(DCAPIKotlinx_datetimeLocalDateTime *)dateStart dateEnd:(DCAPIKotlinx_datetimeLocalDateTime *)dateEnd __attribute__((swift_name("getSalesHistoryRows(dateStart:dateEnd:)")));
@end

__attribute__((swift_name("SystemConfigApi")))
@protocol DCAPISystemConfigApi
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getEnvironmentWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getEnvironment(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)setAdminPasswordPassword:(NSString *)password completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("setAdminPassword(password:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)validateAdminPasswordPassword:(NSString *)password completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("validateAdminPassword(password:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SystemConfigRepositoryImpl")))
@interface DCAPISystemConfigRepositoryImpl : DCAPIBase
- (instancetype)initWithSystemConfigDao:(DCAPIData_container_dataSystemConfigDao *)systemConfigDao __attribute__((swift_name("init(systemConfigDao:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getEnvironmentWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getEnvironment(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)setAdminPasswordPassword:(NSString *)password completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("setAdminPassword(password:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)validateAdminPasswordPassword:(NSString *)password completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("validateAdminPassword(password:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnvironmentEnum")))
@interface DCAPIEnvironmentEnum : DCAPIKotlinEnum<DCAPIEnvironmentEnum *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPIEnvironmentEnum *production __attribute__((swift_name("production")));
@property (class, readonly) DCAPIEnvironmentEnum *certification __attribute__((swift_name("certification")));
@property (class, readonly) DCAPIEnvironmentEnum *sandbox __attribute__((swift_name("sandbox")));
@property (class, readonly) DCAPIEnvironmentEnum *internalHomolog __attribute__((swift_name("internalHomolog")));
@property (class, readonly) DCAPIEnvironmentEnum *staging __attribute__((swift_name("staging")));
+ (DCAPIKotlinArray<DCAPIEnvironmentEnum *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPIEnvironmentEnum *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthorizationTransactionQuery")))
@interface DCAPIAuthorizationTransactionQuery : DCAPIBase
- (instancetype)initWithAuthorization:(DCAPIAuthorization *)authorization transaction:(DCAPITransactionQuery *)transaction __attribute__((swift_name("init(authorization:transaction:)"))) __attribute__((objc_designated_initializer));
- (DCAPIAuthorizationTransactionQuery *)doCopyAuthorization:(DCAPIAuthorization *)authorization transaction:(DCAPITransactionQuery *)transaction __attribute__((swift_name("doCopy(authorization:transaction:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPIAuthorization *authorization __attribute__((swift_name("authorization")));
@property (readonly) DCAPITransactionQuery *transaction __attribute__((swift_name("transaction")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Card")))
@interface DCAPICard : DCAPIBase
- (instancetype)initWithPan:(NSString *)pan aid:(NSString *)aid cvm:(NSString *)cvm cardholderName:(NSString *)cardholderName cardholderNameExtended:(NSString *)cardholderNameExtended transactionType:(DCAPITransactionType *)transactionType voucherType:(DCAPIVoucherType *)voucherType appLabel:(NSString *)appLabel brandId:(int32_t)brandId brandName:(NSString *)brandName accountBalance:(NSString *)accountBalance entryMode:(DCAPICardEntryMode *)entryMode cardHolder:(DCAPICardHolder *)cardHolder serviceCode:(NSString *)serviceCode atcPayment:(NSString * _Nullable)atcPayment atcCancellation:(NSString * _Nullable)atcCancellation panSequenceNumber:(NSString * _Nullable)panSequenceNumber __attribute__((swift_name("init(pan:aid:cvm:cardholderName:cardholderNameExtended:transactionType:voucherType:appLabel:brandId:brandName:accountBalance:entryMode:cardHolder:serviceCode:atcPayment:atcCancellation:panSequenceNumber:)"))) __attribute__((objc_designated_initializer));
- (DCAPICard *)doCopyPan:(NSString *)pan aid:(NSString *)aid cvm:(NSString *)cvm cardholderName:(NSString *)cardholderName cardholderNameExtended:(NSString *)cardholderNameExtended transactionType:(DCAPITransactionType *)transactionType voucherType:(DCAPIVoucherType *)voucherType appLabel:(NSString *)appLabel brandId:(int32_t)brandId brandName:(NSString *)brandName accountBalance:(NSString *)accountBalance entryMode:(DCAPICardEntryMode *)entryMode cardHolder:(DCAPICardHolder *)cardHolder serviceCode:(NSString *)serviceCode atcPayment:(NSString * _Nullable)atcPayment atcCancellation:(NSString * _Nullable)atcCancellation panSequenceNumber:(NSString * _Nullable)panSequenceNumber __attribute__((swift_name("doCopy(pan:aid:cvm:cardholderName:cardholderNameExtended:transactionType:voucherType:appLabel:brandId:brandName:accountBalance:entryMode:cardHolder:serviceCode:atcPayment:atcCancellation:panSequenceNumber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountBalance __attribute__((swift_name("accountBalance")));
@property (readonly) NSString *aid __attribute__((swift_name("aid")));
@property (readonly) NSString *appLabel __attribute__((swift_name("appLabel")));
@property (readonly) NSString * _Nullable atcCancellation __attribute__((swift_name("atcCancellation")));
@property (readonly) NSString * _Nullable atcPayment __attribute__((swift_name("atcPayment")));
@property (readonly) int32_t brandId __attribute__((swift_name("brandId")));
@property (readonly) NSString *brandName __attribute__((swift_name("brandName")));
@property (readonly) DCAPICardHolder *cardHolder __attribute__((swift_name("cardHolder")));
@property (readonly) NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property (readonly) NSString *cardholderNameExtended __attribute__((swift_name("cardholderNameExtended")));
@property (readonly) NSString *cvm __attribute__((swift_name("cvm")));
@property (readonly) DCAPICardEntryMode *entryMode __attribute__((swift_name("entryMode")));
@property (readonly) NSString *pan __attribute__((swift_name("pan")));
@property (readonly) NSString * _Nullable panSequenceNumber __attribute__((swift_name("panSequenceNumber")));
@property (readonly) NSString *serviceCode __attribute__((swift_name("serviceCode")));
@property (readonly) DCAPITransactionType *transactionType __attribute__((swift_name("transactionType")));
@property (readonly) DCAPIVoucherType *voucherType __attribute__((swift_name("voucherType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Card.EntryMode")))
@interface DCAPICardEntryMode : DCAPIKotlinEnum<DCAPICardEntryMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPICardEntryMode *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) DCAPICardEntryMode *icc __attribute__((swift_name("icc")));
@property (class, readonly) DCAPICardEntryMode *mag __attribute__((swift_name("mag")));
@property (class, readonly) DCAPICardEntryMode *picc __attribute__((swift_name("picc")));
@property (class, readonly) DCAPICardEntryMode *piccMag __attribute__((swift_name("piccMag")));
@property (class, readonly) DCAPICardEntryMode *qrCode __attribute__((swift_name("qrCode")));
+ (DCAPIKotlinArray<DCAPICardEntryMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPICardEntryMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardCommand")))
@interface DCAPICardCommand : DCAPIBase
- (instancetype)initWithPan:(NSString *)pan aid:(NSString *)aid cvm:(NSString *)cvm cardholderName:(NSString *)cardholderName cardholderNameExtended:(NSString *)cardholderNameExtended transactionType:(DCAPITransactionType *)transactionType voucherType:(DCAPIVoucherType *)voucherType appLabel:(NSString *)appLabel brandId:(int32_t)brandId brandName:(NSString *)brandName accountBalance:(NSString *)accountBalance entryMode:(DCAPICardEntryMode *)entryMode cardHolder:(DCAPICardHolder *)cardHolder serviceCode:(NSString *)serviceCode atcPayment:(NSString * _Nullable)atcPayment atcCancellation:(NSString * _Nullable)atcCancellation panSequenceNumber:(NSString * _Nullable)panSequenceNumber __attribute__((swift_name("init(pan:aid:cvm:cardholderName:cardholderNameExtended:transactionType:voucherType:appLabel:brandId:brandName:accountBalance:entryMode:cardHolder:serviceCode:atcPayment:atcCancellation:panSequenceNumber:)"))) __attribute__((objc_designated_initializer));
- (DCAPICardCommand *)doCopyPan:(NSString *)pan aid:(NSString *)aid cvm:(NSString *)cvm cardholderName:(NSString *)cardholderName cardholderNameExtended:(NSString *)cardholderNameExtended transactionType:(DCAPITransactionType *)transactionType voucherType:(DCAPIVoucherType *)voucherType appLabel:(NSString *)appLabel brandId:(int32_t)brandId brandName:(NSString *)brandName accountBalance:(NSString *)accountBalance entryMode:(DCAPICardEntryMode *)entryMode cardHolder:(DCAPICardHolder *)cardHolder serviceCode:(NSString *)serviceCode atcPayment:(NSString * _Nullable)atcPayment atcCancellation:(NSString * _Nullable)atcCancellation panSequenceNumber:(NSString * _Nullable)panSequenceNumber __attribute__((swift_name("doCopy(pan:aid:cvm:cardholderName:cardholderNameExtended:transactionType:voucherType:appLabel:brandId:brandName:accountBalance:entryMode:cardHolder:serviceCode:atcPayment:atcCancellation:panSequenceNumber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountBalance __attribute__((swift_name("accountBalance")));
@property (readonly) NSString *aid __attribute__((swift_name("aid")));
@property (readonly) NSString *appLabel __attribute__((swift_name("appLabel")));
@property (readonly) NSString * _Nullable atcCancellation __attribute__((swift_name("atcCancellation")));
@property (readonly) NSString * _Nullable atcPayment __attribute__((swift_name("atcPayment")));
@property (readonly) int32_t brandId __attribute__((swift_name("brandId")));
@property (readonly) NSString *brandName __attribute__((swift_name("brandName")));
@property (readonly) DCAPICardHolder *cardHolder __attribute__((swift_name("cardHolder")));
@property (readonly) NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property (readonly) NSString *cardholderNameExtended __attribute__((swift_name("cardholderNameExtended")));
@property (readonly) NSString *cvm __attribute__((swift_name("cvm")));
@property (readonly) DCAPICardEntryMode *entryMode __attribute__((swift_name("entryMode")));
@property (readonly) NSString *pan __attribute__((swift_name("pan")));
@property (readonly) NSString * _Nullable panSequenceNumber __attribute__((swift_name("panSequenceNumber")));
@property (readonly) NSString *serviceCode __attribute__((swift_name("serviceCode")));
@property (readonly) DCAPITransactionType *transactionType __attribute__((swift_name("transactionType")));
@property (readonly) DCAPIVoucherType *voucherType __attribute__((swift_name("voucherType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardHolder")))
@interface DCAPICardHolder : DCAPIBase
- (instancetype)initWithEmail:(NSString *)email __attribute__((swift_name("init(email:)"))) __attribute__((objc_designated_initializer));
- (DCAPICardHolder *)doCopyEmail:(NSString *)email __attribute__((swift_name("doCopy(email:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DetailedTransactionQuery")))
@interface DCAPIDetailedTransactionQuery : DCAPIBase
- (instancetype)initWithTransaction:(DCAPITransactionQuery *)transaction merchant:(DCAPIMerchantQuery *)merchant authorization:(DCAPIAuthorization * _Nullable)authorization invoice:(DCAPIInvoice * _Nullable)invoice cancellations:(NSArray<DCAPICancellation *> *)cancellations reversalRequests:(NSArray<DCAPIReversalRequest *> *)reversalRequests reversalRequired:(DCAPIReversalRequired * _Nullable)reversalRequired probeRequests:(NSArray<DCAPIProbeRequest *> *)probeRequests probeRequired:(DCAPIProbeRequired * _Nullable)probeRequired subMerchant:(DCAPISubMerchantQuery * _Nullable)subMerchant __attribute__((swift_name("init(transaction:merchant:authorization:invoice:cancellations:reversalRequests:reversalRequired:probeRequests:probeRequired:subMerchant:)"))) __attribute__((objc_designated_initializer));
- (DCAPIDetailedTransactionQuery *)doCopyTransaction:(DCAPITransactionQuery *)transaction merchant:(DCAPIMerchantQuery *)merchant authorization:(DCAPIAuthorization * _Nullable)authorization invoice:(DCAPIInvoice * _Nullable)invoice cancellations:(NSArray<DCAPICancellation *> *)cancellations reversalRequests:(NSArray<DCAPIReversalRequest *> *)reversalRequests reversalRequired:(DCAPIReversalRequired * _Nullable)reversalRequired probeRequests:(NSArray<DCAPIProbeRequest *> *)probeRequests probeRequired:(DCAPIProbeRequired * _Nullable)probeRequired subMerchant:(DCAPISubMerchantQuery * _Nullable)subMerchant __attribute__((swift_name("doCopy(transaction:merchant:authorization:invoice:cancellations:reversalRequests:reversalRequired:probeRequests:probeRequired:subMerchant:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPIAuthorization * _Nullable authorization __attribute__((swift_name("authorization")));
@property (readonly) NSArray<DCAPICancellation *> *cancellations __attribute__((swift_name("cancellations")));
@property (readonly) DCAPIInvoice * _Nullable invoice __attribute__((swift_name("invoice")));
@property (readonly) DCAPIMerchantQuery *merchant __attribute__((swift_name("merchant")));
@property (readonly) NSArray<DCAPIProbeRequest *> *probeRequests __attribute__((swift_name("probeRequests")));
@property (readonly) DCAPIProbeRequired * _Nullable probeRequired __attribute__((swift_name("probeRequired")));
@property (readonly) NSArray<DCAPIReversalRequest *> *reversalRequests __attribute__((swift_name("reversalRequests")));
@property (readonly) DCAPIReversalRequired * _Nullable reversalRequired __attribute__((swift_name("reversalRequired")));
@property (readonly) DCAPISubMerchantQuery * _Nullable subMerchant __attribute__((swift_name("subMerchant")));
@property (readonly) DCAPITransactionQuery *transaction __attribute__((swift_name("transaction")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InstalmentType")))
@interface DCAPIInstalmentType : DCAPIKotlinEnum<DCAPIInstalmentType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPIInstalmentType *none __attribute__((swift_name("none")));
@property (class, readonly) DCAPIInstalmentType *merchant __attribute__((swift_name("merchant")));
@property (class, readonly) DCAPIInstalmentType *issuer __attribute__((swift_name("issuer")));
+ (DCAPIKotlinArray<DCAPIInstalmentType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPIInstalmentType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InstantPaymentTransactionQuery")))
@interface DCAPIInstantPaymentTransactionQuery : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId itk:(NSString *)itk orderId:(NSString *)orderId status:(NSString *)status transactionDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)transactionDate invoiceId:(int64_t)invoiceId paymentOrderId:(NSString *)paymentOrderId paymentType:(NSString *)paymentType walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName walletCustomerId:(NSString *)walletCustomerId walletCustomerName:(NSString *)walletCustomerName walletCustomerAccountNumber:(NSString *)walletCustomerAccountNumber walletCustomerAccountName:(NSString *)walletCustomerAccountName amount:(NSString * _Nullable)amount createdAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)createdAt approvedAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)approvedAt refusedAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)refusedAt __attribute__((swift_name("init(transactionId:itk:orderId:status:transactionDate:invoiceId:paymentOrderId:paymentType:walletProviderId:walletProviderName:walletCustomerId:walletCustomerName:walletCustomerAccountNumber:walletCustomerAccountName:amount:createdAt:approvedAt:refusedAt:)"))) __attribute__((objc_designated_initializer));
- (DCAPIInstantPaymentTransactionQuery *)doCopyTransactionId:(int64_t)transactionId itk:(NSString *)itk orderId:(NSString *)orderId status:(NSString *)status transactionDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)transactionDate invoiceId:(int64_t)invoiceId paymentOrderId:(NSString *)paymentOrderId paymentType:(NSString *)paymentType walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName walletCustomerId:(NSString *)walletCustomerId walletCustomerName:(NSString *)walletCustomerName walletCustomerAccountNumber:(NSString *)walletCustomerAccountNumber walletCustomerAccountName:(NSString *)walletCustomerAccountName amount:(NSString * _Nullable)amount createdAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)createdAt approvedAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)approvedAt refusedAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)refusedAt __attribute__((swift_name("doCopy(transactionId:itk:orderId:status:transactionDate:invoiceId:paymentOrderId:paymentType:walletProviderId:walletProviderName:walletCustomerId:walletCustomerName:walletCustomerAccountNumber:walletCustomerAccountName:amount:createdAt:approvedAt:refusedAt:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable amount __attribute__((swift_name("amount")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable approvedAt __attribute__((swift_name("approvedAt")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property (readonly) int64_t invoiceId __attribute__((swift_name("invoiceId")));
@property (readonly) NSString *itk __attribute__((swift_name("itk")));
@property (readonly) NSString *orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString *paymentOrderId __attribute__((swift_name("paymentOrderId")));
@property (readonly) NSString *paymentType __attribute__((swift_name("paymentType")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable refusedAt __attribute__((swift_name("refusedAt")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable transactionDate __attribute__((swift_name("transactionDate")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@property (readonly) NSString *walletCustomerAccountName __attribute__((swift_name("walletCustomerAccountName")));
@property (readonly) NSString *walletCustomerAccountNumber __attribute__((swift_name("walletCustomerAccountNumber")));
@property (readonly) NSString *walletCustomerId __attribute__((swift_name("walletCustomerId")));
@property (readonly) NSString *walletCustomerName __attribute__((swift_name("walletCustomerName")));
@property (readonly) NSString *walletProviderId __attribute__((swift_name("walletProviderId")));
@property (readonly) NSString *walletProviderName __attribute__((swift_name("walletProviderName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PaymentBusinessModel")))
@interface DCAPIPaymentBusinessModel : DCAPIKotlinEnum<DCAPIPaymentBusinessModel *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPIPaymentBusinessModel *fullAcquirer __attribute__((swift_name("fullAcquirer")));
@property (class, readonly) DCAPIPaymentBusinessModel *van __attribute__((swift_name("van")));
+ (DCAPIKotlinArray<DCAPIPaymentBusinessModel *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPIPaymentBusinessModel *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("QrCodeTransactionQuery")))
@interface DCAPIQrCodeTransactionQuery : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId itk:(NSString *)itk orderId:(NSString *)orderId status:(NSString *)status transactionDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)transactionDate invoiceId:(int64_t)invoiceId paymentOrderId:(NSString *)paymentOrderId paymentType:(NSString *)paymentType walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName walletCustomerId:(NSString *)walletCustomerId walletCustomerName:(NSString *)walletCustomerName walletCustomerAccountNumber:(NSString *)walletCustomerAccountNumber walletCustomerAccountName:(NSString *)walletCustomerAccountName amount:(NSString * _Nullable)amount createdAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)createdAt approvedAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)approvedAt refusedAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)refusedAt transactionType:(NSString *)transactionType __attribute__((swift_name("init(transactionId:itk:orderId:status:transactionDate:invoiceId:paymentOrderId:paymentType:walletProviderId:walletProviderName:walletCustomerId:walletCustomerName:walletCustomerAccountNumber:walletCustomerAccountName:amount:createdAt:approvedAt:refusedAt:transactionType:)"))) __attribute__((objc_designated_initializer));
- (DCAPIQrCodeTransactionQuery *)doCopyTransactionId:(int64_t)transactionId itk:(NSString *)itk orderId:(NSString *)orderId status:(NSString *)status transactionDate:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)transactionDate invoiceId:(int64_t)invoiceId paymentOrderId:(NSString *)paymentOrderId paymentType:(NSString *)paymentType walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName walletCustomerId:(NSString *)walletCustomerId walletCustomerName:(NSString *)walletCustomerName walletCustomerAccountNumber:(NSString *)walletCustomerAccountNumber walletCustomerAccountName:(NSString *)walletCustomerAccountName amount:(NSString * _Nullable)amount createdAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)createdAt approvedAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)approvedAt refusedAt:(DCAPIKotlinx_datetimeLocalDateTime * _Nullable)refusedAt transactionType:(NSString *)transactionType __attribute__((swift_name("doCopy(transactionId:itk:orderId:status:transactionDate:invoiceId:paymentOrderId:paymentType:walletProviderId:walletProviderName:walletCustomerId:walletCustomerName:walletCustomerAccountNumber:walletCustomerAccountName:amount:createdAt:approvedAt:refusedAt:transactionType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable amount __attribute__((swift_name("amount")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable approvedAt __attribute__((swift_name("approvedAt")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property (readonly) int64_t invoiceId __attribute__((swift_name("invoiceId")));
@property (readonly) NSString *itk __attribute__((swift_name("itk")));
@property (readonly) NSString *orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString *paymentOrderId __attribute__((swift_name("paymentOrderId")));
@property (readonly) NSString *paymentType __attribute__((swift_name("paymentType")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable refusedAt __attribute__((swift_name("refusedAt")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime * _Nullable transactionDate __attribute__((swift_name("transactionDate")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@property (readonly) NSString *transactionType __attribute__((swift_name("transactionType")));
@property (readonly) NSString *walletCustomerAccountName __attribute__((swift_name("walletCustomerAccountName")));
@property (readonly) NSString *walletCustomerAccountNumber __attribute__((swift_name("walletCustomerAccountNumber")));
@property (readonly) NSString *walletCustomerId __attribute__((swift_name("walletCustomerId")));
@property (readonly) NSString *walletCustomerName __attribute__((swift_name("walletCustomerName")));
@property (readonly) NSString *walletProviderId __attribute__((swift_name("walletProviderId")));
@property (readonly) NSString *walletProviderName __attribute__((swift_name("walletProviderName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Status")))
@interface DCAPIStatus : DCAPIKotlinEnum<DCAPIStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPIStatus *pending __attribute__((swift_name("pending")));
@property (class, readonly) DCAPIStatus *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) DCAPIStatus *approved __attribute__((swift_name("approved")));
@property (class, readonly) DCAPIStatus *pendingReversal __attribute__((swift_name("pendingReversal")));
@property (class, readonly) DCAPIStatus *pendingCapture __attribute__((swift_name("pendingCapture")));
@property (class, readonly) DCAPIStatus *reversed __attribute__((swift_name("reversed")));
@property (class, readonly) DCAPIStatus *cancelled __attribute__((swift_name("cancelled")));
@property (class, readonly) DCAPIStatus *denied __attribute__((swift_name("denied")));
@property (class, readonly) DCAPIStatus *technicalError __attribute__((swift_name("technicalError")));
+ (DCAPIKotlinArray<DCAPIStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPIStatus *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("TransactionApi")))
@protocol DCAPITransactionApi
@required
- (id _Nullable)cancelCashTransactionTransactionId:(int64_t)transactionId orderId:(NSString *)orderId cancelDate:(DCAPIKotlinx_datetimeLocalDateTime *)cancelDate __attribute__((swift_name("cancelCashTransaction(transactionId:orderId:cancelDate:)")));
- (id _Nullable)configureInitialIdId:(int64_t)id __attribute__((swift_name("configureInitialId(id:)")));
- (id _Nullable)countApprovedPixTransactionsStartDate:(DCAPIKotlinx_datetimeLocalDateTime *)startDate endDate:(DCAPIKotlinx_datetimeLocalDateTime *)endDate __attribute__((swift_name("countApprovedPixTransactions(startDate:endDate:)")));
- (id _Nullable)deleteTransactionsBeforeDateDate:(DCAPIKotlinx_datetimeLocalDateTime *)date __attribute__((swift_name("deleteTransactionsBeforeDate(date:)")));
- (id _Nullable)getAllTransactions __attribute__((swift_name("getAllTransactions()")));
- (id _Nullable)getAllTransactionsBetweenDatesDateStart:(DCAPIKotlinx_datetimeLocalDateTime *)dateStart dateEnd:(DCAPIKotlinx_datetimeLocalDateTime *)dateEnd __attribute__((swift_name("getAllTransactionsBetweenDates(dateStart:dateEnd:)")));
- (id _Nullable)getApprovedPixTransactionsStartDate:(DCAPIKotlinx_datetimeLocalDateTime *)startDate endDate:(DCAPIKotlinx_datetimeLocalDateTime *)endDate max:(int32_t)max __attribute__((swift_name("getApprovedPixTransactions(startDate:endDate:max:)")));
- (id _Nullable)getCashTransactionsByStatusStatuses:(NSArray<DCAPIStatus *> *)statuses __attribute__((swift_name("getCashTransactionsByStatus(statuses:)")));
- (id _Nullable)getPendingInstantPaymentTransactionItk:(NSString *)itk __attribute__((swift_name("getPendingInstantPaymentTransaction(itk:)")));
- (id _Nullable)getPendingInstantPaymentTransactions __attribute__((swift_name("getPendingInstantPaymentTransactions()")));
- (id _Nullable)getPendingQrCodeCardPaymentTransactions __attribute__((swift_name("getPendingQrCodeCardPaymentTransactions()")));
- (id _Nullable)getTransactionTransactionId:(int64_t)transactionId __attribute__((swift_name("getTransaction(transactionId:)")));
- (id _Nullable)getTransactionByAtkAtk:(NSString *)atk __attribute__((swift_name("getTransactionByAtk(atk:)")));
- (id _Nullable)getTransactionsByFilterFilter:(DCAPIFilter *)filter __attribute__((swift_name("getTransactionsByFilter(filter:)")));
- (id _Nullable)offlineDenyTransactionTransactionId:(int64_t)transactionId __attribute__((swift_name("offlineDenyTransaction(transactionId:)")));
- (id _Nullable)saveCashTransactionItk:(NSString *)itk orderId:(NSString *)orderId amount:(NSString *)amount merchantStoneCode:(NSString *)merchantStoneCode paidAt:(DCAPIKotlinx_datetimeLocalDateTime *)paidAt __attribute__((swift_name("saveCashTransaction(itk:orderId:amount:merchantStoneCode:paidAt:)")));
- (id _Nullable)saveDeniedCashTransactionItk:(NSString *)itk amount:(NSString *)amount merchantStoneCode:(NSString *)merchantStoneCode deniedAt:(DCAPIKotlinx_datetimeLocalDateTime *)deniedAt __attribute__((swift_name("saveDeniedCashTransaction(itk:amount:merchantStoneCode:deniedAt:)")));
- (id _Nullable)saveTransactionTransaction:(DCAPITransactionCommand *)transaction __attribute__((swift_name("saveTransaction(transaction:)")));
- (id _Nullable)updateTransactionTransactionId:(int64_t)transactionId transaction:(DCAPITransactionCommand *)transaction __attribute__((swift_name("updateTransaction(transactionId:transaction:)")));
- (id _Nullable)updateTransactionCardTransactionId:(int64_t)transactionId card:(DCAPICardCommand *)card __attribute__((swift_name("updateTransactionCard(transactionId:card:)")));
- (id _Nullable)updateTransactionStatusTransactionId:(int64_t)transactionId status:(DCAPIStatus *)status __attribute__((swift_name("updateTransactionStatus(transactionId:status:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionCommand")))
@interface DCAPITransactionCommand : DCAPIBase
- (instancetype)initWithAmount:(NSString *)amount itk:(NSString *)itk orderId:(NSString *)orderId isCaptured:(BOOL)isCaptured pINPadUsed:(NSString *)pINPadUsed instalmentCount:(int32_t)instalmentCount instalmentType:(DCAPIInstalmentType *)instalmentType arqc:(NSString *)arqc dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime transactionReference:(NSString *)transactionReference paymentBusinessModel:(DCAPIPaymentBusinessModel *)paymentBusinessModel signature:(NSString *)signature card:(DCAPICard *)card status:(DCAPIStatus * _Nullable)status stoneCode:(NSString *)stoneCode subMerchantRegisteredIdentifier:(NSString * _Nullable)subMerchantRegisteredIdentifier isEmergencyAid:(BOOL)isEmergencyAid qualifier:(NSString * _Nullable)qualifier __attribute__((swift_name("init(amount:itk:orderId:isCaptured:pINPadUsed:instalmentCount:instalmentType:arqc:dateTime:transactionReference:paymentBusinessModel:signature:card:status:stoneCode:subMerchantRegisteredIdentifier:isEmergencyAid:qualifier:)"))) __attribute__((objc_designated_initializer));
- (DCAPITransactionCommand *)doCopyAmount:(NSString *)amount itk:(NSString *)itk orderId:(NSString *)orderId isCaptured:(BOOL)isCaptured pINPadUsed:(NSString *)pINPadUsed instalmentCount:(int32_t)instalmentCount instalmentType:(DCAPIInstalmentType *)instalmentType arqc:(NSString *)arqc dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime transactionReference:(NSString *)transactionReference paymentBusinessModel:(DCAPIPaymentBusinessModel *)paymentBusinessModel signature:(NSString *)signature card:(DCAPICard *)card status:(DCAPIStatus * _Nullable)status stoneCode:(NSString *)stoneCode subMerchantRegisteredIdentifier:(NSString * _Nullable)subMerchantRegisteredIdentifier isEmergencyAid:(BOOL)isEmergencyAid qualifier:(NSString * _Nullable)qualifier __attribute__((swift_name("doCopy(amount:itk:orderId:isCaptured:pINPadUsed:instalmentCount:instalmentType:arqc:dateTime:transactionReference:paymentBusinessModel:signature:card:status:stoneCode:subMerchantRegisteredIdentifier:isEmergencyAid:qualifier:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) NSString *arqc __attribute__((swift_name("arqc")));
@property (readonly) DCAPICard *card __attribute__((swift_name("card")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) int32_t instalmentCount __attribute__((swift_name("instalmentCount")));
@property (readonly) DCAPIInstalmentType *instalmentType __attribute__((swift_name("instalmentType")));
@property (readonly) BOOL isCaptured __attribute__((swift_name("isCaptured")));
@property (readonly) BOOL isEmergencyAid __attribute__((swift_name("isEmergencyAid"))) __attribute__((deprecated("From now on the Emergency Aid term is forbidden")));
@property (readonly) NSString *itk __attribute__((swift_name("itk")));
@property (readonly) NSString *orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString *pINPadUsed __attribute__((swift_name("pINPadUsed")));
@property (readonly) DCAPIPaymentBusinessModel *paymentBusinessModel __attribute__((swift_name("paymentBusinessModel")));
@property (readonly) NSString * _Nullable qualifier __attribute__((swift_name("qualifier")));
@property (readonly) NSString *signature __attribute__((swift_name("signature")));
@property (readonly) DCAPIStatus * _Nullable status __attribute__((swift_name("status")));
@property (readonly) NSString *stoneCode __attribute__((swift_name("stoneCode")));
@property (readonly) NSString * _Nullable subMerchantRegisteredIdentifier __attribute__((swift_name("subMerchantRegisteredIdentifier")));
@property (readonly) NSString *transactionReference __attribute__((swift_name("transactionReference")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionQuery")))
@interface DCAPITransactionQuery : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId amount:(NSString *)amount itk:(NSString *)itk orderId:(NSString *)orderId isCaptured:(BOOL)isCaptured pINPadUsed:(NSString *)pINPadUsed instalmentCount:(int32_t)instalmentCount instalmentType:(DCAPIInstalmentType *)instalmentType arqc:(NSString *)arqc dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime transactionReference:(NSString *)transactionReference paymentBusinessModel:(DCAPIPaymentBusinessModel *)paymentBusinessModel signature:(NSString *)signature card:(DCAPICard *)card stoneCode:(NSString *)stoneCode subMerchantRegisteredIdentifier:(NSString * _Nullable)subMerchantRegisteredIdentifier applicationId:(NSString *)applicationId status:(DCAPIStatus *)status isEmergencyAid:(BOOL)isEmergencyAid qualifier:(NSString * _Nullable)qualifier __attribute__((swift_name("init(transactionId:amount:itk:orderId:isCaptured:pINPadUsed:instalmentCount:instalmentType:arqc:dateTime:transactionReference:paymentBusinessModel:signature:card:stoneCode:subMerchantRegisteredIdentifier:applicationId:status:isEmergencyAid:qualifier:)"))) __attribute__((objc_designated_initializer));
- (DCAPITransactionQuery *)doCopyTransactionId:(int64_t)transactionId amount:(NSString *)amount itk:(NSString *)itk orderId:(NSString *)orderId isCaptured:(BOOL)isCaptured pINPadUsed:(NSString *)pINPadUsed instalmentCount:(int32_t)instalmentCount instalmentType:(DCAPIInstalmentType *)instalmentType arqc:(NSString *)arqc dateTime:(DCAPIKotlinx_datetimeLocalDateTime *)dateTime transactionReference:(NSString *)transactionReference paymentBusinessModel:(DCAPIPaymentBusinessModel *)paymentBusinessModel signature:(NSString *)signature card:(DCAPICard *)card stoneCode:(NSString *)stoneCode subMerchantRegisteredIdentifier:(NSString * _Nullable)subMerchantRegisteredIdentifier applicationId:(NSString *)applicationId status:(DCAPIStatus *)status isEmergencyAid:(BOOL)isEmergencyAid qualifier:(NSString * _Nullable)qualifier __attribute__((swift_name("doCopy(transactionId:amount:itk:orderId:isCaptured:pINPadUsed:instalmentCount:instalmentType:arqc:dateTime:transactionReference:paymentBusinessModel:signature:card:stoneCode:subMerchantRegisteredIdentifier:applicationId:status:isEmergencyAid:qualifier:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) NSString *applicationId __attribute__((swift_name("applicationId")));
@property (readonly) NSString *arqc __attribute__((swift_name("arqc")));
@property (readonly) DCAPICard *card __attribute__((swift_name("card")));
@property (readonly) DCAPIKotlinx_datetimeLocalDateTime *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) int32_t instalmentCount __attribute__((swift_name("instalmentCount")));
@property (readonly) DCAPIInstalmentType *instalmentType __attribute__((swift_name("instalmentType")));
@property (readonly) BOOL isCaptured __attribute__((swift_name("isCaptured")));
@property (readonly) BOOL isEmergencyAid __attribute__((swift_name("isEmergencyAid")));
@property (readonly) NSString *itk __attribute__((swift_name("itk")));
@property (readonly) NSString *orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString *pINPadUsed __attribute__((swift_name("pINPadUsed")));
@property (readonly) DCAPIPaymentBusinessModel *paymentBusinessModel __attribute__((swift_name("paymentBusinessModel")));
@property (readonly) NSString * _Nullable qualifier __attribute__((swift_name("qualifier")));
@property (readonly) NSString *signature __attribute__((swift_name("signature")));
@property (readonly) DCAPIStatus *status __attribute__((swift_name("status")));
@property (readonly) NSString *stoneCode __attribute__((swift_name("stoneCode")));
@property (readonly) NSString * _Nullable subMerchantRegisteredIdentifier __attribute__((swift_name("subMerchantRegisteredIdentifier")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@property (readonly) NSString *transactionReference __attribute__((swift_name("transactionReference")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionRepositoryImpl")))
@interface DCAPITransactionRepositoryImpl : DCAPIBase
- (instancetype)initWithTransactionDao:(id<DCAPIData_container_dataTransactionDao>)transactionDao connectionProvider:(id<DCAPIData_container_dataConnectionProvider>)connectionProvider __attribute__((swift_name("init(transactionDao:connectionProvider:)"))) __attribute__((objc_designated_initializer));
- (BOOL)cancelCashTransactionTransactionId:(int64_t)transactionId orderId:(NSString *)orderId cancelDate:(DCAPIKotlinx_datetimeLocalDateTime *)cancelDate __attribute__((swift_name("cancelCashTransaction(transactionId:orderId:cancelDate:)")));
- (id _Nullable)configureInitialIdId:(int64_t)id __attribute__((swift_name("configureInitialId(id:)")));
- (id _Nullable)countApprovedPixTransactionsStartDate:(DCAPIKotlinx_datetimeLocalDateTime *)startDate endDate:(DCAPIKotlinx_datetimeLocalDateTime *)endDate __attribute__((swift_name("countApprovedPixTransactions(startDate:endDate:)")));
- (id _Nullable)deleteTransactionsBeforeDateDate:(DCAPIKotlinx_datetimeLocalDateTime *)date __attribute__((swift_name("deleteTransactionsBeforeDate(date:)")));
- (id _Nullable)getAllTransactions __attribute__((swift_name("getAllTransactions()")));
- (id _Nullable)getAllTransactionsBetweenDatesDateStart:(DCAPIKotlinx_datetimeLocalDateTime *)dateStart dateEnd:(DCAPIKotlinx_datetimeLocalDateTime *)dateEnd __attribute__((swift_name("getAllTransactionsBetweenDates(dateStart:dateEnd:)")));
- (id _Nullable)getApprovedPixTransactionsStartDate:(DCAPIKotlinx_datetimeLocalDateTime *)startDate endDate:(DCAPIKotlinx_datetimeLocalDateTime *)endDate max:(int32_t)max __attribute__((swift_name("getApprovedPixTransactions(startDate:endDate:max:)")));
- (id _Nullable)getCashTransactionsByStatusStatuses:(NSArray<DCAPIStatus *> *)statuses __attribute__((swift_name("getCashTransactionsByStatus(statuses:)")));
- (id _Nullable)getPendingInstantPaymentTransactionItk:(NSString *)itk __attribute__((swift_name("getPendingInstantPaymentTransaction(itk:)")));
- (id _Nullable)getPendingInstantPaymentTransactions __attribute__((swift_name("getPendingInstantPaymentTransactions()")));
- (id _Nullable)getPendingQrCodeCardPaymentTransactions __attribute__((swift_name("getPendingQrCodeCardPaymentTransactions()")));
- (id _Nullable)getTransactionTransactionId:(int64_t)transactionId __attribute__((swift_name("getTransaction(transactionId:)")));
- (id _Nullable)getTransactionByAtkAtk:(NSString *)atk __attribute__((swift_name("getTransactionByAtk(atk:)")));
- (id _Nullable)getTransactionsByFilterFilter:(DCAPIFilter *)filter __attribute__((swift_name("getTransactionsByFilter(filter:)")));
- (id _Nullable)offlineDenyTransactionTransactionId:(int64_t)transactionId __attribute__((swift_name("offlineDenyTransaction(transactionId:)")));
- (id _Nullable)saveTransactionTransaction:(DCAPITransactionCommand *)transaction __attribute__((swift_name("saveTransaction(transaction:)")));
- (id _Nullable)updateTransactionTransactionId:(int64_t)transactionId transaction:(DCAPITransactionCommand *)transaction __attribute__((swift_name("updateTransaction(transactionId:transaction:)")));
- (id _Nullable)updateTransactionCardTransactionId:(int64_t)transactionId card:(DCAPICardCommand *)card __attribute__((swift_name("updateTransactionCard(transactionId:card:)")));
- (id _Nullable)updateTransactionStatusTransactionId:(int64_t)transactionId status:(DCAPIStatus *)status __attribute__((swift_name("updateTransactionStatus(transactionId:status:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionType")))
@interface DCAPITransactionType : DCAPIKotlinEnum<DCAPITransactionType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPITransactionType *credit __attribute__((swift_name("credit")));
@property (class, readonly) DCAPITransactionType *debit __attribute__((swift_name("debit")));
@property (class, readonly) DCAPITransactionType *voucher __attribute__((swift_name("voucher")));
@property (class, readonly) DCAPITransactionType *cash __attribute__((swift_name("cash")));
@property (class, readonly) DCAPITransactionType *instantPayment __attribute__((swift_name("instantPayment")));
+ (DCAPIKotlinArray<DCAPITransactionType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPITransactionType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VoucherType")))
@interface DCAPIVoucherType : DCAPIKotlinEnum<DCAPIVoucherType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPIVoucherType *none __attribute__((swift_name("none")));
@property (class, readonly) DCAPIVoucherType *restaurant __attribute__((swift_name("restaurant")));
@property (class, readonly) DCAPIVoucherType *supermarket __attribute__((swift_name("supermarket")));
@property (class, readonly) DCAPIVoucherType *culture __attribute__((swift_name("culture")));
@property (class, readonly) DCAPIVoucherType *auto_ __attribute__((swift_name("auto_")));
@property (class, readonly) DCAPIVoucherType *premium __attribute__((swift_name("premium")));
@property (class, readonly) DCAPIVoucherType *gift __attribute__((swift_name("gift")));
@property (class, readonly) DCAPIVoucherType *prepaid __attribute__((swift_name("prepaid")));
+ (DCAPIKotlinArray<DCAPIVoucherType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPIVoucherType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionToken")))
@interface DCAPITransactionToken : DCAPIBase
- (instancetype)initWithTransactionTokenAffiliationCode:(NSString *)transactionTokenAffiliationCode token:(NSString *)token compactToken:(NSString * _Nullable)compactToken expiresIn:(int32_t)expiresIn createdAt:(int64_t)createdAt __attribute__((swift_name("init(transactionTokenAffiliationCode:token:compactToken:expiresIn:createdAt:)"))) __attribute__((objc_designated_initializer));
- (DCAPITransactionToken *)doCopyTransactionTokenAffiliationCode:(NSString *)transactionTokenAffiliationCode token:(NSString *)token compactToken:(NSString * _Nullable)compactToken expiresIn:(int32_t)expiresIn createdAt:(int64_t)createdAt __attribute__((swift_name("doCopy(transactionTokenAffiliationCode:token:compactToken:expiresIn:createdAt:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable compactToken __attribute__((swift_name("compactToken")));
@property (readonly) int64_t createdAt __attribute__((swift_name("createdAt")));
@property (readonly) int32_t expiresIn __attribute__((swift_name("expiresIn")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@property (readonly) NSString *transactionTokenAffiliationCode __attribute__((swift_name("transactionTokenAffiliationCode")));
@end

__attribute__((swift_name("TransactionTokenApi")))
@protocol DCAPITransactionTokenApi
@required
- (id _Nullable)deleteAllTransactionsTokens __attribute__((swift_name("deleteAllTransactionsTokens()")));
- (id _Nullable)deleteCompactTokenAffiliationCode:(NSString *)affiliationCode __attribute__((swift_name("deleteCompactToken(affiliationCode:)")));
- (id _Nullable)getTransactionTokenByAffiliationCodeAffiliationCode:(NSString *)affiliationCode __attribute__((swift_name("getTransactionTokenByAffiliationCode(affiliationCode:)")));
- (id _Nullable)isValidAffiliationCode:(NSString *)affiliationCode __attribute__((swift_name("isValid(affiliationCode:)")));
- (id _Nullable)saveTransactionTokenTransactionTokenCommand:(DCAPITransactionTokenCommand *)transactionTokenCommand __attribute__((swift_name("saveTransactionToken(transactionTokenCommand:)")));
- (id _Nullable)setNullableTransactionCompactTokenTransactionTokenCommand:(DCAPITransactionTokenCommand *)transactionTokenCommand __attribute__((swift_name("setNullableTransactionCompactToken(transactionTokenCommand:)")));
- (id _Nullable)updateTransactionTokenTransactionTokenCommand:(DCAPITransactionTokenCommand *)transactionTokenCommand __attribute__((swift_name("updateTransactionToken(transactionTokenCommand:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionTokenCommand")))
@interface DCAPITransactionTokenCommand : DCAPIBase
- (instancetype)initWithTransactionTokenAffiliationCode:(NSString *)transactionTokenAffiliationCode token:(NSString *)token compactToken:(NSString * _Nullable)compactToken expiresIn:(int32_t)expiresIn createdAt:(int64_t)createdAt __attribute__((swift_name("init(transactionTokenAffiliationCode:token:compactToken:expiresIn:createdAt:)"))) __attribute__((objc_designated_initializer));
- (DCAPITransactionTokenCommand *)doCopyTransactionTokenAffiliationCode:(NSString *)transactionTokenAffiliationCode token:(NSString *)token compactToken:(NSString * _Nullable)compactToken expiresIn:(int32_t)expiresIn createdAt:(int64_t)createdAt __attribute__((swift_name("doCopy(transactionTokenAffiliationCode:token:compactToken:expiresIn:createdAt:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable compactToken __attribute__((swift_name("compactToken")));
@property (readonly) int64_t createdAt __attribute__((swift_name("createdAt")));
@property (readonly) int32_t expiresIn __attribute__((swift_name("expiresIn")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@property (readonly) NSString *transactionTokenAffiliationCode __attribute__((swift_name("transactionTokenAffiliationCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Cypher")))
@interface DCAPICypher : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)cypher __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPICypher *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)decryptValueEncrypted:(NSString *)valueEncrypted completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("decrypt(valueEncrypted:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)encryptValue:(NSString *)value completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("encrypt(value:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SecurityUtil")))
@interface DCAPISecurityUtil : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)securityUtil __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPISecurityUtil *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)encryptStringInput:(NSString *)input completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("encryptString(input:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)validateHashInput:(NSString *)input hashedInput:(NSString *)hashedInput completionHandler:(void (^)(DCAPIBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("validateHash(input:hashedInput:completionHandler:)")));
@end

__attribute__((swift_name("Lib_commonsPlatformContext")))
@interface DCAPILib_commonsPlatformContext : DCAPIBase
@property (class, readonly, getter=companion) DCAPILib_commonsPlatformContextCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((swift_name("Data_container_dataAccountPixDao")))
@protocol DCAPIData_container_dataAccountPixDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAccountPixMerchantId:(int64_t)merchantId completionHandler:(void (^)(NSArray<DCAPIData_container_dataAccountPixEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAccountPix(merchantId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAccountPixByAccountIdAccountId:(NSString *)accountId completionHandler:(void (^)(DCAPIData_container_dataAccountPixEntity * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getAccountPixByAccountId(accountId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertAccountPixEntity:(DCAPIData_container_dataAccountPixEntity *)accountPixEntity completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(accountPixEntity:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateAccountPixEntity:(DCAPIData_container_dataAccountPixEntity *)accountPixEntity completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("update(accountPixEntity:completionHandler:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/datetime/serializers/LocalDateTimeIso8601Serializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDateTime")))
@interface DCAPIKotlinx_datetimeLocalDateTime : DCAPIBase <DCAPIKotlinComparable>
- (instancetype)initWithDate:(DCAPIKotlinx_datetimeLocalDate *)date time:(DCAPIKotlinx_datetimeLocalTime *)time __attribute__((swift_name("init(date:time:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithYear:(int32_t)year monthNumber:(int32_t)monthNumber dayOfMonth:(int32_t)dayOfMonth hour:(int32_t)hour minute:(int32_t)minute second:(int32_t)second nanosecond:(int32_t)nanosecond __attribute__((swift_name("init(year:monthNumber:dayOfMonth:hour:minute:second:nanosecond:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithYear:(int32_t)year month:(DCAPIKotlinx_datetimeMonth *)month dayOfMonth:(int32_t)dayOfMonth hour:(int32_t)hour minute:(int32_t)minute second:(int32_t)second nanosecond:(int32_t)nanosecond __attribute__((swift_name("init(year:month:dayOfMonth:hour:minute:second:nanosecond:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) DCAPIKotlinx_datetimeLocalDateTimeCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(DCAPIKotlinx_datetimeLocalDateTime *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPIKotlinx_datetimeLocalDate *date __attribute__((swift_name("date")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) DCAPIKotlinx_datetimeDayOfWeek *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hour __attribute__((swift_name("hour")));
@property (readonly) int32_t minute __attribute__((swift_name("minute")));
@property (readonly) DCAPIKotlinx_datetimeMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t monthNumber __attribute__((swift_name("monthNumber")));
@property (readonly) int32_t nanosecond __attribute__((swift_name("nanosecond")));
@property (readonly) int32_t second __attribute__((swift_name("second")));
@property (readonly) DCAPIKotlinx_datetimeLocalTime *time __attribute__((swift_name("time")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end

__attribute__((swift_name("Data_container_dataAuthorizationDao")))
@protocol DCAPIData_container_dataAuthorizationDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAuthorizationByAtkAtk:(NSString *)atk completionHandler:(void (^)(NSArray<DCAPIData_container_dataAuthorizationEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAuthorizationByAtk(atk:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAuthorizationByTransactionIdTransactionId:(int64_t)transactionId completionHandler:(void (^)(NSArray<DCAPIData_container_dataAuthorizationEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAuthorizationByTransactionId(transactionId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertAuthorization:(DCAPIData_container_dataAuthorizationEntity *)authorization completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(authorization:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertWithCardBalanceTransactionDao:(id<DCAPIData_container_dataTransactionDao>)transactionDao authorization:(DCAPIData_container_dataAuthorizationEntity *)authorization cardBalance:(NSString *)cardBalance completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insertWithCardBalance(transactionDao:authorization:cardBalance:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataTransactionDao")))
@protocol DCAPIData_container_dataTransactionDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)cancelCashTransactionTransactionId:(int64_t)transactionId orderId:(NSString *)orderId cancelDate:(NSString *)cancelDate completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("cancelCashTransaction(transactionId:orderId:cancelDate:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)countApprovedPixTransactionsStartDate:(NSString *)startDate endDate:(NSString *)endDate status:(NSString *)status completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("countApprovedPixTransactions(startDate:endDate:status:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteTransactionEntity:(DCAPIData_container_dataTransactionEntity *)transactionEntity completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("delete(transactionEntity:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteTransactionsBeforeDateDate:(NSString *)date completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteTransactionsBeforeDate(date:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllTransactionsBetweenDatesDateStart:(NSString *)dateStart dateEnd:(NSString *)dateEnd completionHandler:(void (^)(NSArray<DCAPIData_container_dataTransactionEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllTransactionsBetweenDates(dateStart:dateEnd:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getApprovedPixTransactionsStartDate:(NSString *)startDate endDate:(NSString *)endDate max:(int32_t)max completionHandler:(void (^)(NSArray<DCAPIData_container_dataPixApprovedTransactionView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getApprovedPixTransactions(startDate:endDate:max:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCashTransactionByStatusStatus:(NSString *)status completionHandler:(void (^)(NSArray<DCAPIData_container_dataTransactionEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCashTransactionByStatus(status:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPendingInstantPaymentTransactionItk:(NSString *)itk completionHandler:(void (^)(DCAPIData_container_dataQrCodePaymentTransactionView * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getPendingInstantPaymentTransaction(itk:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPendingInstantPaymentTransactionsWithCompletionHandler:(void (^)(NSArray<DCAPIData_container_dataQrCodePaymentTransactionView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getPendingInstantPaymentTransactions(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPendingQrCodeCardPaymentTransactionsWithCompletionHandler:(void (^)(NSArray<DCAPIData_container_dataQrCodePaymentTransactionView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getPendingQrCodeCardPaymentTransactions(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTransactionByAtkAtk:(NSString *)atk completionHandler:(void (^)(DCAPIData_container_dataAuthorizationTransactionView * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getTransactionByAtk(atk:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTransactionByFilterSqLiteConnection:(id<DCAPISqliteSQLiteConnection>)sqLiteConnection query:(NSString *)query completionHandler:(void (^)(NSArray<DCAPIData_container_dataTransactionEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getTransactionByFilter(sqLiteConnection:query:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTransactionByIdTransactionId:(int64_t)transactionId completionHandler:(void (^)(DCAPIData_container_dataTransactionEntity * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getTransactionById(transactionId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTransactionsWithCompletionHandler:(void (^)(NSArray<DCAPIData_container_dataTransactionEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getTransactions(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTransactionsByAffiliationCodeAffiliationCode:(NSString *)affiliationCode completionHandler:(void (^)(NSArray<DCAPIData_container_dataTransactionEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getTransactionsByAffiliationCode(affiliationCode:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTransactionsByQueryQuery:(DCAPIRoom_runtimeRoomRawQuery *)query completionHandler:(void (^)(NSArray<DCAPIData_container_dataTransactionEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getTransactionsByQuery(query:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertTransactionEntity:(DCAPIData_container_dataTransactionEntity *)transactionEntity completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(transactionEntity:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateAffiliationCodeOlderAffiliationCode:(NSString *)olderAffiliationCode newAffiliationCode:(NSString *)newAffiliationCode completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateAffiliationCode(olderAffiliationCode:newAffiliationCode:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateTransactionTransactionEntity:(DCAPIData_container_dataTransactionEntity *)transactionEntity completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateTransaction(transactionEntity:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataCancellationDao")))
@protocol DCAPIData_container_dataCancellationDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCancellationsByAtkAtk:(NSString *)atk completionHandler:(void (^)(NSArray<DCAPIData_container_dataCancellationEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCancellationsByAtk(atk:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCancellationsByTransactionIdTransactionId:(int64_t)transactionId completionHandler:(void (^)(NSArray<DCAPIData_container_dataCancellationEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCancellationsByTransactionId(transactionId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertCancellationEntity:(DCAPIData_container_dataCancellationEntity *)cancellationEntity completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(cancellationEntity:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertWithCardBalanceAuthorizationDao:(id<DCAPIData_container_dataAuthorizationDao>)authorizationDao transactionDao:(id<DCAPIData_container_dataTransactionDao>)transactionDao cancellation:(DCAPIData_container_dataCancellationEntity *)cancellation cardBalance:(NSString *)cardBalance completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insertWithCardBalance(authorizationDao:transactionDao:cancellation:cardBalance:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataCaptureRequestDao")))
@protocol DCAPIData_container_dataCaptureRequestDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCaptureRequestByTransactionIdTransactionId:(int64_t)transactionId completionHandler:(void (^)(NSArray<DCAPIData_container_dataCaptureRequestEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCaptureRequestByTransactionId(transactionId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPendingCapturesWithCompletionHandler:(void (^)(NSArray<DCAPIData_container_dataCaptureRequestEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getPendingCaptures(completionHandler:)"))) __attribute__((deprecated("Use TransactionToCaptureDao instead of this method")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertCaptureRequest:(DCAPIData_container_dataCaptureRequestEntity *)captureRequest completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(captureRequest:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataTransactionToCaptureDao")))
@protocol DCAPIData_container_dataTransactionToCaptureDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTransactionsToCaptureWithCompletionHandler:(void (^)(NSArray<DCAPIData_container_dataTransactionToCaptureView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getTransactionsToCapture(completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataHistoricTransactionDao")))
@protocol DCAPIData_container_dataHistoricTransactionDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getManualCaptureRequiredTransactionsHistoricWithCompletionHandler:(void (^)(NSArray<DCAPIData_container_dataHistoricTransactionView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getManualCaptureRequiredTransactionsHistoric(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getManualCaptureRequiredTransactionsHistoricPanLastFourDigits:(NSString *)panLastFourDigits completionHandler:(void (^)(NSArray<DCAPIData_container_dataHistoricTransactionView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getManualCaptureRequiredTransactionsHistoric(panLastFourDigits:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getManualCaptureRequiredTransactionsHistoricStartDate:(NSString *)startDate endDate:(NSString *)endDate completionHandler:(void (^)(NSArray<DCAPIData_container_dataHistoricTransactionView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getManualCaptureRequiredTransactionsHistoric(startDate:endDate:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataCaptureDao")))
@protocol DCAPIData_container_dataCaptureDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCaptureByTransactionIdTransactionId:(int64_t)transactionId completionHandler:(void (^)(NSArray<DCAPIData_container_dataCaptureEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCaptureByTransactionId(transactionId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertCapture:(DCAPIData_container_dataCaptureEntity *)capture completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(capture:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataCredentialsDao")))
@protocol DCAPIData_container_dataCredentialsDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCredentialsAffiliationCode:(NSString *)affiliationCode completionHandler:(void (^)(DCAPIData_container_dataCredentialsEntity * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getCredentials(affiliationCode:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertCredentialsCredentialsEntity:(DCAPIData_container_dataCredentialsEntity *)credentialsEntity completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insertCredentials(credentialsEntity:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateAffiliationCodeOlderAffiliationCode:(NSString *)olderAffiliationCode newAffiliationCode:(NSString *)newAffiliationCode completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateAffiliationCode(olderAffiliationCode:newAffiliationCode:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateCredentialsCredentialsEntity:(DCAPIData_container_dataCredentialsEntity *)credentialsEntity completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateCredentials(credentialsEntity:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataDccDao")))
@protocol DCAPIData_container_dataDccDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDccByCancellationCancellationId:(int64_t)cancellationId completionHandler:(void (^)(DCAPIData_container_dataDccEntity * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getDccByCancellation(cancellationId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getDccByTransactionTransactionId:(int64_t)transactionId completionHandler:(void (^)(DCAPIData_container_dataDccEntity * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getDccByTransaction(transactionId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertDccEntity:(DCAPIData_container_dataDccEntity *)dccEntity completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(dccEntity:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataErrorInformationDao")))
@protocol DCAPIData_container_dataErrorInformationDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getErrorInformationStartDate:(NSString * _Nullable)startDate endDate:(NSString * _Nullable)endDate limit:(int32_t)limit completionHandler:(void (^)(NSArray<DCAPIData_container_dataErrorInformationEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getErrorInformation(startDate:endDate:limit:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertErrorsEntity:(DCAPIData_container_dataErrorInformationEntity *)errorsEntity completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(errorsEntity:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface DCAPIKotlinArray<T> : DCAPIBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(DCAPIInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<DCAPIKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Data_container_dataFullReceiptDao")))
@protocol DCAPIData_container_dataFullReceiptDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getFullReceiptByIdReceiptId:(int64_t)receiptId completionHandler:(void (^)(DCAPIData_container_dataFullReceiptView * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getFullReceiptById(receiptId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getFullReceiptsWithCompletionHandler:(void (^)(NSArray<DCAPIData_container_dataFullReceiptView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getFullReceipts(completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataInvoiceDao")))
@protocol DCAPIData_container_dataInvoiceDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getInvoiceByIdInvoiceId:(int64_t)invoiceId completionHandler:(void (^)(DCAPIData_container_dataInvoiceEntity * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getInvoiceById(invoiceId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getInvoiceByTransactionIdTransactionId:(int64_t)transactionId completionHandler:(void (^)(DCAPIData_container_dataInvoiceEntity * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getInvoiceByTransactionId(transactionId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getInvoicesWithCompletionHandler:(void (^)(NSArray<DCAPIData_container_dataInvoiceEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getInvoices(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getInvoicesBetweenDatesDateStart:(NSString *)dateStart dateEnd:(NSString *)dateEnd completionHandler:(void (^)(NSArray<DCAPIData_container_dataInvoiceEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getInvoicesBetweenDates(dateStart:dateEnd:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertInvoice:(DCAPIData_container_dataInvoiceEntity *)invoice completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(invoice:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateInvoiceInvoice:(DCAPIData_container_dataInvoiceEntity *)invoice completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateInvoice(invoice:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_contractTaxIdentificationType")))
@interface DCAPIData_container_contractTaxIdentificationType : DCAPIKotlinEnum<DCAPIData_container_contractTaxIdentificationType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPIData_container_contractTaxIdentificationType *cpf __attribute__((swift_name("cpf")));
@property (class, readonly) DCAPIData_container_contractTaxIdentificationType *cnpj __attribute__((swift_name("cnpj")));
+ (DCAPIKotlinArray<DCAPIData_container_contractTaxIdentificationType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPIData_container_contractTaxIdentificationType *> *entries __attribute__((swift_name("entries")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_contractCardBrand")))
@interface DCAPIData_container_contractCardBrand : DCAPIBase
- (instancetype)initWithId:(int32_t)id description:(NSString *)description type:(int32_t)type __attribute__((swift_name("init(id:description:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) DCAPIData_container_contractCardBrandCompanion *companion __attribute__((swift_name("companion")));
- (DCAPIData_container_contractCardBrand *)doCopyId:(int32_t)id description:(NSString *)description type:(int32_t)type __attribute__((swift_name("doCopy(id:description:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@property (readonly) int32_t type __attribute__((swift_name("type")));
@end

__attribute__((swift_name("Data_container_dataMerchantDao")))
@protocol DCAPIData_container_dataMerchantDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteMerchantEntity:(DCAPIData_container_dataMerchantEntity *)merchantEntity completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("delete(merchantEntity:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteAllWithCompletionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteAll(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteByStoneCodeStoneCode:(NSString *)stoneCode completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteByStoneCode(stoneCode:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllMerchantWithCompletionHandler:(void (^)(NSArray<DCAPIData_container_dataMerchantEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllMerchant(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getFirstMerchantWithCompletionHandler:(void (^)(DCAPIData_container_dataMerchantEntity * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getFirstMerchant(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getMerchantStoneCode:(NSString *)stoneCode completionHandler:(void (^)(DCAPIData_container_dataMerchantEntity * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getMerchant(stoneCode:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertMerchantEntity:(DCAPIData_container_dataMerchantEntity *)merchantEntity completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(merchantEntity:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertOrUpdateMerchantEntity:(DCAPIData_container_dataMerchantEntity *)merchantEntity completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insertOrUpdate(merchantEntity:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateMerchantEntity:(DCAPIData_container_dataMerchantEntity *)merchantEntity completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("update(merchantEntity:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateAffiliationCodeOlder_affiliation_code:(NSString *)older_affiliation_code new_affiliation_code:(NSString *)new_affiliation_code completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateAffiliationCode(older_affiliation_code:new_affiliation_code:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataSubMerchantDao")))
@protocol DCAPIData_container_dataSubMerchantDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSubMerchantsByParentAffiliationCodeParentAffiliationCode:(NSString *)parentAffiliationCode completionHandler:(void (^)(NSArray<DCAPIData_container_dataSubMerchantEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSubMerchantsByParentAffiliationCode(parentAffiliationCode:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertSubMerchantEntity:(DCAPIData_container_dataSubMerchantEntity *)subMerchantEntity completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(subMerchantEntity:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateAffiliationCodeOlderAffiliationCode:(NSString *)olderAffiliationCode newAffiliationCode:(NSString *)newAffiliationCode completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateAffiliationCode(olderAffiliationCode:newAffiliationCode:completionHandler:)")));
@end

__attribute__((swift_name("Room_runtimeRoomDatabase")))
@interface DCAPIRoom_runtimeRoomDatabase : DCAPIBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)close __attribute__((swift_name("close()")));

/**
 * @note annotations
 *   androidx.annotation.RestrictTo(value=[Scope.LIBRARY_GROUP])
*/
- (NSArray<DCAPIRoom_runtimeMigration *> *)createAutoMigrationsAutoMigrationSpecs:(NSDictionary<id<DCAPIKotlinKClass>, id<DCAPIRoom_runtimeAutoMigrationSpec>> *)autoMigrationSpecs __attribute__((swift_name("createAutoMigrations(autoMigrationSpecs:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (DCAPIRoom_runtimeInvalidationTracker *)createInvalidationTracker __attribute__((swift_name("createInvalidationTracker()")));

/**
 * @note annotations
 *   androidx.annotation.RestrictTo(value=[Scope.LIBRARY_GROUP])
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id<DCAPIRoom_runtimeRoomOpenDelegateMarker>)createOpenDelegate __attribute__((swift_name("createOpenDelegate()")));

/**
 * @note annotations
 *   androidx.annotation.RestrictTo(value=[Scope.LIBRARY_GROUP])
*/
- (id<DCAPIKotlinx_coroutines_coreCoroutineScope>)getCoroutineScope __attribute__((swift_name("getCoroutineScope()")));

/**
 * @note annotations
 *   androidx.annotation.RestrictTo(value=[Scope.LIBRARY_GROUP])
*/
- (NSSet<id<DCAPIKotlinKClass>> *)getRequiredAutoMigrationSpecClasses __attribute__((swift_name("getRequiredAutoMigrationSpecClasses()")));

/**
 * @note annotations
 *   androidx.annotation.RestrictTo(value=[Scope.LIBRARY_GROUP])
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (NSDictionary<id<DCAPIKotlinKClass>, NSArray<id<DCAPIKotlinKClass>> *> *)getRequiredTypeConverterClasses __attribute__((swift_name("getRequiredTypeConverterClasses()")));

/**
 * @note annotations
 *   androidx.annotation.RestrictTo(value=[Scope.LIBRARY_GROUP])
*/
- (id)getTypeConverterKlass:(id<DCAPIKotlinKClass>)klass __attribute__((swift_name("getTypeConverter(klass:)")));

/**
 * @note annotations
 *   androidx.annotation.RestrictTo(value=[Scope.LIBRARY_GROUP_PREFIX])
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)internalInitInvalidationTrackerConnection:(id<DCAPISqliteSQLiteConnection>)connection __attribute__((swift_name("internalInitInvalidationTracker(connection:)")));
@property (readonly) DCAPIRoom_runtimeInvalidationTracker *invalidationTracker __attribute__((swift_name("invalidationTracker")));
@end

__attribute__((swift_name("Data_container_dataDB")))
@protocol DCAPIData_container_dataDB
@required
- (void)clearAllTables __attribute__((swift_name("clearAllTables()")));
@end

__attribute__((swift_name("Data_container_dataDataContainerDataBase")))
@interface DCAPIData_container_dataDataContainerDataBase : DCAPIRoom_runtimeRoomDatabase <DCAPIData_container_dataDB>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) DCAPIData_container_dataDataContainerDataBaseCompanion *companion __attribute__((swift_name("companion")));
- (id<DCAPIData_container_dataAccountPixDao>)accountPixDao __attribute__((swift_name("accountPixDao()")));
- (id<DCAPIData_container_dataAuthorizationDao>)authorizationDao __attribute__((swift_name("authorizationDao()")));
- (id<DCAPIData_container_dataCancellationDao>)cancellationDao __attribute__((swift_name("cancellationDao()")));
- (id<DCAPIData_container_dataCaptureDao>)captureDao __attribute__((swift_name("captureDao()")));
- (id<DCAPIData_container_dataCaptureRequestDao>)captureRequestDao __attribute__((swift_name("captureRequestDao()")));
- (void)clearAllTables __attribute__((swift_name("clearAllTables()")));
- (id<DCAPIData_container_dataCredentialsDao>)credentialsDao __attribute__((swift_name("credentialsDao()")));
- (id<DCAPIData_container_dataDccDao>)dccDao __attribute__((swift_name("dccDao()")));
- (id<DCAPIData_container_dataErrorInformationDao>)errorInformationDao __attribute__((swift_name("errorInformationDao()")));
- (id<DCAPIData_container_dataFullReceiptDao>)fullReceiptDao __attribute__((swift_name("fullReceiptDao()")));
- (id<DCAPIData_container_dataFullTransactionDao>)fullTransactionDao __attribute__((swift_name("fullTransactionDao()")));
- (id<DCAPIData_container_dataHistoricTransactionDao>)historicTransactionDao __attribute__((swift_name("historicTransactionDao()")));
- (id<DCAPIData_container_dataInvoiceDao>)invoiceDao __attribute__((swift_name("invoiceDao()")));
- (id<DCAPIData_container_dataMerchantDao>)merchantDao __attribute__((swift_name("merchantDao()")));
- (id<DCAPIData_container_dataProbeRequestDao>)probeRequestDao __attribute__((swift_name("probeRequestDao()")));
- (id<DCAPIData_container_dataProbeRequiredDao>)probeRequiredDao __attribute__((swift_name("probeRequiredDao()")));
- (id<DCAPIData_container_dataReportDao>)reportDao __attribute__((swift_name("reportDao()")));
- (id<DCAPIData_container_dataReversalRequestDao>)reversalRequestDao __attribute__((swift_name("reversalRequestDao()")));
- (id<DCAPIData_container_dataReversalRequiredDao>)reversalRequiredDao __attribute__((swift_name("reversalRequiredDao()")));
- (id<DCAPIData_container_dataSalesHistoryDao>)salesHistoryDao __attribute__((swift_name("salesHistoryDao()")));
- (id<DCAPIData_container_dataSubMerchantDao>)subMerchantDao __attribute__((swift_name("subMerchantDao()")));
- (id<DCAPIData_container_dataTransactionDao>)transactionDao __attribute__((swift_name("transactionDao()")));
- (id<DCAPIData_container_dataTransactionToCaptureDao>)transactionToCaptureDao __attribute__((swift_name("transactionToCaptureDao()")));
- (id<DCAPIData_container_dataTransactionTokenDao>)transactionTokenDao __attribute__((swift_name("transactionTokenDao()")));
@end

__attribute__((swift_name("Data_container_dataProbeRequestDao")))
@protocol DCAPIData_container_dataProbeRequestDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getProbeRequestByTransactionIdTransactionId:(int64_t)transactionId completionHandler:(void (^)(NSArray<DCAPIData_container_dataProbeRequestEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getProbeRequestByTransactionId(transactionId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertProbeRequest:(DCAPIData_container_dataProbeRequestEntity *)probeRequest completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(probeRequest:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataProbeRequiredDao")))
@protocol DCAPIData_container_dataProbeRequiredDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getProbeRequiredByTransactionIdTransactionId:(int64_t)transactionId completionHandler:(void (^)(NSArray<DCAPIData_container_dataProbeRequiredEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getProbeRequiredByTransactionId(transactionId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRequiredProbeByQuerySQLiteConnection:(id<DCAPISqliteSQLiteConnection>)sQLiteConnection query:(NSString *)query completionHandler:(void (^)(NSArray<DCAPIData_container_dataProbeRequiredEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRequiredProbeByQuery(sQLiteConnection:query:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertProbeRequired:(DCAPIData_container_dataProbeRequiredEntity *)probeRequired completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(probeRequired:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataConnectionProvider")))
@protocol DCAPIData_container_dataConnectionProvider
@required
- (int32_t)deleteSql:(NSString *)sql __attribute__((swift_name("delete(sql:)")));
- (id<DCAPISqliteSQLiteConnection>)provideConnection __attribute__((swift_name("provideConnection()")));
- (id _Nullable)querySql:(NSString *)sql block:(id _Nullable (^)(id<DCAPISqliteSQLiteStatement>))block __attribute__((swift_name("query(sql:block:)")));
- (int32_t)updateSql:(NSString *)sql __attribute__((swift_name("update(sql:)")));
- (id _Nullable)withConnectionBlock:(id _Nullable (^)(id<DCAPISqliteSQLiteConnection>))block __attribute__((swift_name("withConnection(block:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface DCAPIKotlinEnumCompanion : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPIKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Data_container_dataReportDao")))
@protocol DCAPIData_container_dataReportDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)generateReportCashPaymentStoneCode:(NSString *)stoneCode transactionType:(NSString * _Nullable)transactionType startDate:(NSString *)startDate endDate:(NSString *)endDate completionHandler:(void (^)(NSArray<DCAPIData_container_dataReportCashPaymentView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("generateReportCashPayment(stoneCode:transactionType:startDate:endDate:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getReportDetailedDataStartReportDate:(NSString *)startReportDate endReportDate:(NSString *)endReportDate stoneCode:(NSString *)stoneCode statusCode:(NSString *)statusCode completionHandler:(void (^)(NSArray<DCAPIData_container_dataReportData *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getReportDetailedData(startReportDate:endReportDate:stoneCode:statusCode:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getReportQrCodeStartReportDate:(NSString *)startReportDate endReportDate:(NSString *)endReportDate stoneCode:(NSString *)stoneCode transactionType:(NSString * _Nullable)transactionType completionHandler:(void (^)(NSArray<DCAPIData_container_dataReportQrCode *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getReportQrCode(startReportDate:endReportDate:stoneCode:transactionType:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getReportWalletStartReportDate:(NSString *)startReportDate endReportDate:(NSString *)endReportDate stoneCode:(NSString *)stoneCode completionHandler:(void (^)(NSArray<DCAPIData_container_dataReportWallet *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getReportWallet(startReportDate:endReportDate:stoneCode:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSummaryQrCodeStartReportDate:(NSString *)startReportDate endReportDate:(NSString *)endReportDate stoneCode:(NSString *)stoneCode transactionType:(NSString * _Nullable)transactionType completionHandler:(void (^)(DCAPIData_container_dataReportSummaryQrCodeEntity * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSummaryQrCode(startReportDate:endReportDate:stoneCode:transactionType:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSummaryWalletStartReportDate:(NSString *)startReportDate endReportDate:(NSString *)endReportDate stoneCode:(NSString *)stoneCode completionHandler:(void (^)(DCAPIData_container_dataReportSummaryWallet * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSummaryWallet(startReportDate:endReportDate:stoneCode:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataReversalRequestDao")))
@protocol DCAPIData_container_dataReversalRequestDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteReversalRequest:(DCAPIData_container_dataReversalRequestEntity *)reversalRequest completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("delete(reversalRequest:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getReversalRequestByTransactionIdTransactionId:(int64_t)transactionId completionHandler:(void (^)(NSArray<DCAPIData_container_dataReversalRequestEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getReversalRequestByTransactionId(transactionId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertReversalRequest:(DCAPIData_container_dataReversalRequestEntity *)reversalRequest completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(reversalRequest:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataReversalRequiredDao")))
@protocol DCAPIData_container_dataReversalRequiredDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllReversalRequiredWithCompletionHandler:(void (^)(NSArray<DCAPIData_container_dataReversalRequiredEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllReversalRequired(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getReversalRequiredByTransactionIdTransactionId:(int64_t)transactionId completionHandler:(void (^)(NSArray<DCAPIData_container_dataReversalRequiredEntity *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getReversalRequiredByTransactionId(transactionId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertReversalRequired:(DCAPIData_container_dataReversalRequiredEntity *)reversalRequired completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(reversalRequired:completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataSalesHistoryDao")))
@protocol DCAPIData_container_dataSalesHistoryDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllSalesHistoryBetweenDatesStartDate:(NSString *)startDate endDate:(NSString *)endDate completionHandler:(void (^)(NSArray<DCAPIData_container_dataSalesHistoryView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllSalesHistoryBetweenDates(startDate:endDate:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSalesHistoryWithCompletionHandler:(void (^)(NSArray<DCAPIData_container_dataSalesHistoryView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSalesHistory(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSalesHistoryByFilterSqLiteConnection:(id<DCAPISqliteSQLiteConnection>)sqLiteConnection query:(NSString *)query completionHandler:(void (^)(NSArray<DCAPIData_container_dataSalesHistoryView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSalesHistoryByFilter(sqLiteConnection:query:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSalesHistoryByIdSalesHistoryId:(int64_t)salesHistoryId completionHandler:(void (^)(DCAPIData_container_dataSalesHistoryView * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSalesHistoryById(salesHistoryId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSalesHistoryRowsStartDate:(NSString *)startDate endDate:(NSString *)endDate completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSalesHistoryRows(startDate:endDate:completionHandler:)")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface DCAPIKotlinThrowable : DCAPIBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(DCAPIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(DCAPIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (DCAPIKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPIKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface DCAPIKotlinException : DCAPIKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(DCAPIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(DCAPIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface DCAPIKotlinRuntimeException : DCAPIKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(DCAPIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(DCAPIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface DCAPIKotlinIllegalStateException : DCAPIKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(DCAPIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(DCAPIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface DCAPIKotlinCancellationException : DCAPIKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(DCAPIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(DCAPIKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Data_container_dataSystemConfigDao")))
@interface DCAPIData_container_dataSystemConfigDao : DCAPIBase
- (instancetype)initWithProducePath:(NSString *(^)(void))producePath isDebug:(BOOL)isDebug migrations:(NSArray<id<DCAPIDatastore_coreDataMigration>> *)migrations __attribute__((swift_name("init(producePath:isDebug:migrations:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) DCAPIData_container_dataSystemConfigDaoCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getKey:(NSString *)key completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("get(key:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getEnvironmentWithCompletionHandler:(void (^)(DCAPIData_container_dataEnvironmentEnum * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getEnvironment(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)setKey:(NSString *)key value:(NSString *)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("set(key:value:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)setEnvironmentEnvironmentEnum:(DCAPIData_container_dataEnvironmentEnum *)environmentEnum completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("setEnvironment(environmentEnum:completionHandler:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<DCAPIDatastore_coreDataStore> dataStore __attribute__((swift_name("dataStore")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Lib_commonsPlatformContext.Companion")))
@interface DCAPILib_commonsPlatformContextCompanion : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPILib_commonsPlatformContextCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) DCAPILib_commonsPlatformContext *INSTANCE __attribute__((swift_name("INSTANCE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataAccountPixEntity")))
@interface DCAPIData_container_dataAccountPixEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id accountId:(NSString *)accountId accountNumber:(NSString *)accountNumber keyCreated:(BOOL)keyCreated merchantId:(int64_t)merchantId __attribute__((swift_name("init(id:accountId:accountNumber:keyCreated:merchantId:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataAccountPixEntity *)doCopyId:(DCAPILong * _Nullable)id accountId:(NSString *)accountId accountNumber:(NSString *)accountNumber keyCreated:(BOOL)keyCreated merchantId:(int64_t)merchantId __attribute__((swift_name("doCopy(id:accountId:accountNumber:keyCreated:merchantId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountId __attribute__((swift_name("accountId")));
@property (readonly) NSString *accountNumber __attribute__((swift_name("accountNumber")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) BOOL keyCreated __attribute__((swift_name("keyCreated")));
@property (readonly) int64_t merchantId __attribute__((swift_name("merchantId")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/datetime/serializers/LocalDateIso8601Serializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDate")))
@interface DCAPIKotlinx_datetimeLocalDate : DCAPIBase <DCAPIKotlinComparable>
- (instancetype)initWithYear:(int32_t)year monthNumber:(int32_t)monthNumber dayOfMonth:(int32_t)dayOfMonth __attribute__((swift_name("init(year:monthNumber:dayOfMonth:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithYear:(int32_t)year month:(DCAPIKotlinx_datetimeMonth *)month dayOfMonth:(int32_t)dayOfMonth __attribute__((swift_name("init(year:month:dayOfMonth:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) DCAPIKotlinx_datetimeLocalDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(DCAPIKotlinx_datetimeLocalDate *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (int32_t)toEpochDays __attribute__((swift_name("toEpochDays()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) DCAPIKotlinx_datetimeDayOfWeek *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) DCAPIKotlinx_datetimeMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t monthNumber __attribute__((swift_name("monthNumber")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/datetime/serializers/LocalTimeIso8601Serializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalTime")))
@interface DCAPIKotlinx_datetimeLocalTime : DCAPIBase <DCAPIKotlinComparable>
- (instancetype)initWithHour:(int32_t)hour minute:(int32_t)minute second:(int32_t)second nanosecond:(int32_t)nanosecond __attribute__((swift_name("init(hour:minute:second:nanosecond:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) DCAPIKotlinx_datetimeLocalTimeCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(DCAPIKotlinx_datetimeLocalTime *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (int32_t)toMillisecondOfDay __attribute__((swift_name("toMillisecondOfDay()")));
- (int64_t)toNanosecondOfDay __attribute__((swift_name("toNanosecondOfDay()")));
- (int32_t)toSecondOfDay __attribute__((swift_name("toSecondOfDay()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t hour __attribute__((swift_name("hour")));
@property (readonly) int32_t minute __attribute__((swift_name("minute")));
@property (readonly) int32_t nanosecond __attribute__((swift_name("nanosecond")));
@property (readonly) int32_t second __attribute__((swift_name("second")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeMonth")))
@interface DCAPIKotlinx_datetimeMonth : DCAPIKotlinEnum<DCAPIKotlinx_datetimeMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPIKotlinx_datetimeMonth *january __attribute__((swift_name("january")));
@property (class, readonly) DCAPIKotlinx_datetimeMonth *february __attribute__((swift_name("february")));
@property (class, readonly) DCAPIKotlinx_datetimeMonth *march __attribute__((swift_name("march")));
@property (class, readonly) DCAPIKotlinx_datetimeMonth *april __attribute__((swift_name("april")));
@property (class, readonly) DCAPIKotlinx_datetimeMonth *may __attribute__((swift_name("may")));
@property (class, readonly) DCAPIKotlinx_datetimeMonth *june __attribute__((swift_name("june")));
@property (class, readonly) DCAPIKotlinx_datetimeMonth *july __attribute__((swift_name("july")));
@property (class, readonly) DCAPIKotlinx_datetimeMonth *august __attribute__((swift_name("august")));
@property (class, readonly) DCAPIKotlinx_datetimeMonth *september __attribute__((swift_name("september")));
@property (class, readonly) DCAPIKotlinx_datetimeMonth *october __attribute__((swift_name("october")));
@property (class, readonly) DCAPIKotlinx_datetimeMonth *november __attribute__((swift_name("november")));
@property (class, readonly) DCAPIKotlinx_datetimeMonth *december __attribute__((swift_name("december")));
+ (DCAPIKotlinArray<DCAPIKotlinx_datetimeMonth *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPIKotlinx_datetimeMonth *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDateTime.Companion")))
@interface DCAPIKotlinx_datetimeLocalDateTimeCompanion : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPIKotlinx_datetimeLocalDateTimeCompanion *shared __attribute__((swift_name("shared")));
- (id<DCAPIKotlinx_datetimeDateTimeFormat>)FormatBuilder:(void (^)(id<DCAPIKotlinx_datetimeDateTimeFormatBuilderWithDateTime>))builder __attribute__((swift_name("Format(builder:)")));
- (DCAPIKotlinx_datetimeLocalDateTime *)parseInput:(id)input format:(id<DCAPIKotlinx_datetimeDateTimeFormat>)format __attribute__((swift_name("parse(input:format:)")));
- (id<DCAPIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeDayOfWeek")))
@interface DCAPIKotlinx_datetimeDayOfWeek : DCAPIKotlinEnum<DCAPIKotlinx_datetimeDayOfWeek *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPIKotlinx_datetimeDayOfWeek *monday __attribute__((swift_name("monday")));
@property (class, readonly) DCAPIKotlinx_datetimeDayOfWeek *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) DCAPIKotlinx_datetimeDayOfWeek *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) DCAPIKotlinx_datetimeDayOfWeek *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) DCAPIKotlinx_datetimeDayOfWeek *friday __attribute__((swift_name("friday")));
@property (class, readonly) DCAPIKotlinx_datetimeDayOfWeek *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) DCAPIKotlinx_datetimeDayOfWeek *sunday __attribute__((swift_name("sunday")));
+ (DCAPIKotlinArray<DCAPIKotlinx_datetimeDayOfWeek *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPIKotlinx_datetimeDayOfWeek *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataAuthorizationEntity")))
@interface DCAPIData_container_dataAuthorizationEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId atk:(NSString *)atk amountAuthorized:(NSString *)amountAuthorized authorizationCode:(NSString *)authorizationCode dateTime:(NSString *)dateTime __attribute__((swift_name("init(id:transactionId:atk:amountAuthorized:authorizationCode:dateTime:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataAuthorizationEntity *)doCopyId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId atk:(NSString *)atk amountAuthorized:(NSString *)amountAuthorized authorizationCode:(NSString *)authorizationCode dateTime:(NSString *)dateTime __attribute__((swift_name("doCopy(id:transactionId:atk:amountAuthorized:authorizationCode:dateTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amountAuthorized __attribute__((swift_name("amountAuthorized")));
@property (readonly) NSString *atk __attribute__((swift_name("atk")));
@property (readonly) NSString *authorizationCode __attribute__((swift_name("authorizationCode")));
@property (readonly) NSString *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataTransactionEntity")))
@interface DCAPIData_container_dataTransactionEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id amount:(NSString *)amount itk:(NSString *)itk orderId:(NSString *)orderId isCaptured:(BOOL)isCaptured pinpadUsed:(NSString *)pinpadUsed instalmentCount:(int32_t)instalmentCount instalmentType:(NSString *)instalmentType arqc:(NSString *)arqc dateTime:(NSString *)dateTime transactionReference:(NSString *)transactionReference paymentBusinessModel:(NSString *)paymentBusinessModel signature:(NSString *)signature stoneCode:(NSString *)stoneCode subMerchantRegisteredIdentifier:(NSString * _Nullable)subMerchantRegisteredIdentifier isEmergencyAid:(BOOL)isEmergencyAid appIdentification:(NSString *)appIdentification status:(NSString *)status qualifier:(NSString * _Nullable)qualifier card:(DCAPIData_container_dataCardEntity *)card __attribute__((swift_name("init(id:amount:itk:orderId:isCaptured:pinpadUsed:instalmentCount:instalmentType:arqc:dateTime:transactionReference:paymentBusinessModel:signature:stoneCode:subMerchantRegisteredIdentifier:isEmergencyAid:appIdentification:status:qualifier:card:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataTransactionEntity *)doCopyId:(DCAPILong * _Nullable)id amount:(NSString *)amount itk:(NSString *)itk orderId:(NSString *)orderId isCaptured:(BOOL)isCaptured pinpadUsed:(NSString *)pinpadUsed instalmentCount:(int32_t)instalmentCount instalmentType:(NSString *)instalmentType arqc:(NSString *)arqc dateTime:(NSString *)dateTime transactionReference:(NSString *)transactionReference paymentBusinessModel:(NSString *)paymentBusinessModel signature:(NSString *)signature stoneCode:(NSString *)stoneCode subMerchantRegisteredIdentifier:(NSString * _Nullable)subMerchantRegisteredIdentifier isEmergencyAid:(BOOL)isEmergencyAid appIdentification:(NSString *)appIdentification status:(NSString *)status qualifier:(NSString * _Nullable)qualifier card:(DCAPIData_container_dataCardEntity *)card __attribute__((swift_name("doCopy(id:amount:itk:orderId:isCaptured:pinpadUsed:instalmentCount:instalmentType:arqc:dateTime:transactionReference:paymentBusinessModel:signature:stoneCode:subMerchantRegisteredIdentifier:isEmergencyAid:appIdentification:status:qualifier:card:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) NSString *appIdentification __attribute__((swift_name("appIdentification")));
@property (readonly) NSString *arqc __attribute__((swift_name("arqc")));
@property (readonly) DCAPIData_container_dataCardEntity *card __attribute__((swift_name("card")));
@property (readonly) NSString *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) int32_t instalmentCount __attribute__((swift_name("instalmentCount")));
@property (readonly) NSString *instalmentType __attribute__((swift_name("instalmentType")));
@property (readonly) BOOL isCaptured __attribute__((swift_name("isCaptured")));
@property (readonly) BOOL isEmergencyAid __attribute__((swift_name("isEmergencyAid")));
@property (readonly) NSString *itk __attribute__((swift_name("itk")));
@property (readonly) NSString *orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString *paymentBusinessModel __attribute__((swift_name("paymentBusinessModel")));
@property (readonly) NSString *pinpadUsed __attribute__((swift_name("pinpadUsed")));
@property (readonly) NSString * _Nullable qualifier __attribute__((swift_name("qualifier")));
@property (readonly) NSString *signature __attribute__((swift_name("signature")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) NSString *stoneCode __attribute__((swift_name("stoneCode")));
@property (readonly) NSString * _Nullable subMerchantRegisteredIdentifier __attribute__((swift_name("subMerchantRegisteredIdentifier")));
@property (readonly) NSString *transactionReference __attribute__((swift_name("transactionReference")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataPixApprovedTransactionView")))
@interface DCAPIData_container_dataPixApprovedTransactionView : DCAPIBase
- (instancetype)initWithId:(int64_t)id itk:(NSString *)itk orderId:(NSString *)orderId status:(NSString *)status transactionDate:(NSString * _Nullable)transactionDate invoiceId:(NSString *)invoiceId transactionType:(NSString *)transactionType entryMode:(NSString *)entryMode paymentOrderId:(NSString *)paymentOrderId paymentType:(NSString *)paymentType walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName walletCustomerId:(NSString *)walletCustomerId walletCustomerName:(NSString *)walletCustomerName walletCustomerAccountNumber:(NSString *)walletCustomerAccountNumber walletCustomerAccountName:(NSString *)walletCustomerAccountName amount:(NSString * _Nullable)amount createdAt:(NSString * _Nullable)createdAt approvedAt:(NSString * _Nullable)approvedAt refusedAt:(NSString * _Nullable)refusedAt __attribute__((swift_name("init(id:itk:orderId:status:transactionDate:invoiceId:transactionType:entryMode:paymentOrderId:paymentType:walletProviderId:walletProviderName:walletCustomerId:walletCustomerName:walletCustomerAccountNumber:walletCustomerAccountName:amount:createdAt:approvedAt:refusedAt:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataPixApprovedTransactionView *)doCopyId:(int64_t)id itk:(NSString *)itk orderId:(NSString *)orderId status:(NSString *)status transactionDate:(NSString * _Nullable)transactionDate invoiceId:(NSString *)invoiceId transactionType:(NSString *)transactionType entryMode:(NSString *)entryMode paymentOrderId:(NSString *)paymentOrderId paymentType:(NSString *)paymentType walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName walletCustomerId:(NSString *)walletCustomerId walletCustomerName:(NSString *)walletCustomerName walletCustomerAccountNumber:(NSString *)walletCustomerAccountNumber walletCustomerAccountName:(NSString *)walletCustomerAccountName amount:(NSString * _Nullable)amount createdAt:(NSString * _Nullable)createdAt approvedAt:(NSString * _Nullable)approvedAt refusedAt:(NSString * _Nullable)refusedAt __attribute__((swift_name("doCopy(id:itk:orderId:status:transactionDate:invoiceId:transactionType:entryMode:paymentOrderId:paymentType:walletProviderId:walletProviderName:walletCustomerId:walletCustomerName:walletCustomerAccountNumber:walletCustomerAccountName:amount:createdAt:approvedAt:refusedAt:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable amount __attribute__((swift_name("amount")));
@property (readonly) NSString * _Nullable approvedAt __attribute__((swift_name("approvedAt")));
@property (readonly) NSString * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property (readonly) NSString *entryMode __attribute__((swift_name("entryMode")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) NSString *invoiceId __attribute__((swift_name("invoiceId")));
@property (readonly) NSString *itk __attribute__((swift_name("itk")));
@property (readonly) NSString *orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString *paymentOrderId __attribute__((swift_name("paymentOrderId")));
@property (readonly) NSString *paymentType __attribute__((swift_name("paymentType")));
@property (readonly) NSString * _Nullable refusedAt __attribute__((swift_name("refusedAt")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) NSString * _Nullable transactionDate __attribute__((swift_name("transactionDate")));
@property (readonly) NSString *transactionType __attribute__((swift_name("transactionType")));
@property (readonly) NSString *walletCustomerAccountName __attribute__((swift_name("walletCustomerAccountName")));
@property (readonly) NSString *walletCustomerAccountNumber __attribute__((swift_name("walletCustomerAccountNumber")));
@property (readonly) NSString *walletCustomerId __attribute__((swift_name("walletCustomerId")));
@property (readonly) NSString *walletCustomerName __attribute__((swift_name("walletCustomerName")));
@property (readonly) NSString *walletProviderId __attribute__((swift_name("walletProviderId")));
@property (readonly) NSString *walletProviderName __attribute__((swift_name("walletProviderName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataQrCodePaymentTransactionView")))
@interface DCAPIData_container_dataQrCodePaymentTransactionView : DCAPIBase
- (instancetype)initWithId:(int64_t)id itk:(NSString *)itk orderId:(NSString *)orderId status:(NSString *)status transactionDate:(NSString * _Nullable)transactionDate invoiceId:(NSString *)invoiceId transactionType:(NSString *)transactionType entryMode:(NSString *)entryMode paymentOrderId:(NSString *)paymentOrderId paymentType:(NSString *)paymentType walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName walletCustomerId:(NSString *)walletCustomerId walletCustomerName:(NSString *)walletCustomerName walletCustomerAccountNumber:(NSString *)walletCustomerAccountNumber walletCustomerAccountName:(NSString *)walletCustomerAccountName amount:(NSString * _Nullable)amount createdAt:(NSString * _Nullable)createdAt approvedAt:(NSString * _Nullable)approvedAt refusedAt:(NSString * _Nullable)refusedAt __attribute__((swift_name("init(id:itk:orderId:status:transactionDate:invoiceId:transactionType:entryMode:paymentOrderId:paymentType:walletProviderId:walletProviderName:walletCustomerId:walletCustomerName:walletCustomerAccountNumber:walletCustomerAccountName:amount:createdAt:approvedAt:refusedAt:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataQrCodePaymentTransactionView *)doCopyId:(int64_t)id itk:(NSString *)itk orderId:(NSString *)orderId status:(NSString *)status transactionDate:(NSString * _Nullable)transactionDate invoiceId:(NSString *)invoiceId transactionType:(NSString *)transactionType entryMode:(NSString *)entryMode paymentOrderId:(NSString *)paymentOrderId paymentType:(NSString *)paymentType walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName walletCustomerId:(NSString *)walletCustomerId walletCustomerName:(NSString *)walletCustomerName walletCustomerAccountNumber:(NSString *)walletCustomerAccountNumber walletCustomerAccountName:(NSString *)walletCustomerAccountName amount:(NSString * _Nullable)amount createdAt:(NSString * _Nullable)createdAt approvedAt:(NSString * _Nullable)approvedAt refusedAt:(NSString * _Nullable)refusedAt __attribute__((swift_name("doCopy(id:itk:orderId:status:transactionDate:invoiceId:transactionType:entryMode:paymentOrderId:paymentType:walletProviderId:walletProviderName:walletCustomerId:walletCustomerName:walletCustomerAccountNumber:walletCustomerAccountName:amount:createdAt:approvedAt:refusedAt:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable amount __attribute__((swift_name("amount")));
@property (readonly) NSString * _Nullable approvedAt __attribute__((swift_name("approvedAt")));
@property (readonly) NSString * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property (readonly) NSString *entryMode __attribute__((swift_name("entryMode")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) NSString *invoiceId __attribute__((swift_name("invoiceId")));
@property (readonly) NSString *itk __attribute__((swift_name("itk")));
@property (readonly) NSString *orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString *paymentOrderId __attribute__((swift_name("paymentOrderId")));
@property (readonly) NSString *paymentType __attribute__((swift_name("paymentType")));
@property (readonly) NSString * _Nullable refusedAt __attribute__((swift_name("refusedAt")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) NSString * _Nullable transactionDate __attribute__((swift_name("transactionDate")));
@property (readonly) NSString *transactionType __attribute__((swift_name("transactionType")));
@property (readonly) NSString *walletCustomerAccountName __attribute__((swift_name("walletCustomerAccountName")));
@property (readonly) NSString *walletCustomerAccountNumber __attribute__((swift_name("walletCustomerAccountNumber")));
@property (readonly) NSString *walletCustomerId __attribute__((swift_name("walletCustomerId")));
@property (readonly) NSString *walletCustomerName __attribute__((swift_name("walletCustomerName")));
@property (readonly) NSString *walletProviderId __attribute__((swift_name("walletProviderId")));
@property (readonly) NSString *walletProviderName __attribute__((swift_name("walletProviderName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataAuthorizationTransactionView")))
@interface DCAPIData_container_dataAuthorizationTransactionView : DCAPIBase
- (instancetype)initWithId:(int64_t)id transactionDate:(NSString * _Nullable)transactionDate amount:(NSString *)amount transactionReference:(NSString *)transactionReference stoneCode:(NSString *)stoneCode signature:(NSString *)signature pinpadUsed:(NSString *)pinpadUsed orderId:(NSString *)orderId isCaptured:(BOOL)isCaptured instalmentCount:(int32_t)instalmentCount arqc:(NSString *)arqc itk:(NSString *)itk paymentBusinessModel:(NSString *)paymentBusinessModel applicationId:(NSString *)applicationId subMerchantRegisteredIdentifier:(NSString * _Nullable)subMerchantRegisteredIdentifier pan:(NSString *)pan aid:(NSString *)aid cvm:(NSString *)cvm appLabel:(NSString *)appLabel cardholderName:(NSString *)cardholderName accountBalance:(NSString *)accountBalance cardholderNameExtended:(NSString *)cardholderNameExtended transactionType:(NSString *)transactionType voucherType:(NSString *)voucherType serviceCode:(NSString *)serviceCode atcPayment:(NSString * _Nullable)atcPayment atcCancellation:(NSString * _Nullable)atcCancellation sequenceNumber:(NSString * _Nullable)sequenceNumber brandId:(int32_t)brandId brandName:(NSString *)brandName email:(NSString *)email entryMode:(NSString *)entryMode instalmentType:(NSString *)instalmentType isEmergencyAid:(BOOL)isEmergencyAid status:(NSString *)status qualifier:(NSString * _Nullable)qualifier authTransactionId:(int64_t)authTransactionId atk:(NSString *)atk amountAuthorized:(NSString *)amountAuthorized authorizationCode:(NSString *)authorizationCode authDateTime:(NSString *)authDateTime __attribute__((swift_name("init(id:transactionDate:amount:transactionReference:stoneCode:signature:pinpadUsed:orderId:isCaptured:instalmentCount:arqc:itk:paymentBusinessModel:applicationId:subMerchantRegisteredIdentifier:pan:aid:cvm:appLabel:cardholderName:accountBalance:cardholderNameExtended:transactionType:voucherType:serviceCode:atcPayment:atcCancellation:sequenceNumber:brandId:brandName:email:entryMode:instalmentType:isEmergencyAid:status:qualifier:authTransactionId:atk:amountAuthorized:authorizationCode:authDateTime:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataAuthorizationTransactionView *)doCopyId:(int64_t)id transactionDate:(NSString * _Nullable)transactionDate amount:(NSString *)amount transactionReference:(NSString *)transactionReference stoneCode:(NSString *)stoneCode signature:(NSString *)signature pinpadUsed:(NSString *)pinpadUsed orderId:(NSString *)orderId isCaptured:(BOOL)isCaptured instalmentCount:(int32_t)instalmentCount arqc:(NSString *)arqc itk:(NSString *)itk paymentBusinessModel:(NSString *)paymentBusinessModel applicationId:(NSString *)applicationId subMerchantRegisteredIdentifier:(NSString * _Nullable)subMerchantRegisteredIdentifier pan:(NSString *)pan aid:(NSString *)aid cvm:(NSString *)cvm appLabel:(NSString *)appLabel cardholderName:(NSString *)cardholderName accountBalance:(NSString *)accountBalance cardholderNameExtended:(NSString *)cardholderNameExtended transactionType:(NSString *)transactionType voucherType:(NSString *)voucherType serviceCode:(NSString *)serviceCode atcPayment:(NSString * _Nullable)atcPayment atcCancellation:(NSString * _Nullable)atcCancellation sequenceNumber:(NSString * _Nullable)sequenceNumber brandId:(int32_t)brandId brandName:(NSString *)brandName email:(NSString *)email entryMode:(NSString *)entryMode instalmentType:(NSString *)instalmentType isEmergencyAid:(BOOL)isEmergencyAid status:(NSString *)status qualifier:(NSString * _Nullable)qualifier authTransactionId:(int64_t)authTransactionId atk:(NSString *)atk amountAuthorized:(NSString *)amountAuthorized authorizationCode:(NSString *)authorizationCode authDateTime:(NSString *)authDateTime __attribute__((swift_name("doCopy(id:transactionDate:amount:transactionReference:stoneCode:signature:pinpadUsed:orderId:isCaptured:instalmentCount:arqc:itk:paymentBusinessModel:applicationId:subMerchantRegisteredIdentifier:pan:aid:cvm:appLabel:cardholderName:accountBalance:cardholderNameExtended:transactionType:voucherType:serviceCode:atcPayment:atcCancellation:sequenceNumber:brandId:brandName:email:entryMode:instalmentType:isEmergencyAid:status:qualifier:authTransactionId:atk:amountAuthorized:authorizationCode:authDateTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountBalance __attribute__((swift_name("accountBalance")));
@property (readonly) NSString *aid __attribute__((swift_name("aid")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) NSString *amountAuthorized __attribute__((swift_name("amountAuthorized")));
@property (readonly) NSString *appLabel __attribute__((swift_name("appLabel")));
@property (readonly) NSString *applicationId __attribute__((swift_name("applicationId")));
@property (readonly) NSString *arqc __attribute__((swift_name("arqc")));
@property (readonly) NSString * _Nullable atcCancellation __attribute__((swift_name("atcCancellation")));
@property (readonly) NSString * _Nullable atcPayment __attribute__((swift_name("atcPayment")));
@property (readonly) NSString *atk __attribute__((swift_name("atk")));
@property (readonly) NSString *authDateTime __attribute__((swift_name("authDateTime")));
@property (readonly) int64_t authTransactionId __attribute__((swift_name("authTransactionId")));
@property (readonly) NSString *authorizationCode __attribute__((swift_name("authorizationCode")));
@property (readonly) int32_t brandId __attribute__((swift_name("brandId")));
@property (readonly) NSString *brandName __attribute__((swift_name("brandName")));
@property (readonly) NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property (readonly) NSString *cardholderNameExtended __attribute__((swift_name("cardholderNameExtended")));
@property (readonly) NSString *cvm __attribute__((swift_name("cvm")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString *entryMode __attribute__((swift_name("entryMode")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) int32_t instalmentCount __attribute__((swift_name("instalmentCount")));
@property (readonly) NSString *instalmentType __attribute__((swift_name("instalmentType")));
@property (readonly) BOOL isCaptured __attribute__((swift_name("isCaptured")));
@property (readonly) BOOL isEmergencyAid __attribute__((swift_name("isEmergencyAid")));
@property (readonly) NSString *itk __attribute__((swift_name("itk")));
@property (readonly) NSString *orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString *pan __attribute__((swift_name("pan")));
@property (readonly) NSString *paymentBusinessModel __attribute__((swift_name("paymentBusinessModel")));
@property (readonly) NSString *pinpadUsed __attribute__((swift_name("pinpadUsed")));
@property (readonly) NSString * _Nullable qualifier __attribute__((swift_name("qualifier")));
@property (readonly) NSString * _Nullable sequenceNumber __attribute__((swift_name("sequenceNumber")));
@property (readonly) NSString *serviceCode __attribute__((swift_name("serviceCode")));
@property (readonly) NSString *signature __attribute__((swift_name("signature")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) NSString *stoneCode __attribute__((swift_name("stoneCode")));
@property (readonly) NSString * _Nullable subMerchantRegisteredIdentifier __attribute__((swift_name("subMerchantRegisteredIdentifier")));
@property (readonly) NSString * _Nullable transactionDate __attribute__((swift_name("transactionDate")));
@property (readonly) NSString *transactionReference __attribute__((swift_name("transactionReference")));
@property (readonly) NSString *transactionType __attribute__((swift_name("transactionType")));
@property (readonly) NSString *voucherType __attribute__((swift_name("voucherType")));
@end

__attribute__((swift_name("SqliteSQLiteConnection")))
@protocol DCAPISqliteSQLiteConnection
@required
- (void)close __attribute__((swift_name("close()")));
- (id<DCAPISqliteSQLiteStatement>)prepareSql:(NSString *)sql __attribute__((swift_name("prepare(sql:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Room_runtimeRoomRawQuery")))
@interface DCAPIRoom_runtimeRoomRawQuery : DCAPIBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithSql:(NSString *)sql onBindStatement:(void (^)(id<DCAPISqliteSQLiteStatement>))onBindStatement __attribute__((swift_name("init(sql:onBindStatement:)"))) __attribute__((objc_designated_initializer));
- (void (^)(id<DCAPISqliteSQLiteStatement>))getBindingFunction __attribute__((swift_name("getBindingFunction()")));
@property (readonly) NSString *sql __attribute__((swift_name("sql")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataCancellationEntity")))
@interface DCAPIData_container_dataCancellationEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id atk:(NSString *)atk amount:(NSString *)amount dateTime:(NSString *)dateTime authorizationCode:(NSString * _Nullable)authorizationCode __attribute__((swift_name("init(id:atk:amount:dateTime:authorizationCode:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataCancellationEntity *)doCopyId:(DCAPILong * _Nullable)id atk:(NSString *)atk amount:(NSString *)amount dateTime:(NSString *)dateTime authorizationCode:(NSString * _Nullable)authorizationCode __attribute__((swift_name("doCopy(id:atk:amount:dateTime:authorizationCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) NSString *atk __attribute__((swift_name("atk")));
@property (readonly) NSString * _Nullable authorizationCode __attribute__((swift_name("authorizationCode")));
@property (readonly) NSString *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataCaptureRequestEntity")))
@interface DCAPIData_container_dataCaptureRequestEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId iccRelatedData:(NSString *)iccRelatedData __attribute__((swift_name("init(id:transactionId:iccRelatedData:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataCaptureRequestEntity *)doCopyId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId iccRelatedData:(NSString *)iccRelatedData __attribute__((swift_name("doCopy(id:transactionId:iccRelatedData:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *iccRelatedData __attribute__((swift_name("iccRelatedData")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataTransactionToCaptureView")))
@interface DCAPIData_container_dataTransactionToCaptureView : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId itk:(NSString *)itk amountAuthorized:(NSString *)amountAuthorized atk:(NSString *)atk iccRelatedData:(NSString * _Nullable)iccRelatedData transactionType:(NSString * _Nullable)transactionType brandId:(DCAPILong * _Nullable)brandId status:(NSString * _Nullable)status brandName:(NSString * _Nullable)brandName cardHolderName:(NSString * _Nullable)cardHolderName cardPan:(NSString * _Nullable)cardPan cardEntryMode:(NSString * _Nullable)cardEntryMode amount:(NSString * _Nullable)amount createDate:(NSString * _Nullable)createDate __attribute__((swift_name("init(transactionId:itk:amountAuthorized:atk:iccRelatedData:transactionType:brandId:status:brandName:cardHolderName:cardPan:cardEntryMode:amount:createDate:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataTransactionToCaptureView *)doCopyTransactionId:(int64_t)transactionId itk:(NSString *)itk amountAuthorized:(NSString *)amountAuthorized atk:(NSString *)atk iccRelatedData:(NSString * _Nullable)iccRelatedData transactionType:(NSString * _Nullable)transactionType brandId:(DCAPILong * _Nullable)brandId status:(NSString * _Nullable)status brandName:(NSString * _Nullable)brandName cardHolderName:(NSString * _Nullable)cardHolderName cardPan:(NSString * _Nullable)cardPan cardEntryMode:(NSString * _Nullable)cardEntryMode amount:(NSString * _Nullable)amount createDate:(NSString * _Nullable)createDate __attribute__((swift_name("doCopy(transactionId:itk:amountAuthorized:atk:iccRelatedData:transactionType:brandId:status:brandName:cardHolderName:cardPan:cardEntryMode:amount:createDate:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable amount __attribute__((swift_name("amount")));
@property (readonly) NSString *amountAuthorized __attribute__((swift_name("amountAuthorized")));
@property (readonly) NSString *atk __attribute__((swift_name("atk")));
@property (readonly) DCAPILong * _Nullable brandId __attribute__((swift_name("brandId")));
@property (readonly) NSString * _Nullable brandName __attribute__((swift_name("brandName")));
@property (readonly) NSString * _Nullable cardEntryMode __attribute__((swift_name("cardEntryMode")));
@property (readonly) NSString * _Nullable cardHolderName __attribute__((swift_name("cardHolderName")));
@property (readonly) NSString * _Nullable cardPan __attribute__((swift_name("cardPan")));
@property (readonly) NSString * _Nullable createDate __attribute__((swift_name("createDate")));
@property (readonly) NSString * _Nullable iccRelatedData __attribute__((swift_name("iccRelatedData")));
@property (readonly) NSString *itk __attribute__((swift_name("itk")));
@property (readonly) NSString * _Nullable status __attribute__((swift_name("status")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@property (readonly) NSString * _Nullable transactionType __attribute__((swift_name("transactionType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataHistoricTransactionView")))
@interface DCAPIData_container_dataHistoricTransactionView : DCAPIBase
- (instancetype)initWithTransactionId:(int64_t)transactionId itk:(NSString *)itk amountAuthorized:(NSString *)amountAuthorized atk:(NSString *)atk arqc:(NSString * _Nullable)arqc orderId:(NSString * _Nullable)orderId authorizationCode:(NSString * _Nullable)authorizationCode extendedModality:(NSString * _Nullable)extendedModality reducedModality:(NSString * _Nullable)reducedModality iccRelatedData:(NSString * _Nullable)iccRelatedData transactionType:(NSString * _Nullable)transactionType status:(NSString * _Nullable)status isCaptured:(DCAPIBoolean * _Nullable)isCaptured brandId:(DCAPILong * _Nullable)brandId brandName:(NSString * _Nullable)brandName cardHolderName:(NSString * _Nullable)cardHolderName cardPan:(NSString * _Nullable)cardPan cardEntryMode:(NSString * _Nullable)cardEntryMode amount:(NSString * _Nullable)amount createDate:(NSString * _Nullable)createDate applicationIdentifier:(NSString * _Nullable)applicationIdentifier applicationLabel:(NSString * _Nullable)applicationLabel stoneCode:(NSString * _Nullable)stoneCode cardCvm:(NSString * _Nullable)cardCvm captureAmountTotal:(NSString *)captureAmountTotal __attribute__((swift_name("init(transactionId:itk:amountAuthorized:atk:arqc:orderId:authorizationCode:extendedModality:reducedModality:iccRelatedData:transactionType:status:isCaptured:brandId:brandName:cardHolderName:cardPan:cardEntryMode:amount:createDate:applicationIdentifier:applicationLabel:stoneCode:cardCvm:captureAmountTotal:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataHistoricTransactionView *)doCopyTransactionId:(int64_t)transactionId itk:(NSString *)itk amountAuthorized:(NSString *)amountAuthorized atk:(NSString *)atk arqc:(NSString * _Nullable)arqc orderId:(NSString * _Nullable)orderId authorizationCode:(NSString * _Nullable)authorizationCode extendedModality:(NSString * _Nullable)extendedModality reducedModality:(NSString * _Nullable)reducedModality iccRelatedData:(NSString * _Nullable)iccRelatedData transactionType:(NSString * _Nullable)transactionType status:(NSString * _Nullable)status isCaptured:(DCAPIBoolean * _Nullable)isCaptured brandId:(DCAPILong * _Nullable)brandId brandName:(NSString * _Nullable)brandName cardHolderName:(NSString * _Nullable)cardHolderName cardPan:(NSString * _Nullable)cardPan cardEntryMode:(NSString * _Nullable)cardEntryMode amount:(NSString * _Nullable)amount createDate:(NSString * _Nullable)createDate applicationIdentifier:(NSString * _Nullable)applicationIdentifier applicationLabel:(NSString * _Nullable)applicationLabel stoneCode:(NSString * _Nullable)stoneCode cardCvm:(NSString * _Nullable)cardCvm captureAmountTotal:(NSString *)captureAmountTotal __attribute__((swift_name("doCopy(transactionId:itk:amountAuthorized:atk:arqc:orderId:authorizationCode:extendedModality:reducedModality:iccRelatedData:transactionType:status:isCaptured:brandId:brandName:cardHolderName:cardPan:cardEntryMode:amount:createDate:applicationIdentifier:applicationLabel:stoneCode:cardCvm:captureAmountTotal:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable amount __attribute__((swift_name("amount")));
@property (readonly) NSString *amountAuthorized __attribute__((swift_name("amountAuthorized")));
@property (readonly) NSString * _Nullable applicationIdentifier __attribute__((swift_name("applicationIdentifier")));
@property (readonly) NSString * _Nullable applicationLabel __attribute__((swift_name("applicationLabel")));
@property (readonly) NSString * _Nullable arqc __attribute__((swift_name("arqc")));
@property (readonly) NSString *atk __attribute__((swift_name("atk")));
@property (readonly) NSString * _Nullable authorizationCode __attribute__((swift_name("authorizationCode")));
@property (readonly) DCAPILong * _Nullable brandId __attribute__((swift_name("brandId")));
@property (readonly) NSString * _Nullable brandName __attribute__((swift_name("brandName")));
@property (readonly) NSString *captureAmountTotal __attribute__((swift_name("captureAmountTotal")));
@property (readonly) NSString * _Nullable cardCvm __attribute__((swift_name("cardCvm")));
@property (readonly) NSString * _Nullable cardEntryMode __attribute__((swift_name("cardEntryMode")));
@property (readonly) NSString * _Nullable cardHolderName __attribute__((swift_name("cardHolderName")));
@property (readonly) NSString * _Nullable cardPan __attribute__((swift_name("cardPan")));
@property (readonly) NSString * _Nullable createDate __attribute__((swift_name("createDate")));
@property (readonly) NSString * _Nullable extendedModality __attribute__((swift_name("extendedModality")));
@property (readonly) NSString * _Nullable iccRelatedData __attribute__((swift_name("iccRelatedData")));
@property (readonly) DCAPIBoolean * _Nullable isCaptured __attribute__((swift_name("isCaptured")));
@property (readonly) NSString *itk __attribute__((swift_name("itk")));
@property (readonly) NSString * _Nullable orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString * _Nullable reducedModality __attribute__((swift_name("reducedModality")));
@property (readonly) NSString * _Nullable status __attribute__((swift_name("status")));
@property (readonly) NSString * _Nullable stoneCode __attribute__((swift_name("stoneCode")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@property (readonly) NSString * _Nullable transactionType __attribute__((swift_name("transactionType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataCaptureEntity")))
@interface DCAPIData_container_dataCaptureEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId amount:(NSString *)amount dateTime:(NSString *)dateTime __attribute__((swift_name("init(id:transactionId:amount:dateTime:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataCaptureEntity *)doCopyId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId amount:(NSString *)amount dateTime:(NSString *)dateTime __attribute__((swift_name("doCopy(id:transactionId:amount:dateTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) NSString *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataCredentialsEntity")))
@interface DCAPIData_container_dataCredentialsEntity : DCAPIBase
- (instancetype)initWithCredentialsAffiliationCode:(NSString *)credentialsAffiliationCode userName:(NSString *)userName password:(NSString *)password clientId:(NSString *)clientId clientSecret:(NSString *)clientSecret __attribute__((swift_name("init(credentialsAffiliationCode:userName:password:clientId:clientSecret:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataCredentialsEntity *)doCopyCredentialsAffiliationCode:(NSString *)credentialsAffiliationCode userName:(NSString *)userName password:(NSString *)password clientId:(NSString *)clientId clientSecret:(NSString *)clientSecret __attribute__((swift_name("doCopy(credentialsAffiliationCode:userName:password:clientId:clientSecret:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *clientId __attribute__((swift_name("clientId")));
@property (readonly) NSString *clientSecret __attribute__((swift_name("clientSecret")));
@property (readonly) NSString *credentialsAffiliationCode __attribute__((swift_name("credentialsAffiliationCode")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@property (readonly) NSString *userName __attribute__((swift_name("userName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataDccEntity")))
@interface DCAPIData_container_dataDccEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId cancellationId:(DCAPILong * _Nullable)cancellationId currencyCode:(DCAPIInt * _Nullable)currencyCode currencyLabel:(NSString *)currencyLabel exchangeRate:(NSString *)exchangeRate markUpRate:(NSString *)markUpRate convertedAmount:(NSString *)convertedAmount exponent:(NSString * _Nullable)exponent __attribute__((swift_name("init(id:transactionId:cancellationId:currencyCode:currencyLabel:exchangeRate:markUpRate:convertedAmount:exponent:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataDccEntity *)doCopyId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId cancellationId:(DCAPILong * _Nullable)cancellationId currencyCode:(DCAPIInt * _Nullable)currencyCode currencyLabel:(NSString *)currencyLabel exchangeRate:(NSString *)exchangeRate markUpRate:(NSString *)markUpRate convertedAmount:(NSString *)convertedAmount exponent:(NSString * _Nullable)exponent __attribute__((swift_name("doCopy(id:transactionId:cancellationId:currencyCode:currencyLabel:exchangeRate:markUpRate:convertedAmount:exponent:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPILong * _Nullable cancellationId __attribute__((swift_name("cancellationId")));
@property (readonly) NSString *convertedAmount __attribute__((swift_name("convertedAmount")));
@property (readonly) DCAPIInt * _Nullable currencyCode __attribute__((swift_name("currencyCode")));
@property (readonly) NSString *currencyLabel __attribute__((swift_name("currencyLabel")));
@property (readonly) NSString *exchangeRate __attribute__((swift_name("exchangeRate")));
@property (readonly) NSString * _Nullable exponent __attribute__((swift_name("exponent")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString *markUpRate __attribute__((swift_name("markUpRate")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataErrorInformationEntity")))
@interface DCAPIData_container_dataErrorInformationEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id code:(NSString *)code transactionId:(int64_t)transactionId message:(NSString *)message dateTime:(NSString *)dateTime __attribute__((swift_name("init(id:code:transactionId:message:dateTime:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataErrorInformationEntity *)doCopyId:(DCAPILong * _Nullable)id code:(NSString *)code transactionId:(int64_t)transactionId message:(NSString *)message dateTime:(NSString *)dateTime __attribute__((swift_name("doCopy(id:code:transactionId:message:dateTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *code __attribute__((swift_name("code")));
@property (readonly) NSString *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol DCAPIKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataFullReceiptView")))
@interface DCAPIData_container_dataFullReceiptView : DCAPIBase
- (instancetype)initWithId:(int64_t)id companyAddressCity:(NSString *)companyAddressCity companyAddressState:(NSString *)companyAddressState companyTaxType:(NSString *)companyTaxType companyTaxNumber:(NSString *)companyTaxNumber companyName:(NSString *)companyName aut:(NSString *)aut arqc:(NSString *)arqc aid:(NSString *)aid cardName:(NSString *)cardName stoneId:(NSString *)stoneId transactionStatus:(NSString *)transactionStatus __attribute__((swift_name("init(id:companyAddressCity:companyAddressState:companyTaxType:companyTaxNumber:companyName:aut:arqc:aid:cardName:stoneId:transactionStatus:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataFullReceiptView *)doCopyId:(int64_t)id companyAddressCity:(NSString *)companyAddressCity companyAddressState:(NSString *)companyAddressState companyTaxType:(NSString *)companyTaxType companyTaxNumber:(NSString *)companyTaxNumber companyName:(NSString *)companyName aut:(NSString *)aut arqc:(NSString *)arqc aid:(NSString *)aid cardName:(NSString *)cardName stoneId:(NSString *)stoneId transactionStatus:(NSString *)transactionStatus __attribute__((swift_name("doCopy(id:companyAddressCity:companyAddressState:companyTaxType:companyTaxNumber:companyName:aut:arqc:aid:cardName:stoneId:transactionStatus:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *aid __attribute__((swift_name("aid")));
@property (readonly) NSString *arqc __attribute__((swift_name("arqc")));
@property (readonly) NSString *aut __attribute__((swift_name("aut")));
@property (readonly) NSString *cardName __attribute__((swift_name("cardName")));
@property (readonly) NSString *companyAddressCity __attribute__((swift_name("companyAddressCity")));
@property (readonly) NSString *companyAddressState __attribute__((swift_name("companyAddressState")));
@property (readonly) NSString *companyName __attribute__((swift_name("companyName")));
@property (readonly) NSString *companyTaxNumber __attribute__((swift_name("companyTaxNumber")));
@property (readonly) NSString *companyTaxType __attribute__((swift_name("companyTaxType")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) NSString *stoneId __attribute__((swift_name("stoneId")));
@property (readonly) NSString *transactionStatus __attribute__((swift_name("transactionStatus")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataInvoiceEntity")))
@interface DCAPIData_container_dataInvoiceEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id paymentOrderId:(NSString *)paymentOrderId transactionId:(int64_t)transactionId paymentType:(NSString *)paymentType amount:(NSString *)amount currency:(int32_t)currency walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName createdAt:(NSString *)createdAt expiresAt:(NSString *)expiresAt customer:(DCAPIData_container_dataCustomerEntity *)customer instantPayment:(DCAPIData_container_dataInstantPaymentEntity * _Nullable)instantPayment __attribute__((swift_name("init(id:paymentOrderId:transactionId:paymentType:amount:currency:walletProviderId:walletProviderName:createdAt:expiresAt:customer:instantPayment:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataInvoiceEntity *)doCopyId:(DCAPILong * _Nullable)id paymentOrderId:(NSString *)paymentOrderId transactionId:(int64_t)transactionId paymentType:(NSString *)paymentType amount:(NSString *)amount currency:(int32_t)currency walletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName createdAt:(NSString *)createdAt expiresAt:(NSString *)expiresAt customer:(DCAPIData_container_dataCustomerEntity *)customer instantPayment:(DCAPIData_container_dataInstantPaymentEntity * _Nullable)instantPayment __attribute__((swift_name("doCopy(id:paymentOrderId:transactionId:paymentType:amount:currency:walletProviderId:walletProviderName:createdAt:expiresAt:customer:instantPayment:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) NSString *createdAt __attribute__((swift_name("createdAt")));
@property (readonly) int32_t currency __attribute__((swift_name("currency")));
@property (readonly) DCAPIData_container_dataCustomerEntity *customer __attribute__((swift_name("customer")));
@property (readonly) NSString *expiresAt __attribute__((swift_name("expiresAt")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) DCAPIData_container_dataInstantPaymentEntity * _Nullable instantPayment __attribute__((swift_name("instantPayment")));
@property (readonly) NSString *paymentOrderId __attribute__((swift_name("paymentOrderId")));
@property (readonly) NSString *paymentType __attribute__((swift_name("paymentType")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@property (readonly) NSString *walletProviderId __attribute__((swift_name("walletProviderId")));
@property (readonly) NSString *walletProviderName __attribute__((swift_name("walletProviderName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_contractCardBrand.Companion")))
@interface DCAPIData_container_contractCardBrandCompanion : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPIData_container_contractCardBrandCompanion *shared __attribute__((swift_name("shared")));
- (id<DCAPIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataMerchantEntity")))
@interface DCAPIData_container_dataMerchantEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id acquirerCode:(NSString *)acquirerCode stoneCode:(NSString *)stoneCode sak:(NSString *)sak displayName:(NSString *)displayName mcc:(NSString *)mcc affiliationKey:(NSString *)affiliationKey taxIdentificationType:(NSString *)taxIdentificationType taxIdentificationNumber:(NSString *)taxIdentificationNumber currencyCode:(NSString *)currencyCode phoneNumber:(NSString *)phoneNumber email:(NSString *)email shortName:(NSString *)shortName cardBrands:(NSString *)cardBrands legalName:(NSString *)legalName pixAvailable:(DCAPIBoolean * _Nullable)pixAvailable appId:(NSString *)appId address:(DCAPIData_container_dataAddressEntity *)address pixAccount:(DCAPIData_container_dataPixAccountEntity * _Nullable)pixAccount __attribute__((swift_name("init(id:acquirerCode:stoneCode:sak:displayName:mcc:affiliationKey:taxIdentificationType:taxIdentificationNumber:currencyCode:phoneNumber:email:shortName:cardBrands:legalName:pixAvailable:appId:address:pixAccount:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataMerchantEntity *)doCopyId:(DCAPILong * _Nullable)id acquirerCode:(NSString *)acquirerCode stoneCode:(NSString *)stoneCode sak:(NSString *)sak displayName:(NSString *)displayName mcc:(NSString *)mcc affiliationKey:(NSString *)affiliationKey taxIdentificationType:(NSString *)taxIdentificationType taxIdentificationNumber:(NSString *)taxIdentificationNumber currencyCode:(NSString *)currencyCode phoneNumber:(NSString *)phoneNumber email:(NSString *)email shortName:(NSString *)shortName cardBrands:(NSString *)cardBrands legalName:(NSString *)legalName pixAvailable:(DCAPIBoolean * _Nullable)pixAvailable appId:(NSString *)appId address:(DCAPIData_container_dataAddressEntity *)address pixAccount:(DCAPIData_container_dataPixAccountEntity * _Nullable)pixAccount __attribute__((swift_name("doCopy(id:acquirerCode:stoneCode:sak:displayName:mcc:affiliationKey:taxIdentificationType:taxIdentificationNumber:currencyCode:phoneNumber:email:shortName:cardBrands:legalName:pixAvailable:appId:address:pixAccount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *acquirerCode __attribute__((swift_name("acquirerCode")));
@property (readonly) DCAPIData_container_dataAddressEntity *address __attribute__((swift_name("address")));
@property (readonly) NSString *affiliationKey __attribute__((swift_name("affiliationKey")));
@property (readonly) NSString *appId __attribute__((swift_name("appId")));
@property (readonly) NSString *cardBrands __attribute__((swift_name("cardBrands")));
@property (readonly) NSString *currencyCode __attribute__((swift_name("currencyCode")));
@property (readonly) NSString *displayName __attribute__((swift_name("displayName")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString *legalName __attribute__((swift_name("legalName")));
@property (readonly) NSString *mcc __attribute__((swift_name("mcc")));
@property (readonly) NSString *phoneNumber __attribute__((swift_name("phoneNumber")));
@property (readonly) DCAPIData_container_dataPixAccountEntity * _Nullable pixAccount __attribute__((swift_name("pixAccount")));
@property (readonly) DCAPIBoolean * _Nullable pixAvailable __attribute__((swift_name("pixAvailable")));
@property (readonly) NSString *sak __attribute__((swift_name("sak")));
@property (readonly) NSString *shortName __attribute__((swift_name("shortName")));
@property (readonly) NSString *stoneCode __attribute__((swift_name("stoneCode")));
@property (readonly) NSString *taxIdentificationNumber __attribute__((swift_name("taxIdentificationNumber")));
@property (readonly) NSString *taxIdentificationType __attribute__((swift_name("taxIdentificationType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataSubMerchantEntity")))
@interface DCAPIData_container_dataSubMerchantEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id parentStoneCode:(NSString *)parentStoneCode taxIdentificationNumber:(NSString *)taxIdentificationNumber registeredIdentifier:(NSString *)registeredIdentifier mcc:(NSString *)mcc address:(DCAPIData_container_dataAddressEntity *)address __attribute__((swift_name("init(id:parentStoneCode:taxIdentificationNumber:registeredIdentifier:mcc:address:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataSubMerchantEntity *)doCopyId:(DCAPILong * _Nullable)id parentStoneCode:(NSString *)parentStoneCode taxIdentificationNumber:(NSString *)taxIdentificationNumber registeredIdentifier:(NSString *)registeredIdentifier mcc:(NSString *)mcc address:(DCAPIData_container_dataAddressEntity *)address __attribute__((swift_name("doCopy(id:parentStoneCode:taxIdentificationNumber:registeredIdentifier:mcc:address:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) DCAPIData_container_dataAddressEntity *address __attribute__((swift_name("address")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString *mcc __attribute__((swift_name("mcc")));
@property (readonly) NSString *parentStoneCode __attribute__((swift_name("parentStoneCode")));
@property (readonly) NSString *registeredIdentifier __attribute__((swift_name("registeredIdentifier")));
@property (readonly) NSString *taxIdentificationNumber __attribute__((swift_name("taxIdentificationNumber")));
@end

__attribute__((swift_name("Room_runtimeMigration")))
@interface DCAPIRoom_runtimeMigration : DCAPIBase
- (instancetype)initWithStartVersion:(int32_t)startVersion endVersion:(int32_t)endVersion __attribute__((swift_name("init(startVersion:endVersion:)"))) __attribute__((objc_designated_initializer));
- (void)migrateConnection:(id<DCAPISqliteSQLiteConnection>)connection __attribute__((swift_name("migrate(connection:)")));
@property (readonly) int32_t endVersion __attribute__((swift_name("endVersion")));
@property (readonly) int32_t startVersion __attribute__((swift_name("startVersion")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol DCAPIKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol DCAPIKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol DCAPIKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol DCAPIKotlinKClass <DCAPIKotlinKDeclarationContainer, DCAPIKotlinKAnnotatedElement, DCAPIKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((swift_name("Room_runtimeAutoMigrationSpec")))
@protocol DCAPIRoom_runtimeAutoMigrationSpec
@required
- (void)onPostMigrateConnection:(id<DCAPISqliteSQLiteConnection>)connection __attribute__((swift_name("onPostMigrate(connection:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Room_runtimeInvalidationTracker")))
@interface DCAPIRoom_runtimeInvalidationTracker : DCAPIBase

/**
 * @note annotations
 *   androidx.annotation.RestrictTo(value=[Scope.LIBRARY_GROUP_PREFIX])
*/
- (instancetype)initWithDatabase:(DCAPIRoom_runtimeRoomDatabase *)database shadowTablesMap:(NSDictionary<NSString *, NSString *> *)shadowTablesMap viewTables:(NSDictionary<NSString *, NSSet<NSString *> *> *)viewTables tableNames:(DCAPIKotlinArray<NSString *> *)tableNames __attribute__((swift_name("init(database:shadowTablesMap:viewTables:tableNames:)"))) __attribute__((objc_designated_initializer));
- (void)refreshAsync __attribute__((swift_name("refreshAsync()")));
- (void)stop __attribute__((swift_name("stop()")));

/**
 * @note annotations
 *   androidx.annotation.RestrictTo(value=[Scope.LIBRARY_GROUP])
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)subscribeObserver:(DCAPIRoom_runtimeInvalidationTrackerObserver *)observer completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("subscribe(observer:completionHandler:)")));

/**
 * @note annotations
 *   androidx.annotation.RestrictTo(value=[Scope.LIBRARY_GROUP])
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)unsubscribeObserver:(DCAPIRoom_runtimeInvalidationTrackerObserver *)observer completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("unsubscribe(observer:completionHandler:)")));
@end

__attribute__((swift_name("Room_runtimeRoomOpenDelegateMarker")))
@protocol DCAPIRoom_runtimeRoomOpenDelegateMarker
@required
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol DCAPIKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<DCAPIKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataDataContainerDataBase.Companion")))
@interface DCAPIData_container_dataDataContainerDataBaseCompanion : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPIData_container_dataDataContainerDataBaseCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *ID_CONFIGURATION_DATABASE __attribute__((swift_name("ID_CONFIGURATION_DATABASE")));
@property (readonly) DCAPIKotlinArray<DCAPIRoom_runtimeMigration *> *migrations __attribute__((swift_name("migrations")));
@end

__attribute__((swift_name("Data_container_dataFullTransactionDao")))
@protocol DCAPIData_container_dataFullTransactionDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getFullTransactionByATKAcquirerTransactionKey:(NSString *)acquirerTransactionKey completionHandler:(void (^)(DCAPIData_container_dataFullTransactionView * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getFullTransactionByATK(acquirerTransactionKey:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getFullTransactionByITKInitiatorTransactionKey:(NSString *)initiatorTransactionKey completionHandler:(void (^)(DCAPIData_container_dataFullTransactionView * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getFullTransactionByITK(initiatorTransactionKey:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getFullTransactionsWithCompletionHandler:(void (^)(NSArray<DCAPIData_container_dataFullTransactionView *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getFullTransactions(completionHandler:)")));
@end

__attribute__((swift_name("Data_container_dataTransactionTokenDao")))
@protocol DCAPIData_container_dataTransactionTokenDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteAllTransactionsTokensWithCompletionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteAllTransactionsTokens(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteCompactTokenAffiliationCode:(NSString *)affiliationCode completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("deleteCompactToken(affiliationCode:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getTransactionTokenAffiliationCode:(NSString *)affiliationCode completionHandler:(void (^)(DCAPIData_container_dataTransactionTokenEntity * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getTransactionToken(affiliationCode:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertTransactionTokenTransactionTokenEntity:(DCAPIData_container_dataTransactionTokenEntity *)transactionTokenEntity completionHandler:(void (^)(DCAPILong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insertTransactionToken(transactionTokenEntity:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateAffiliationCodeOlderAffiliationCode:(NSString *)olderAffiliationCode newAffiliationCode:(NSString *)newAffiliationCode completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateAffiliationCode(olderAffiliationCode:newAffiliationCode:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateTransactionTokenTransactionTokenEntity:(DCAPIData_container_dataTransactionTokenEntity *)transactionTokenEntity completionHandler:(void (^)(DCAPIInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateTransactionToken(transactionTokenEntity:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataProbeRequestEntity")))
@interface DCAPIData_container_dataProbeRequestEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId status:(NSString *)status dateTime:(NSString *)dateTime __attribute__((swift_name("init(id:transactionId:status:dateTime:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataProbeRequestEntity *)doCopyId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId status:(NSString *)status dateTime:(NSString *)dateTime __attribute__((swift_name("doCopy(id:transactionId:status:dateTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataProbeRequiredEntity")))
@interface DCAPIData_container_dataProbeRequiredEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId reason:(NSString *)reason dateTime:(NSString *)dateTime reasonCode:(int32_t)reasonCode __attribute__((swift_name("init(id:transactionId:reason:dateTime:reasonCode:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataProbeRequiredEntity *)doCopyId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId reason:(NSString *)reason dateTime:(NSString *)dateTime reasonCode:(int32_t)reasonCode __attribute__((swift_name("doCopy(id:transactionId:reason:dateTime:reasonCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString *reason __attribute__((swift_name("reason")));
@property (readonly) int32_t reasonCode __attribute__((swift_name("reasonCode")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((swift_name("SqliteSQLiteStatement")))
@protocol DCAPISqliteSQLiteStatement
@required
- (void)bindBlobIndex:(int32_t)index value:(DCAPIKotlinByteArray *)value __attribute__((swift_name("bindBlob(index:value:)")));
- (void)bindBooleanIndex:(int32_t)index value:(BOOL)value __attribute__((swift_name("bindBoolean(index:value:)")));
- (void)bindDoubleIndex:(int32_t)index value:(double)value __attribute__((swift_name("bindDouble(index:value:)")));
- (void)bindFloatIndex:(int32_t)index value:(float)value __attribute__((swift_name("bindFloat(index:value:)")));
- (void)bindIntIndex:(int32_t)index value:(int32_t)value __attribute__((swift_name("bindInt(index:value:)")));
- (void)bindLongIndex:(int32_t)index value:(int64_t)value __attribute__((swift_name("bindLong(index:value:)")));
- (void)bindNullIndex:(int32_t)index __attribute__((swift_name("bindNull(index:)")));
- (void)bindTextIndex:(int32_t)index value:(NSString *)value __attribute__((swift_name("bindText(index:value:)")));
- (void)clearBindings __attribute__((swift_name("clearBindings()")));
- (void)close __attribute__((swift_name("close()")));
- (DCAPIKotlinByteArray *)getBlobIndex:(int32_t)index __attribute__((swift_name("getBlob(index:)")));
- (BOOL)getBooleanIndex:(int32_t)index __attribute__((swift_name("getBoolean(index:)")));
- (int32_t)getColumnCount __attribute__((swift_name("getColumnCount()")));
- (NSString *)getColumnNameIndex:(int32_t)index __attribute__((swift_name("getColumnName(index:)")));
- (NSArray<NSString *> *)getColumnNames __attribute__((swift_name("getColumnNames()")));
- (double)getDoubleIndex:(int32_t)index __attribute__((swift_name("getDouble(index:)")));
- (float)getFloatIndex:(int32_t)index __attribute__((swift_name("getFloat(index:)")));
- (int32_t)getIntIndex:(int32_t)index __attribute__((swift_name("getInt(index:)")));
- (int64_t)getLongIndex:(int32_t)index __attribute__((swift_name("getLong(index:)")));
- (NSString *)getTextIndex:(int32_t)index __attribute__((swift_name("getText(index:)")));
- (BOOL)isNullIndex:(int32_t)index __attribute__((swift_name("isNull(index:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (BOOL)step __attribute__((swift_name("step()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataReportCashPaymentView")))
@interface DCAPIData_container_dataReportCashPaymentView : DCAPIBase
- (instancetype)initWithStoneCode:(NSString *)stoneCode transactionType:(NSString *)transactionType dateTime:(NSString *)dateTime brandId:(NSString *)brandId qualifier:(NSString *)qualifier approvedAmountInCents:(int64_t)approvedAmountInCents approvedCount:(int32_t)approvedCount cancelledAmountInCents:(int64_t)cancelledAmountInCents cancelledCount:(int32_t)cancelledCount __attribute__((swift_name("init(stoneCode:transactionType:dateTime:brandId:qualifier:approvedAmountInCents:approvedCount:cancelledAmountInCents:cancelledCount:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataReportCashPaymentView *)doCopyStoneCode:(NSString *)stoneCode transactionType:(NSString *)transactionType dateTime:(NSString *)dateTime brandId:(NSString *)brandId qualifier:(NSString *)qualifier approvedAmountInCents:(int64_t)approvedAmountInCents approvedCount:(int32_t)approvedCount cancelledAmountInCents:(int64_t)cancelledAmountInCents cancelledCount:(int32_t)cancelledCount __attribute__((swift_name("doCopy(stoneCode:transactionType:dateTime:brandId:qualifier:approvedAmountInCents:approvedCount:cancelledAmountInCents:cancelledCount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t approvedAmountInCents __attribute__((swift_name("approvedAmountInCents")));
@property (readonly) int32_t approvedCount __attribute__((swift_name("approvedCount")));
@property (readonly) NSString *brandId __attribute__((swift_name("brandId")));
@property (readonly) int64_t cancelledAmountInCents __attribute__((swift_name("cancelledAmountInCents")));
@property (readonly) int32_t cancelledCount __attribute__((swift_name("cancelledCount")));
@property (readonly) NSString *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) NSString *qualifier __attribute__((swift_name("qualifier")));
@property (readonly) NSString *stoneCode __attribute__((swift_name("stoneCode")));
@property (readonly) NSString *transactionType __attribute__((swift_name("transactionType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataReportData")))
@interface DCAPIData_container_dataReportData : DCAPIBase
- (instancetype)initWithTotalApprovedBrand:(int64_t)totalApprovedBrand approvedValueBrand:(int64_t)approvedValueBrand approvedTransactionsNumber:(int64_t)approvedTransactionsNumber cancelledValueBrand:(int64_t)cancelledValueBrand cancelledTransactionsNumber:(int64_t)cancelledTransactionsNumber brandId:(int32_t)brandId brandName:(NSString *)brandName transactionType:(NSString * _Nullable)transactionType qualifier:(NSString *)qualifier __attribute__((swift_name("init(totalApprovedBrand:approvedValueBrand:approvedTransactionsNumber:cancelledValueBrand:cancelledTransactionsNumber:brandId:brandName:transactionType:qualifier:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataReportData *)doCopyTotalApprovedBrand:(int64_t)totalApprovedBrand approvedValueBrand:(int64_t)approvedValueBrand approvedTransactionsNumber:(int64_t)approvedTransactionsNumber cancelledValueBrand:(int64_t)cancelledValueBrand cancelledTransactionsNumber:(int64_t)cancelledTransactionsNumber brandId:(int32_t)brandId brandName:(NSString *)brandName transactionType:(NSString * _Nullable)transactionType qualifier:(NSString *)qualifier __attribute__((swift_name("doCopy(totalApprovedBrand:approvedValueBrand:approvedTransactionsNumber:cancelledValueBrand:cancelledTransactionsNumber:brandId:brandName:transactionType:qualifier:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int64_t approvedTransactionsNumber __attribute__((swift_name("approvedTransactionsNumber")));
@property int64_t approvedValueBrand __attribute__((swift_name("approvedValueBrand")));
@property int32_t brandId __attribute__((swift_name("brandId")));
@property NSString *brandName __attribute__((swift_name("brandName")));
@property int64_t cancelledTransactionsNumber __attribute__((swift_name("cancelledTransactionsNumber")));
@property int64_t cancelledValueBrand __attribute__((swift_name("cancelledValueBrand")));
@property NSString *qualifier __attribute__((swift_name("qualifier")));
@property int64_t totalApprovedBrand __attribute__((swift_name("totalApprovedBrand")));
@property NSString * _Nullable transactionType __attribute__((swift_name("transactionType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataReportQrCode")))
@interface DCAPIData_container_dataReportQrCode : DCAPIBase
- (instancetype)initWithWalletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName brandId:(int32_t)brandId brandName:(NSString *)brandName transactionType:(NSString *)transactionType totalApproved:(int64_t)totalApproved approvedValue:(int64_t)approvedValue approvedTransactionsNumber:(int64_t)approvedTransactionsNumber cancelledValue:(int64_t)cancelledValue cancelledTransactionsNumber:(int64_t)cancelledTransactionsNumber __attribute__((swift_name("init(walletProviderId:walletProviderName:brandId:brandName:transactionType:totalApproved:approvedValue:approvedTransactionsNumber:cancelledValue:cancelledTransactionsNumber:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataReportQrCode *)doCopyWalletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName brandId:(int32_t)brandId brandName:(NSString *)brandName transactionType:(NSString *)transactionType totalApproved:(int64_t)totalApproved approvedValue:(int64_t)approvedValue approvedTransactionsNumber:(int64_t)approvedTransactionsNumber cancelledValue:(int64_t)cancelledValue cancelledTransactionsNumber:(int64_t)cancelledTransactionsNumber __attribute__((swift_name("doCopy(walletProviderId:walletProviderName:brandId:brandName:transactionType:totalApproved:approvedValue:approvedTransactionsNumber:cancelledValue:cancelledTransactionsNumber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t approvedTransactionsNumber __attribute__((swift_name("approvedTransactionsNumber")));
@property (readonly) int64_t approvedValue __attribute__((swift_name("approvedValue")));
@property (readonly) int32_t brandId __attribute__((swift_name("brandId")));
@property (readonly) NSString *brandName __attribute__((swift_name("brandName")));
@property (readonly) int64_t cancelledTransactionsNumber __attribute__((swift_name("cancelledTransactionsNumber")));
@property (readonly) int64_t cancelledValue __attribute__((swift_name("cancelledValue")));
@property (readonly) int64_t totalApproved __attribute__((swift_name("totalApproved")));
@property (readonly) NSString *transactionType __attribute__((swift_name("transactionType")));
@property (readonly) NSString *walletProviderId __attribute__((swift_name("walletProviderId")));
@property (readonly) NSString *walletProviderName __attribute__((swift_name("walletProviderName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataReportWallet")))
@interface DCAPIData_container_dataReportWallet : DCAPIBase
- (instancetype)initWithWalletId:(NSString *)walletId walletName:(NSString *)walletName totalApprovedWallet:(int64_t)totalApprovedWallet approvedValueWallet:(int64_t)approvedValueWallet approvedTransactionsNumber:(int64_t)approvedTransactionsNumber cancelledValueWallet:(int64_t)cancelledValueWallet cancelledTransactionsNumber:(int64_t)cancelledTransactionsNumber __attribute__((swift_name("init(walletId:walletName:totalApprovedWallet:approvedValueWallet:approvedTransactionsNumber:cancelledValueWallet:cancelledTransactionsNumber:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataReportWallet *)doCopyWalletId:(NSString *)walletId walletName:(NSString *)walletName totalApprovedWallet:(int64_t)totalApprovedWallet approvedValueWallet:(int64_t)approvedValueWallet approvedTransactionsNumber:(int64_t)approvedTransactionsNumber cancelledValueWallet:(int64_t)cancelledValueWallet cancelledTransactionsNumber:(int64_t)cancelledTransactionsNumber __attribute__((swift_name("doCopy(walletId:walletName:totalApprovedWallet:approvedValueWallet:approvedTransactionsNumber:cancelledValueWallet:cancelledTransactionsNumber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int64_t approvedTransactionsNumber __attribute__((swift_name("approvedTransactionsNumber")));
@property int64_t approvedValueWallet __attribute__((swift_name("approvedValueWallet")));
@property int64_t cancelledTransactionsNumber __attribute__((swift_name("cancelledTransactionsNumber")));
@property int64_t cancelledValueWallet __attribute__((swift_name("cancelledValueWallet")));
@property int64_t totalApprovedWallet __attribute__((swift_name("totalApprovedWallet")));
@property NSString *walletId __attribute__((swift_name("walletId")));
@property NSString *walletName __attribute__((swift_name("walletName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataReportSummaryQrCodeEntity")))
@interface DCAPIData_container_dataReportSummaryQrCodeEntity : DCAPIBase
- (instancetype)initWithWalletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName brand:(int32_t)brand transactionType:(NSString *)transactionType approvedValue:(int64_t)approvedValue approvedNumber:(int64_t)approvedNumber cancelledNumber:(int64_t)cancelledNumber __attribute__((swift_name("init(walletProviderId:walletProviderName:brand:transactionType:approvedValue:approvedNumber:cancelledNumber:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataReportSummaryQrCodeEntity *)doCopyWalletProviderId:(NSString *)walletProviderId walletProviderName:(NSString *)walletProviderName brand:(int32_t)brand transactionType:(NSString *)transactionType approvedValue:(int64_t)approvedValue approvedNumber:(int64_t)approvedNumber cancelledNumber:(int64_t)cancelledNumber __attribute__((swift_name("doCopy(walletProviderId:walletProviderName:brand:transactionType:approvedValue:approvedNumber:cancelledNumber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t approvedNumber __attribute__((swift_name("approvedNumber")));
@property (readonly) int64_t approvedValue __attribute__((swift_name("approvedValue")));
@property int32_t brand __attribute__((swift_name("brand")));
@property (readonly) int64_t cancelledNumber __attribute__((swift_name("cancelledNumber")));
@property NSString *transactionType __attribute__((swift_name("transactionType")));
@property NSString *walletProviderId __attribute__((swift_name("walletProviderId")));
@property NSString *walletProviderName __attribute__((swift_name("walletProviderName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataReportSummaryWallet")))
@interface DCAPIData_container_dataReportSummaryWallet : DCAPIBase
- (instancetype)initWithApprovedValueFromQrCode:(int64_t)approvedValueFromQrCode approvedNumberFromQrCode:(int64_t)approvedNumberFromQrCode __attribute__((swift_name("init(approvedValueFromQrCode:approvedNumberFromQrCode:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataReportSummaryWallet *)doCopyApprovedValueFromQrCode:(int64_t)approvedValueFromQrCode approvedNumberFromQrCode:(int64_t)approvedNumberFromQrCode __attribute__((swift_name("doCopy(approvedValueFromQrCode:approvedNumberFromQrCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t approvedNumberFromQrCode __attribute__((swift_name("approvedNumberFromQrCode")));
@property (readonly) int64_t approvedValueFromQrCode __attribute__((swift_name("approvedValueFromQrCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataReversalRequestEntity")))
@interface DCAPIData_container_dataReversalRequestEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId status:(NSString *)status dateTime:(NSString *)dateTime __attribute__((swift_name("init(id:transactionId:status:dateTime:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataReversalRequestEntity *)doCopyId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId status:(NSString *)status dateTime:(NSString *)dateTime __attribute__((swift_name("doCopy(id:transactionId:status:dateTime:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataReversalRequiredEntity")))
@interface DCAPIData_container_dataReversalRequiredEntity : DCAPIBase
- (instancetype)initWithId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId reason:(NSString *)reason dateTime:(NSString *)dateTime reasonCode:(int32_t)reasonCode __attribute__((swift_name("init(id:transactionId:reason:dateTime:reasonCode:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataReversalRequiredEntity *)doCopyId:(DCAPILong * _Nullable)id transactionId:(int64_t)transactionId reason:(NSString *)reason dateTime:(NSString *)dateTime reasonCode:(int32_t)reasonCode __attribute__((swift_name("doCopy(id:transactionId:reason:dateTime:reasonCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) DCAPILong * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString *reason __attribute__((swift_name("reason")));
@property (readonly) int32_t reasonCode __attribute__((swift_name("reasonCode")));
@property (readonly) int64_t transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataSalesHistoryView")))
@interface DCAPIData_container_dataSalesHistoryView : DCAPIBase
- (instancetype)initWithId:(int64_t)id amount:(int64_t)amount cancelledAmount:(int64_t)cancelledAmount finalAmount:(int64_t)finalAmount cardBrandId:(int32_t)cardBrandId cardBrandName:(NSString *)cardBrandName transactionStatus:(NSString *)transactionStatus approvalDate:(NSString *)approvalDate cancelledDate:(NSString * _Nullable)cancelledDate stoneId:(NSString *)stoneId reducedModality:(NSString *)reducedModality extendedModality:(NSString *)extendedModality hasMultipleCancellations:(BOOL)hasMultipleCancellations isInstantPaymentTransaction:(BOOL)isInstantPaymentTransaction walletId:(NSString * _Nullable)walletId cardPan:(NSString *)cardPan qualifier:(NSString *)qualifier __attribute__((swift_name("init(id:amount:cancelledAmount:finalAmount:cardBrandId:cardBrandName:transactionStatus:approvalDate:cancelledDate:stoneId:reducedModality:extendedModality:hasMultipleCancellations:isInstantPaymentTransaction:walletId:cardPan:qualifier:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataSalesHistoryView *)doCopyId:(int64_t)id amount:(int64_t)amount cancelledAmount:(int64_t)cancelledAmount finalAmount:(int64_t)finalAmount cardBrandId:(int32_t)cardBrandId cardBrandName:(NSString *)cardBrandName transactionStatus:(NSString *)transactionStatus approvalDate:(NSString *)approvalDate cancelledDate:(NSString * _Nullable)cancelledDate stoneId:(NSString *)stoneId reducedModality:(NSString *)reducedModality extendedModality:(NSString *)extendedModality hasMultipleCancellations:(BOOL)hasMultipleCancellations isInstantPaymentTransaction:(BOOL)isInstantPaymentTransaction walletId:(NSString * _Nullable)walletId cardPan:(NSString *)cardPan qualifier:(NSString *)qualifier __attribute__((swift_name("doCopy(id:amount:cancelledAmount:finalAmount:cardBrandId:cardBrandName:transactionStatus:approvalDate:cancelledDate:stoneId:reducedModality:extendedModality:hasMultipleCancellations:isInstantPaymentTransaction:walletId:cardPan:qualifier:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t amount __attribute__((swift_name("amount")));
@property (readonly) NSString *approvalDate __attribute__((swift_name("approvalDate")));
@property (readonly) int64_t cancelledAmount __attribute__((swift_name("cancelledAmount")));
@property (readonly) NSString * _Nullable cancelledDate __attribute__((swift_name("cancelledDate")));
@property (readonly) int32_t cardBrandId __attribute__((swift_name("cardBrandId")));
@property (readonly) NSString *cardBrandName __attribute__((swift_name("cardBrandName")));
@property (readonly) NSString *cardPan __attribute__((swift_name("cardPan")));
@property (readonly) NSString *extendedModality __attribute__((swift_name("extendedModality")));
@property (readonly) int64_t finalAmount __attribute__((swift_name("finalAmount")));
@property (readonly) BOOL hasMultipleCancellations __attribute__((swift_name("hasMultipleCancellations")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) BOOL isInstantPaymentTransaction __attribute__((swift_name("isInstantPaymentTransaction")));
@property (readonly) NSString *qualifier __attribute__((swift_name("qualifier")));
@property (readonly) NSString *reducedModality __attribute__((swift_name("reducedModality")));
@property (readonly) NSString *stoneId __attribute__((swift_name("stoneId")));
@property (readonly) NSString *transactionStatus __attribute__((swift_name("transactionStatus")));
@property (readonly) NSString * _Nullable walletId __attribute__((swift_name("walletId")));
@end

__attribute__((swift_name("Datastore_coreDataMigration")))
@protocol DCAPIDatastore_coreDataMigration
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)cleanUpWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("cleanUp(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)migrateCurrentData:(id _Nullable)currentData completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("migrate(currentData:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)shouldMigrateCurrentData:(id _Nullable)currentData completionHandler:(void (^)(DCAPIBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("shouldMigrate(currentData:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataSystemConfigDao.Companion")))
@interface DCAPIData_container_dataSystemConfigDaoCompanion : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPIData_container_dataSystemConfigDaoCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) DCAPIData_container_dataEnvironmentEnum *DEFAULT_ENV __attribute__((swift_name("DEFAULT_ENV")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataEnvironmentEnum")))
@interface DCAPIData_container_dataEnvironmentEnum : DCAPIKotlinEnum<DCAPIData_container_dataEnvironmentEnum *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPIData_container_dataEnvironmentEnum *production __attribute__((swift_name("production")));
@property (class, readonly) DCAPIData_container_dataEnvironmentEnum *certification __attribute__((swift_name("certification")));
@property (class, readonly) DCAPIData_container_dataEnvironmentEnum *sandbox __attribute__((swift_name("sandbox")));
@property (class, readonly) DCAPIData_container_dataEnvironmentEnum *internalHomolog __attribute__((swift_name("internalHomolog")));
@property (class, readonly) DCAPIData_container_dataEnvironmentEnum *staging __attribute__((swift_name("staging")));
+ (DCAPIKotlinArray<DCAPIData_container_dataEnvironmentEnum *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPIData_container_dataEnvironmentEnum *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("Datastore_coreDataStore")))
@protocol DCAPIDatastore_coreDataStore
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateDataTransform:(id<DCAPIKotlinSuspendFunction1>)transform completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("updateData(transform:completionHandler:)")));
@property (readonly) id<DCAPIKotlinx_coroutines_coreFlow> data __attribute__((swift_name("data")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDate.Companion")))
@interface DCAPIKotlinx_datetimeLocalDateCompanion : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPIKotlinx_datetimeLocalDateCompanion *shared __attribute__((swift_name("shared")));
- (id<DCAPIKotlinx_datetimeDateTimeFormat>)FormatBlock:(void (^)(id<DCAPIKotlinx_datetimeDateTimeFormatBuilderWithDate>))block __attribute__((swift_name("Format(block:)")));
- (DCAPIKotlinx_datetimeLocalDate *)fromEpochDaysEpochDays:(int32_t)epochDays __attribute__((swift_name("fromEpochDays(epochDays:)")));
- (DCAPIKotlinx_datetimeLocalDate *)parseInput:(id)input format:(id<DCAPIKotlinx_datetimeDateTimeFormat>)format __attribute__((swift_name("parse(input:format:)")));
- (id<DCAPIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalTime.Companion")))
@interface DCAPIKotlinx_datetimeLocalTimeCompanion : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPIKotlinx_datetimeLocalTimeCompanion *shared __attribute__((swift_name("shared")));
- (id<DCAPIKotlinx_datetimeDateTimeFormat>)FormatBuilder:(void (^)(id<DCAPIKotlinx_datetimeDateTimeFormatBuilderWithTime>))builder __attribute__((swift_name("Format(builder:)")));
- (DCAPIKotlinx_datetimeLocalTime *)fromMillisecondOfDayMillisecondOfDay:(int32_t)millisecondOfDay __attribute__((swift_name("fromMillisecondOfDay(millisecondOfDay:)")));
- (DCAPIKotlinx_datetimeLocalTime *)fromNanosecondOfDayNanosecondOfDay:(int64_t)nanosecondOfDay __attribute__((swift_name("fromNanosecondOfDay(nanosecondOfDay:)")));
- (DCAPIKotlinx_datetimeLocalTime *)fromSecondOfDaySecondOfDay:(int32_t)secondOfDay __attribute__((swift_name("fromSecondOfDay(secondOfDay:)")));
- (DCAPIKotlinx_datetimeLocalTime *)parseInput:(id)input format:(id<DCAPIKotlinx_datetimeDateTimeFormat>)format __attribute__((swift_name("parse(input:format:)")));
- (id<DCAPIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("Kotlinx_datetimeDateTimeFormat")))
@protocol DCAPIKotlinx_datetimeDateTimeFormat
@required
- (NSString *)formatValue:(id _Nullable)value __attribute__((swift_name("format(value:)")));
- (id<DCAPIKotlinAppendable>)formatToAppendable:(id<DCAPIKotlinAppendable>)appendable value:(id _Nullable)value __attribute__((swift_name("formatTo(appendable:value:)")));
- (id _Nullable)parseInput:(id)input __attribute__((swift_name("parse(input:)")));
- (id _Nullable)parseOrNullInput:(id)input __attribute__((swift_name("parseOrNull(input:)")));
@end

__attribute__((swift_name("Kotlinx_datetimeDateTimeFormatBuilder")))
@protocol DCAPIKotlinx_datetimeDateTimeFormatBuilder
@required
- (void)charsValue:(NSString *)value __attribute__((swift_name("chars(value:)")));
@end

__attribute__((swift_name("Kotlinx_datetimeDateTimeFormatBuilderWithDate")))
@protocol DCAPIKotlinx_datetimeDateTimeFormatBuilderWithDate <DCAPIKotlinx_datetimeDateTimeFormatBuilder>
@required
- (void)dateFormat:(id<DCAPIKotlinx_datetimeDateTimeFormat>)format __attribute__((swift_name("date(format:)")));
- (void)dayOfMonthPadding:(DCAPIKotlinx_datetimePadding *)padding __attribute__((swift_name("dayOfMonth(padding:)")));
- (void)dayOfWeekNames:(DCAPIKotlinx_datetimeDayOfWeekNames *)names __attribute__((swift_name("dayOfWeek(names:)")));
- (void)monthNameNames:(DCAPIKotlinx_datetimeMonthNames *)names __attribute__((swift_name("monthName(names:)")));
- (void)monthNumberPadding:(DCAPIKotlinx_datetimePadding *)padding __attribute__((swift_name("monthNumber(padding:)")));
- (void)yearPadding:(DCAPIKotlinx_datetimePadding *)padding __attribute__((swift_name("year(padding:)")));
- (void)yearTwoDigitsBaseYear:(int32_t)baseYear __attribute__((swift_name("yearTwoDigits(baseYear:)")));
@end

__attribute__((swift_name("Kotlinx_datetimeDateTimeFormatBuilderWithTime")))
@protocol DCAPIKotlinx_datetimeDateTimeFormatBuilderWithTime <DCAPIKotlinx_datetimeDateTimeFormatBuilder>
@required
- (void)amPmHourPadding:(DCAPIKotlinx_datetimePadding *)padding __attribute__((swift_name("amPmHour(padding:)")));
- (void)amPmMarkerAm:(NSString *)am pm:(NSString *)pm __attribute__((swift_name("amPmMarker(am:pm:)")));
- (void)hourPadding:(DCAPIKotlinx_datetimePadding *)padding __attribute__((swift_name("hour(padding:)")));
- (void)minutePadding:(DCAPIKotlinx_datetimePadding *)padding __attribute__((swift_name("minute(padding:)")));
- (void)secondPadding:(DCAPIKotlinx_datetimePadding *)padding __attribute__((swift_name("second(padding:)")));
- (void)secondFractionFixedLength:(int32_t)fixedLength __attribute__((swift_name("secondFraction(fixedLength:)")));
- (void)secondFractionMinLength:(int32_t)minLength maxLength:(int32_t)maxLength __attribute__((swift_name("secondFraction(minLength:maxLength:)")));
- (void)timeFormat:(id<DCAPIKotlinx_datetimeDateTimeFormat>)format __attribute__((swift_name("time(format:)")));
@end

__attribute__((swift_name("Kotlinx_datetimeDateTimeFormatBuilderWithDateTime")))
@protocol DCAPIKotlinx_datetimeDateTimeFormatBuilderWithDateTime <DCAPIKotlinx_datetimeDateTimeFormatBuilderWithDate, DCAPIKotlinx_datetimeDateTimeFormatBuilderWithTime>
@required
- (void)dateTimeFormat:(id<DCAPIKotlinx_datetimeDateTimeFormat>)format __attribute__((swift_name("dateTime(format:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol DCAPIKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<DCAPIKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<DCAPIKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol DCAPIKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<DCAPIKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<DCAPIKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol DCAPIKotlinx_serialization_coreKSerializer <DCAPIKotlinx_serialization_coreSerializationStrategy, DCAPIKotlinx_serialization_coreDeserializationStrategy>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataCardEntity")))
@interface DCAPIData_container_dataCardEntity : DCAPIBase
- (instancetype)initWithPan:(NSString *)pan aid:(NSString *)aid cvm:(NSString *)cvm cardholderName:(NSString *)cardholderName cardholderNameExtended:(NSString *)cardholderNameExtended transactionType:(NSString *)transactionType voucherType:(NSString *)voucherType appLabel:(NSString *)appLabel brandId:(int32_t)brandId brandName:(NSString *)brandName accountBalance:(NSString *)accountBalance entryMode:(NSString *)entryMode sequenceNumber:(NSString * _Nullable)sequenceNumber atcPayment:(NSString * _Nullable)atcPayment atcCancellation:(NSString * _Nullable)atcCancellation cardHolder:(DCAPIData_container_dataCardHolderEntity *)cardHolder serviceCode:(NSString *)serviceCode __attribute__((swift_name("init(pan:aid:cvm:cardholderName:cardholderNameExtended:transactionType:voucherType:appLabel:brandId:brandName:accountBalance:entryMode:sequenceNumber:atcPayment:atcCancellation:cardHolder:serviceCode:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataCardEntity *)doCopyPan:(NSString *)pan aid:(NSString *)aid cvm:(NSString *)cvm cardholderName:(NSString *)cardholderName cardholderNameExtended:(NSString *)cardholderNameExtended transactionType:(NSString *)transactionType voucherType:(NSString *)voucherType appLabel:(NSString *)appLabel brandId:(int32_t)brandId brandName:(NSString *)brandName accountBalance:(NSString *)accountBalance entryMode:(NSString *)entryMode sequenceNumber:(NSString * _Nullable)sequenceNumber atcPayment:(NSString * _Nullable)atcPayment atcCancellation:(NSString * _Nullable)atcCancellation cardHolder:(DCAPIData_container_dataCardHolderEntity *)cardHolder serviceCode:(NSString *)serviceCode __attribute__((swift_name("doCopy(pan:aid:cvm:cardholderName:cardholderNameExtended:transactionType:voucherType:appLabel:brandId:brandName:accountBalance:entryMode:sequenceNumber:atcPayment:atcCancellation:cardHolder:serviceCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountBalance __attribute__((swift_name("accountBalance")));
@property (readonly) NSString *aid __attribute__((swift_name("aid")));
@property (readonly) NSString *appLabel __attribute__((swift_name("appLabel")));
@property (readonly) NSString * _Nullable atcCancellation __attribute__((swift_name("atcCancellation")));
@property (readonly) NSString * _Nullable atcPayment __attribute__((swift_name("atcPayment")));
@property (readonly) int32_t brandId __attribute__((swift_name("brandId")));
@property (readonly) NSString *brandName __attribute__((swift_name("brandName")));
@property (readonly) DCAPIData_container_dataCardHolderEntity *cardHolder __attribute__((swift_name("cardHolder")));
@property (readonly) NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property (readonly) NSString *cardholderNameExtended __attribute__((swift_name("cardholderNameExtended")));
@property (readonly) NSString *cvm __attribute__((swift_name("cvm")));
@property (readonly) NSString *entryMode __attribute__((swift_name("entryMode")));
@property (readonly) NSString *pan __attribute__((swift_name("pan")));
@property (readonly) NSString * _Nullable sequenceNumber __attribute__((swift_name("sequenceNumber")));
@property (readonly) NSString *serviceCode __attribute__((swift_name("serviceCode")));
@property (readonly) NSString *transactionType __attribute__((swift_name("transactionType")));
@property (readonly) NSString *voucherType __attribute__((swift_name("voucherType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataCustomerEntity")))
@interface DCAPIData_container_dataCustomerEntity : DCAPIBase
- (instancetype)initWithAccountholderNumber:(NSString *)accountholderNumber accountholderName:(NSString *)accountholderName customerWalletProviderId:(NSString *)customerWalletProviderId customerWalletProviderName:(NSString *)customerWalletProviderName __attribute__((swift_name("init(accountholderNumber:accountholderName:customerWalletProviderId:customerWalletProviderName:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataCustomerEntity *)doCopyAccountholderNumber:(NSString *)accountholderNumber accountholderName:(NSString *)accountholderName customerWalletProviderId:(NSString *)customerWalletProviderId customerWalletProviderName:(NSString *)customerWalletProviderName __attribute__((swift_name("doCopy(accountholderNumber:accountholderName:customerWalletProviderId:customerWalletProviderName:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountholderName __attribute__((swift_name("accountholderName")));
@property (readonly) NSString *accountholderNumber __attribute__((swift_name("accountholderNumber")));
@property (readonly) NSString *customerWalletProviderId __attribute__((swift_name("customerWalletProviderId")));
@property (readonly) NSString *customerWalletProviderName __attribute__((swift_name("customerWalletProviderName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataInstantPaymentEntity")))
@interface DCAPIData_container_dataInstantPaymentEntity : DCAPIBase
- (instancetype)initWithInstantPaymentId:(NSString * _Nullable)instantPaymentId amount:(NSString * _Nullable)amount fee:(DCAPIInt * _Nullable)fee createdAt:(NSString * _Nullable)createdAt approvedAt:(NSString * _Nullable)approvedAt refusedAt:(NSString * _Nullable)refusedAt paymentId:(NSString * _Nullable)paymentId __attribute__((swift_name("init(instantPaymentId:amount:fee:createdAt:approvedAt:refusedAt:paymentId:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataInstantPaymentEntity *)doCopyInstantPaymentId:(NSString * _Nullable)instantPaymentId amount:(NSString * _Nullable)amount fee:(DCAPIInt * _Nullable)fee createdAt:(NSString * _Nullable)createdAt approvedAt:(NSString * _Nullable)approvedAt refusedAt:(NSString * _Nullable)refusedAt paymentId:(NSString * _Nullable)paymentId __attribute__((swift_name("doCopy(instantPaymentId:amount:fee:createdAt:approvedAt:refusedAt:paymentId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable amount __attribute__((swift_name("amount")));
@property (readonly) NSString * _Nullable approvedAt __attribute__((swift_name("approvedAt")));
@property (readonly) NSString * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property (readonly) DCAPIInt * _Nullable fee __attribute__((swift_name("fee")));
@property (readonly) NSString * _Nullable instantPaymentId __attribute__((swift_name("instantPaymentId")));
@property (readonly) NSString * _Nullable paymentId __attribute__((swift_name("paymentId")));
@property (readonly) NSString * _Nullable refusedAt __attribute__((swift_name("refusedAt")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataAddressEntity")))
@interface DCAPIData_container_dataAddressEntity : DCAPIBase
- (instancetype)initWithStreet:(NSString *)street number:(NSString *)number complement:(NSString *)complement neighborhood:(NSString *)neighborhood zipCode:(NSString *)zipCode city:(NSString *)city state:(NSString *)state __attribute__((swift_name("init(street:number:complement:neighborhood:zipCode:city:state:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataAddressEntity *)doCopyStreet:(NSString *)street number:(NSString *)number complement:(NSString *)complement neighborhood:(NSString *)neighborhood zipCode:(NSString *)zipCode city:(NSString *)city state:(NSString *)state __attribute__((swift_name("doCopy(street:number:complement:neighborhood:zipCode:city:state:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *city __attribute__((swift_name("city")));
@property (readonly) NSString *complement __attribute__((swift_name("complement")));
@property (readonly) NSString *neighborhood __attribute__((swift_name("neighborhood")));
@property (readonly) NSString *number __attribute__((swift_name("number")));
@property (readonly) NSString *state __attribute__((swift_name("state")));
@property (readonly) NSString *street __attribute__((swift_name("street")));
@property (readonly) NSString *zipCode __attribute__((swift_name("zipCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataPixAccountEntity")))
@interface DCAPIData_container_dataPixAccountEntity : DCAPIBase
- (instancetype)initWithAccountNumber:(NSString *)accountNumber branch:(NSString * _Nullable)branch accountId:(NSString *)accountId entry:(NSString * _Nullable)entry email:(NSString * _Nullable)email __attribute__((swift_name("init(accountNumber:branch:accountId:entry:email:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataPixAccountEntity *)doCopyAccountNumber:(NSString *)accountNumber branch:(NSString * _Nullable)branch accountId:(NSString *)accountId entry:(NSString * _Nullable)entry email:(NSString * _Nullable)email __attribute__((swift_name("doCopy(accountNumber:branch:accountId:entry:email:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountId __attribute__((swift_name("accountId")));
@property (readonly) NSString *accountNumber __attribute__((swift_name("accountNumber")));
@property (readonly) NSString * _Nullable branch __attribute__((swift_name("branch")));
@property (readonly) NSString * _Nullable email __attribute__((swift_name("email")));
@property (readonly) NSString * _Nullable entry __attribute__((swift_name("entry")));
@end

__attribute__((swift_name("Room_runtimeInvalidationTracker.Observer")))
@interface DCAPIRoom_runtimeInvalidationTrackerObserver : DCAPIBase
- (instancetype)initWithTables:(DCAPIKotlinArray<NSString *> *)tables __attribute__((swift_name("init(tables:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithFirstTable:(NSString *)firstTable rest:(DCAPIKotlinArray<NSString *> *)rest __attribute__((swift_name("init(firstTable:rest:)"))) __attribute__((objc_designated_initializer));
- (void)onInvalidatedTables:(NSSet<NSString *> *)tables __attribute__((swift_name("onInvalidated(tables:)")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol DCAPIKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<DCAPIKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<DCAPIKotlinCoroutineContextElement> _Nullable)getKey:(id<DCAPIKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<DCAPIKotlinCoroutineContext>)minusKeyKey:(id<DCAPIKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<DCAPIKotlinCoroutineContext>)plusContext:(id<DCAPIKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataFullTransactionView")))
@interface DCAPIData_container_dataFullTransactionView : DCAPIBase
- (instancetype)initWithId:(int64_t)id amount:(NSString *)amount authorizedAmount:(NSString * _Nullable)authorizedAmount cancelledAmount:(NSString * _Nullable)cancelledAmount dateTime:(NSString *)dateTime isCapture:(BOOL)isCapture subMerchantMcc:(NSString * _Nullable)subMerchantMcc subMerchantAddress:(DCAPIData_container_dataAddressEntity * _Nullable)subMerchantAddress affiliationCode:(NSString *)affiliationCode cvm:(NSString *)cvm accountBalance:(NSString *)accountBalance cardHolderName:(NSString *)cardHolderName cardHolderNameExtended:(NSString *)cardHolderNameExtended cardVoucherType:(NSString *)cardVoucherType cardAppLabel:(NSString *)cardAppLabel cardHolderEmail:(NSString *)cardHolderEmail cardServiceCode:(NSString *)cardServiceCode cardPan:(NSString *)cardPan cardBrandName:(NSString *)cardBrandName cardBrandId:(int32_t)cardBrandId orderId:(NSString *)orderId pinpadUsed:(NSString *)pinpadUsed instalmentCount:(int32_t)instalmentCount instalmentType:(NSString *)instalmentType transactionReference:(NSString *)transactionReference paymentBusinessModel:(NSString *)paymentBusinessModel signature:(NSString * _Nullable)signature isEmergencyAid:(BOOL)isEmergencyAid appIdentification:(NSString *)appIdentification qualifier:(NSString * _Nullable)qualifier entryMode:(NSString *)entryMode transactionStatus:(NSString *)transactionStatus transactionType:(NSString *)transactionType authorizationCode:(NSString * _Nullable)authorizationCode atk:(NSString * _Nullable)atk itk:(NSString * _Nullable)itk arqc:(NSString * _Nullable)arqc aid:(NSString *)aid subMerchantTaxNumber:(NSString * _Nullable)subMerchantTaxNumber subMerchantRegisteredIdentifier:(NSString * _Nullable)subMerchantRegisteredIdentifier iccRelatedData:(NSString * _Nullable)iccRelatedData __attribute__((swift_name("init(id:amount:authorizedAmount:cancelledAmount:dateTime:isCapture:subMerchantMcc:subMerchantAddress:affiliationCode:cvm:accountBalance:cardHolderName:cardHolderNameExtended:cardVoucherType:cardAppLabel:cardHolderEmail:cardServiceCode:cardPan:cardBrandName:cardBrandId:orderId:pinpadUsed:instalmentCount:instalmentType:transactionReference:paymentBusinessModel:signature:isEmergencyAid:appIdentification:qualifier:entryMode:transactionStatus:transactionType:authorizationCode:atk:itk:arqc:aid:subMerchantTaxNumber:subMerchantRegisteredIdentifier:iccRelatedData:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataFullTransactionView *)doCopyId:(int64_t)id amount:(NSString *)amount authorizedAmount:(NSString * _Nullable)authorizedAmount cancelledAmount:(NSString * _Nullable)cancelledAmount dateTime:(NSString *)dateTime isCapture:(BOOL)isCapture subMerchantMcc:(NSString * _Nullable)subMerchantMcc subMerchantAddress:(DCAPIData_container_dataAddressEntity * _Nullable)subMerchantAddress affiliationCode:(NSString *)affiliationCode cvm:(NSString *)cvm accountBalance:(NSString *)accountBalance cardHolderName:(NSString *)cardHolderName cardHolderNameExtended:(NSString *)cardHolderNameExtended cardVoucherType:(NSString *)cardVoucherType cardAppLabel:(NSString *)cardAppLabel cardHolderEmail:(NSString *)cardHolderEmail cardServiceCode:(NSString *)cardServiceCode cardPan:(NSString *)cardPan cardBrandName:(NSString *)cardBrandName cardBrandId:(int32_t)cardBrandId orderId:(NSString *)orderId pinpadUsed:(NSString *)pinpadUsed instalmentCount:(int32_t)instalmentCount instalmentType:(NSString *)instalmentType transactionReference:(NSString *)transactionReference paymentBusinessModel:(NSString *)paymentBusinessModel signature:(NSString * _Nullable)signature isEmergencyAid:(BOOL)isEmergencyAid appIdentification:(NSString *)appIdentification qualifier:(NSString * _Nullable)qualifier entryMode:(NSString *)entryMode transactionStatus:(NSString *)transactionStatus transactionType:(NSString *)transactionType authorizationCode:(NSString * _Nullable)authorizationCode atk:(NSString * _Nullable)atk itk:(NSString * _Nullable)itk arqc:(NSString * _Nullable)arqc aid:(NSString *)aid subMerchantTaxNumber:(NSString * _Nullable)subMerchantTaxNumber subMerchantRegisteredIdentifier:(NSString * _Nullable)subMerchantRegisteredIdentifier iccRelatedData:(NSString * _Nullable)iccRelatedData __attribute__((swift_name("doCopy(id:amount:authorizedAmount:cancelledAmount:dateTime:isCapture:subMerchantMcc:subMerchantAddress:affiliationCode:cvm:accountBalance:cardHolderName:cardHolderNameExtended:cardVoucherType:cardAppLabel:cardHolderEmail:cardServiceCode:cardPan:cardBrandName:cardBrandId:orderId:pinpadUsed:instalmentCount:instalmentType:transactionReference:paymentBusinessModel:signature:isEmergencyAid:appIdentification:qualifier:entryMode:transactionStatus:transactionType:authorizationCode:atk:itk:arqc:aid:subMerchantTaxNumber:subMerchantRegisteredIdentifier:iccRelatedData:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accountBalance __attribute__((swift_name("accountBalance")));
@property (readonly) NSString *affiliationCode __attribute__((swift_name("affiliationCode")));
@property (readonly) NSString *aid __attribute__((swift_name("aid")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) NSString *appIdentification __attribute__((swift_name("appIdentification")));
@property (readonly) NSString * _Nullable arqc __attribute__((swift_name("arqc")));
@property (readonly) NSString * _Nullable atk __attribute__((swift_name("atk")));
@property (readonly) NSString * _Nullable authorizationCode __attribute__((swift_name("authorizationCode")));
@property (readonly) NSString * _Nullable authorizedAmount __attribute__((swift_name("authorizedAmount")));
@property (readonly) NSString * _Nullable cancelledAmount __attribute__((swift_name("cancelledAmount")));
@property (readonly) NSString *cardAppLabel __attribute__((swift_name("cardAppLabel")));
@property (readonly) int32_t cardBrandId __attribute__((swift_name("cardBrandId")));
@property (readonly) NSString *cardBrandName __attribute__((swift_name("cardBrandName")));
@property (readonly) NSString *cardHolderEmail __attribute__((swift_name("cardHolderEmail")));
@property (readonly) NSString *cardHolderName __attribute__((swift_name("cardHolderName")));
@property (readonly) NSString *cardHolderNameExtended __attribute__((swift_name("cardHolderNameExtended")));
@property (readonly) NSString *cardPan __attribute__((swift_name("cardPan")));
@property (readonly) NSString *cardServiceCode __attribute__((swift_name("cardServiceCode")));
@property (readonly) NSString *cardVoucherType __attribute__((swift_name("cardVoucherType")));
@property (readonly) NSString *cvm __attribute__((swift_name("cvm")));
@property (readonly) NSString *dateTime __attribute__((swift_name("dateTime")));
@property (readonly) NSString *entryMode __attribute__((swift_name("entryMode")));
@property (readonly) NSString * _Nullable iccRelatedData __attribute__((swift_name("iccRelatedData")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) int32_t instalmentCount __attribute__((swift_name("instalmentCount")));
@property (readonly) NSString *instalmentType __attribute__((swift_name("instalmentType")));
@property (readonly) BOOL isCapture __attribute__((swift_name("isCapture")));
@property (readonly) BOOL isEmergencyAid __attribute__((swift_name("isEmergencyAid")));
@property (readonly) NSString * _Nullable itk __attribute__((swift_name("itk")));
@property (readonly) NSString *orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString *paymentBusinessModel __attribute__((swift_name("paymentBusinessModel")));
@property (readonly) NSString *pinpadUsed __attribute__((swift_name("pinpadUsed")));
@property (readonly) NSString * _Nullable qualifier __attribute__((swift_name("qualifier")));
@property (readonly) NSString * _Nullable signature __attribute__((swift_name("signature")));
@property (readonly) DCAPIData_container_dataAddressEntity * _Nullable subMerchantAddress __attribute__((swift_name("subMerchantAddress")));
@property (readonly) NSString * _Nullable subMerchantMcc __attribute__((swift_name("subMerchantMcc")));
@property (readonly) NSString * _Nullable subMerchantRegisteredIdentifier __attribute__((swift_name("subMerchantRegisteredIdentifier")));
@property (readonly) NSString * _Nullable subMerchantTaxNumber __attribute__((swift_name("subMerchantTaxNumber")));
@property (readonly) NSString *transactionReference __attribute__((swift_name("transactionReference")));
@property (readonly) NSString *transactionStatus __attribute__((swift_name("transactionStatus")));
@property (readonly) NSString *transactionType __attribute__((swift_name("transactionType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataTransactionTokenEntity")))
@interface DCAPIData_container_dataTransactionTokenEntity : DCAPIBase
- (instancetype)initWithTransactionTokenAffiliationCode:(NSString *)transactionTokenAffiliationCode token:(NSString *)token compactToken:(NSString * _Nullable)compactToken expiresIn:(int32_t)expiresIn createdAt:(int64_t)createdAt __attribute__((swift_name("init(transactionTokenAffiliationCode:token:compactToken:expiresIn:createdAt:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataTransactionTokenEntity *)doCopyTransactionTokenAffiliationCode:(NSString *)transactionTokenAffiliationCode token:(NSString *)token compactToken:(NSString * _Nullable)compactToken expiresIn:(int32_t)expiresIn createdAt:(int64_t)createdAt __attribute__((swift_name("doCopy(transactionTokenAffiliationCode:token:compactToken:expiresIn:createdAt:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable compactToken __attribute__((swift_name("compactToken")));
@property (readonly) int64_t createdAt __attribute__((swift_name("createdAt")));
@property (readonly) int32_t expiresIn __attribute__((swift_name("expiresIn")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@property (readonly) NSString *transactionTokenAffiliationCode __attribute__((swift_name("transactionTokenAffiliationCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface DCAPIKotlinByteArray : DCAPIBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(DCAPIByte *(^)(DCAPIInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (DCAPIKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol DCAPIKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol DCAPIKotlinSuspendFunction1 <DCAPIKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol DCAPIKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<DCAPIKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((swift_name("KotlinAppendable")))
@protocol DCAPIKotlinAppendable
@required
- (id<DCAPIKotlinAppendable>)appendValue:(unichar)value __attribute__((swift_name("append(value:)")));
- (id<DCAPIKotlinAppendable>)appendValue_:(id _Nullable)value __attribute__((swift_name("append(value_:)")));
- (id<DCAPIKotlinAppendable>)appendValue:(id _Nullable)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("append(value:startIndex:endIndex:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimePadding")))
@interface DCAPIKotlinx_datetimePadding : DCAPIKotlinEnum<DCAPIKotlinx_datetimePadding *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) DCAPIKotlinx_datetimePadding *none __attribute__((swift_name("none")));
@property (class, readonly) DCAPIKotlinx_datetimePadding *zero __attribute__((swift_name("zero")));
@property (class, readonly) DCAPIKotlinx_datetimePadding *space __attribute__((swift_name("space")));
+ (DCAPIKotlinArray<DCAPIKotlinx_datetimePadding *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<DCAPIKotlinx_datetimePadding *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeDayOfWeekNames")))
@interface DCAPIKotlinx_datetimeDayOfWeekNames : DCAPIBase
- (instancetype)initWithNames:(NSArray<NSString *> *)names __attribute__((swift_name("init(names:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMonday:(NSString *)monday tuesday:(NSString *)tuesday wednesday:(NSString *)wednesday thursday:(NSString *)thursday friday:(NSString *)friday saturday:(NSString *)saturday sunday:(NSString *)sunday __attribute__((swift_name("init(monday:tuesday:wednesday:thursday:friday:saturday:sunday:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) DCAPIKotlinx_datetimeDayOfWeekNamesCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSArray<NSString *> *names __attribute__((swift_name("names")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeMonthNames")))
@interface DCAPIKotlinx_datetimeMonthNames : DCAPIBase
- (instancetype)initWithNames:(NSArray<NSString *> *)names __attribute__((swift_name("init(names:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithJanuary:(NSString *)january february:(NSString *)february march:(NSString *)march april:(NSString *)april may:(NSString *)may june:(NSString *)june july:(NSString *)july august:(NSString *)august september:(NSString *)september october:(NSString *)october november:(NSString *)november december:(NSString *)december __attribute__((swift_name("init(january:february:march:april:may:june:july:august:september:october:november:december:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) DCAPIKotlinx_datetimeMonthNamesCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSArray<NSString *> *names __attribute__((swift_name("names")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol DCAPIKotlinx_serialization_coreEncoder
@required
- (id<DCAPIKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<DCAPIKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<DCAPIKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<DCAPIKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<DCAPIKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) DCAPIKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol DCAPIKotlinx_serialization_coreSerialDescriptor
@required

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSArray<id<DCAPIKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<DCAPIKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSArray<id<DCAPIKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) DCAPIKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol DCAPIKotlinx_serialization_coreDecoder
@required
- (id<DCAPIKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<DCAPIKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (DCAPIKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<DCAPIKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<DCAPIKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) DCAPIKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Data_container_dataCardHolderEntity")))
@interface DCAPIData_container_dataCardHolderEntity : DCAPIBase
- (instancetype)initWithEmail:(NSString *)email __attribute__((swift_name("init(email:)"))) __attribute__((objc_designated_initializer));
- (DCAPIData_container_dataCardHolderEntity *)doCopyEmail:(NSString *)email __attribute__((swift_name("doCopy(email:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol DCAPIKotlinCoroutineContextElement <DCAPIKotlinCoroutineContext>
@required
@property (readonly) id<DCAPIKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol DCAPIKotlinCoroutineContextKey
@required
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface DCAPIKotlinByteIterator : DCAPIBase <DCAPIKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (DCAPIByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol DCAPIKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeDayOfWeekNames.Companion")))
@interface DCAPIKotlinx_datetimeDayOfWeekNamesCompanion : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPIKotlinx_datetimeDayOfWeekNamesCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) DCAPIKotlinx_datetimeDayOfWeekNames *ENGLISH_ABBREVIATED __attribute__((swift_name("ENGLISH_ABBREVIATED")));
@property (readonly) DCAPIKotlinx_datetimeDayOfWeekNames *ENGLISH_FULL __attribute__((swift_name("ENGLISH_FULL")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeMonthNames.Companion")))
@interface DCAPIKotlinx_datetimeMonthNamesCompanion : DCAPIBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) DCAPIKotlinx_datetimeMonthNamesCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) DCAPIKotlinx_datetimeMonthNames *ENGLISH_ABBREVIATED __attribute__((swift_name("ENGLISH_ABBREVIATED")));
@property (readonly) DCAPIKotlinx_datetimeMonthNames *ENGLISH_FULL __attribute__((swift_name("ENGLISH_FULL")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol DCAPIKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<DCAPIKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<DCAPIKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<DCAPIKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) DCAPIKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface DCAPIKotlinx_serialization_coreSerializersModule : DCAPIBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<DCAPIKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<DCAPIKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<DCAPIKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<DCAPIKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<DCAPIKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<DCAPIKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<DCAPIKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<DCAPIKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol DCAPIKotlinAnnotation
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface DCAPIKotlinx_serialization_coreSerialKind : DCAPIBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol DCAPIKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<DCAPIKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<DCAPIKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<DCAPIKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<DCAPIKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) DCAPIKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface DCAPIKotlinNothing : DCAPIBase
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol DCAPIKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<DCAPIKotlinKClass>)kClass provider:(id<DCAPIKotlinx_serialization_coreKSerializer> (^)(NSArray<id<DCAPIKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<DCAPIKotlinKClass>)kClass serializer:(id<DCAPIKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<DCAPIKotlinKClass>)baseClass actualClass:(id<DCAPIKotlinKClass>)actualClass actualSerializer:(id<DCAPIKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<DCAPIKotlinKClass>)baseClass defaultDeserializerProvider:(id<DCAPIKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<DCAPIKotlinKClass>)baseClass defaultDeserializerProvider:(id<DCAPIKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<DCAPIKotlinKClass>)baseClass defaultSerializerProvider:(id<DCAPIKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
